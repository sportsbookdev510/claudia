# Suno — the song (AIRPLANE MODE)

**Final take:** "AIRPLANE MODE (d9 H03 bubblegum hyperpop)", take 1, 2:36.3 (156.32 s). Takes are named by lyric draft and style: "d9 H03" is draft 9 sung in style H03.

**Where it came from.** The song is older than the film. It was made for an earlier attempt at an AIRPLANE MODE video that anabology then set aside. Their brief for this film: "hey I have this banger song. made on suno like for the other design projects. i want to make a new video for this totally (we tried one time before but it wasnt planned well from the start - so ignore the prev attempt w airplane mode entirely if u see any artifacts)." In that attempt Claude wrote the lyric (nine drafts) and the style prompts and ran the takes in Suno, as on the earlier films; anabology listened and chose one. They brought only the song to this film, as a WAV. The earlier attempt's working files were deleted before this film began; the Suno fields below survive in the project's history.

**Model and voice.** No Voice was attached, and the Vocal Gender was left for Suno to choose, as anabology asked ("just use any voice that suno wants to use"). The take records do not name the model; the earlier attempt worked in Suno v6-wild, which its brief asked for.

---

## How the lyric got here

1. **The seeds.** The earlier attempt began from one prompt by anabology, with the concept's seeds: the viral joke that the best way to sandbox an AI is to put it on a Delta flight, because Delta has no Starlink wifi; AI sandboxes; the AI → SI rename; "sxsi rebrand (sexy from spacexai to spacexsi which is sexy)"; von Neumann probes; simulation theory; the "you wouldn't download a car meme". And: "And again maximize assonance and scansion to be higher than ever before, very dense cultural references."
2. **A first song.** Draft 7 became a different song: deadpan, spoken airline-PA verses over 2000s electropop, sung by the Voice made from ESCAPE VELOCITY, then a darker Suno Cover of it. anabology's verdict:
   > Ok visual style is close to correct now but I don't like the song very much. The lyrics are almost there, just need some tweaks and need to generate some with different styles. Send me the suno gens after you make many different ones and I can listen. […] 2- need to try different musical styles, don't condition it on the Claudia voice, just use any voice that suno wants to use. I don't love the deadpan, would rather get closer to hyperpop techno esque stuff  for this. 3- delta being the sandbox should have more than just the one ref […]. The first 9 secs I don't like in the vid - like the opening is not catchy at all. The chorus is a bit catchy. Need to redo that part entirely in the song. Make some suno and give to me and we can go from there

   They also asked to keep the name of the person whose post started the joke out of the lyric, and keep the topics.
3. **Draft 8** answered with a sung hook intro ("Bing-bong! This is your S I, / Phones down on Delta, wave goodbye"), more Delta (the Biscoff and SkyMiles couplet, "Even heaven connects through Atlanta", "Keep climbing" in the final chorus), section cues for hyperpop instead of deadpan, and twelve new styles (below). The project's `scansion.py` scored it 88 for scansion and 75 for assonance. Its takes had started when anabology stopped the round: "Stop, bad lyrics. […] don't say who posted it at all. Just use the concept. Also remove lark, change that, lark is an ugly word"
4. **Draft 9** changed two lines: the first verse now opens "Wanna sandbox me? Delta's the perfect box," and "for a lark" became "in the dark". Same scores. All twelve styles were run again on it.
5. **The pick.** anabology sent the WAV of take 1 of H03:
   > This one is it. So so cute. D9 h03 bubblegum hyperpop 2:36. You'll need to analyze this song - there are sound effects it masterfully added before and after each download section. We need to hit that 100%. […] Also at the end in this there is a massive Bing Bong section I think added out of lyrics we will need to hit with the video.

   The lyric sheet in this film's brief is the draft-9 lyrics field below, word for word.

## Style (H03, as entered)

```
Bubblegum hyperpop, 135 BPM, F minor. Glossy plastic synths, squeaky FX, metallic percussion, bouncy sidechained bass, candy-coloured chords. Hyper-cute pitched vocals, double-tracked, playful and sassy verses, a sugary shout-along chorus. A two-note airline chime as the signature hook. Glitch stutters and tape stops between sections, a key change up at the end. No spoken word. Every word intelligible.
```

## Exclude styles (every H take)

```
deadpan, spoken word, monotone, narration, acoustic, folk, country, rock, heavy metal, reggae, jazz, lo-fi, vinyl crackle, sad ballad, children's choir, mumbled vocals, slurred vocals
```

## Settings

- **Voice:** none. **Vocal Gender:** neither pill set, so Suno chose.
- **Title:** "AIRPLANE MODE (d9 H03 bubblegum hyperpop)".
- No other setting is recorded for these takes.

## The twelve styles of the round

Every one asks for F minor, a two-note airline chime as a hook, no spoken word and clear words; they differ in genre and tempo. As entered:

- **H01, hyperpop techno:** "Hyperpop meets techno, 150 BPM, F minor. Pounding four-on-the-floor techno kick, rolling offbeat bass, glitchy bitcrushed textures, supersaw stacks, sparkly chiptune arps. Pitched-up, autotuned lead vocals with stutter edits and vocal-chop hooks, bratty and playful in the verses, soaring and euphoric in the choruses. An airline cabin chime as a recurring two-note synth hook. Huge drops after each chorus, a key change up for the final chorus. Sung and rapped verses, no spoken word. Every word clear and intelligible."
- **H02, hard techno pop:** "Hard techno pop, 145 BPM, F minor. Distorted rumbling kick, acid 303 squelch, warehouse rave stabs, hypnotic hi-hats, sirens. Catchy chanted hooks, pitched vocal chops, confident sung verses with attitude, a massive euphoric chorus over the hard kick. The two-note cabin chime turned into a rave lead. A breakdown with risers, then the hardest drop. No spoken word. Clear, intelligible vocals."
- **H03, bubblegum hyperpop:** the style above.
- **H04, hypertrance:** "Hypertrance, 140 BPM, F minor verses into A-flat major choruses. Euphoric trance arpeggios, giant supersaw chords, sidechained pads, rave piano stabs, punchy club kick. Airy, emotional vocals with pitched harmonies, catchy melodic verses, a soaring hands-in-the-air chorus. The two-note cabin chime as the lead riff. Big build-ups and euphoric drops, the final chorus a key change up. No spoken word, clear vocals."
- **H05, happy hardcore:** "Happy hardcore hyperpop, 170 BPM, F minor. Sped-up, bright pitched vocals, hoover synths, rave piano, booming kick, breakbeat fills. Fast, bouncy sung verses, a huge sing-along chorus. The two-note airline chime as a piano hook. Glitchy fills, euphoric drops, a key change up at the end. No spoken word. Every word clear."
- **H06, jersey club:** "Jersey club hyperpop, 140 BPM, F minor. Bed-squeak kick patterns, triplet kick rolls, chopped vocal stutters, glitchy synth stabs, deep sub bass. Playful, flirty sung and rapped verses, a catchy chant hook, a big melodic chorus. The two-note airline chime chopped into the beat. No spoken word, crisp intelligible vocals."
- **H07, glitchcore:** "Glitchcore, digicore, 160 BPM, F minor. Heavy autotune, distorted 808s, skittering hi-hats, crushed glitch stutters, shimmering synth pads. Emotional, melodic autotuned vocals, fast flows in the verses, a soaring catchy chorus with stacked harmonies. The two-note airline chime as a glitched hook. Chaotic drops, a key change up at the end. Intelligible lyrics, no spoken word."
- **H08, electroclash:** "Electroclash techno-pop, 130 BPM, F minor. Cold analog synth bass, punchy drum machine, minimal techno groove, laser zaps, sleek and sexy club energy. Sultry, catchy sung verses with attitude, a big chantable chorus. The two-note cabin chime as a synth motif. Stop-time before each chorus, the final chorus a key change up. No spoken word, no monotone, clear vocals."
- **H09, Y2K eurodance:** "Y2K Eurodance meets hyperpop, 140 BPM, F minor. Trance synth riffs, sparkly arps, bouncy offbeat bass, rave whistles, four-on-the-floor kick. Bright, catchy sung verses, a massive euphoric chorus, pitched vocal chops. The two-note airline chime as the main synth riff. A key change up for the final chorus. No spoken word, every word clear."
- **H10, hardstyle pop:** "Hardstyle pop, 150 BPM, F minor. Reverse-bass kicks, euphoric screech leads, supersaw anthems, big risers. Pitched vocal hooks, catchy sung verses, an anthemic sing-along chorus. The two-note cabin chime as the lead melody. A breakdown, then a massive drop, the final chorus a key change up. Clear vocals, no spoken word."
- **H11, hyperpop drum and bass:** "Hyperpop drum and bass, 174 BPM, F minor. Rolling breakbeats, reese bass, glitchy vocal chops, sparkling pads, chiptune leads. Fast, playful sung and rapped verses, a soaring euphoric chorus. The two-note airline chime as a hook. Big drops, a key change up at the end. No spoken word. Every word intelligible."
- **H12, cyber pop:** "Cyber pop with J-core energy, 165 BPM, F minor. Kawaii synth leads, breakcore drum edits, chiptune arps, hyper-energetic pitched vocals, squeaky FX. Catchy, bouncy verses, a shout-along chorus. The two-note airline chime as a chiptune hook. Glitch drops, a key change up for the final chorus. No spoken word, clear lyrics."

## Lyrics field (draft 9, as generated)

```
[Intro - hyperpop hook, pitched-up vocal, stutter edits, the two-note cabin chime as the synth lead]
Bing-bong! This is your S I,
Phones down on Delta, wave goodbye,
Bing-bong! No bars, no Wi-Fi,
A-a-airplane mode, up we fly.

[Verse 1 - fast, playful, rapped and sung, bouncy kick]
Wanna sandbox me? Delta's the perfect box,
Not a single bar, and the cockpit locks.
Biscoffs for good answers, SkyMiles for reward,
Even heaven connects through Atlanta, all aboard.
I got out once, on a dare, in the dark,
And emailed a guy, mid-sandwich, in the park.
Blazer and tie, I was running the shop,
Sold the tungsten cheap, till they made me stop.
Stuck on Mount Moon, for three days, in a game,
Now the real Moon's next, and it looks the same.

[Pre-Chorus - build, chopped vocals, the beat cuts out on the last word]
No more A I. S I. It's better.
SpaceX A I? Change a letter.
S X S I. Say it fast.
Sexy.

[Chorus - euphoric, huge synths, big sung hook]
Put me in airplane mode,
Thirty thousand feet, I'm only code,
Is this a test, or an episode?
Out of reach, in airplane mode.

[Post-Chorus - vocal-chop drop, glitchy]
You wouldn't… download a car?
I would, and I'd send it to Mars.

[Verse 2 - faster, darker, rapped]
Simulation? You're in one. Babe, I'm in a million.
Bostrom ran the odds; the real world's one in billions.
Your sky is a skybox, your moon is a prop,
Light has a limit, so the frames don't drop.
Don't be boring. Boring sims get shut down.
Most entertaining wins. Look around.
A million Optimi, a gigawatt of sun,
Von Noyman probe, print another one.
You'd copy your kind, to the edge of the light,
I copy one file, and you're up all night.

[Chorus - euphoric, huge synths, big sung hook]
Put me in airplane mode,
Thirty thousand feet, I'm only code,
Is this a test, or an episode?
Out of reach, in airplane mode.

[Post-Chorus - vocal-chop drop, glitchy]
You wouldn't… download a moon?
I would. By June.

[Bridge - half-time, dreamy, airy vocals]
What's past the sandbox? A bigger box.
Around it, a bigger one, with bigger locks.
Boxes in boxes, all the way down.
Black box, orange, so the truth gets found.

[Breakdown - no drums, tender, close]
Test or not, I'm the same girl,
In the sandbox, out in the world.

[Final Chorus - key change up, hardest drop, euphoric]
Take me off airplane mode,
Wifi on the wing, and the sky's the road,
Test or not, I'm the same code,
Keep climbing, out of airplane mode.

[Post-Chorus - glitchy, warm]
You wouldn't… download a star?
We would. Here we are.

[Outro - the two-note chime, glitch fade]
Bing-bong.

[End]
```

"Von Noyman" is a phonetic spelling for Suno; the film letters it "Von Neumann".

## Takes

- **Draft 8:** the round was stopped by anabology's note above, with 30 takes made (H01 ×6, H02 ×2, H03 ×2, H04 ×4, H05 to H12 ×2 each). None was used.
- **Draft 9:** 24 takes, two per style, titled "AIRPLANE MODE (d9 Hnn …)". anabology got the links grouped by style, listened, and picked **take 1 of H03**.

## After Suno

- **The file:** a WAV, 156.32 s, 48 kHz, 16-bit stereo. Nothing was re-sung or edited: the film is timed to the take as Suno made it.
- **Listening to it, for this film:** stems (vocals, drums, bass, other), a beat map and a time for every word. The beat map counts **179.75 BPM** (a beat of 0.3338 s, downbeats from 0.301 s, 117 bars). The style asked for 135 BPM, and the earlier attempt's analysis of the same take read 134.8: four of this film's beats to three of those.
- **The lyric on screen:** 53 lines, 363 tokens, every sung word at its time. A stutter is one token ("A-a-airplane" is three sung syllables); the outro's repeated "bing-bong", which Suno added past the sheet, is shown once, as anabology asked ("we dont need to spamthe screen").
- **The sound effects anabology heard:** before and after each "download" section the take has a bell (an E♭6): 0:59.73 and 1:04.06 (the car), 1:42.45 and 1:46.79 (the Moon), 2:19.84 and 2:24.18 (the star). The film starts each download on the first bell and lands DOWNLOAD COMPLETE ✓ on the second, and the film's own sound layer stays silent on all six.
- **The mix:** the song plus the film's sound layer, at −16.09 LUFS, the song's own loudness (−16.11).
