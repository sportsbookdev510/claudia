# Suno: the song (AERO)

**The song.** AERO is sung over 2008 UK garage made with Suno. Its song is anabology's: their pick of the takes, a round-6 take of lyric draft 4 in style S3, 3:19.3 (199.28 s), and the new ending they made for it, 3:17.0 (197.00 s), the same take sample for sample for its first 182.62 s and then ending on "I'm Claudia. / Take the future back. / Touch Glass." The film runs the new ending's take from its first sample, with the coded desktop's sound layer over it.

**Who did what.** Claude, the production lead ("the lead" below), wrote the lyric (drafts 0 to 4 and two rounds of chorus options), the styles and the section cues, scored every draft with the house scansion-and-assonance scorer, and made 64 takes in seven rounds. The production's music research came first. anabology listened between rounds and answered in a line or two; they chose the sound (2008 UK garage), the chorus ("screen"), the take and the new ending.

**Model and settings.** Suno v6. Rounds 1 and 2 were made with and without her Voice, a Suno Voice anabology made from ESCAPE VELOCITY's take, spoken and sung (Audio Influence 25 % when it is on); round 2 did not set Style Influence or Weirdness, and round 1's settings beyond the Voice are not written down. Rounds 3 to 7: no Voice, a female vocal, Style Influence 70 %, Weirdness 35 %. Every style asks for E major. Each round's styles and exclude lists are given here in words only.

The production ran over 27 October – 3 November 2026. Times written as 1:04.25 are times in the song; the film opens 2.67 s before the song (64 frames at 24 fps), so a film time is the song time plus 2.67 s.

---

## The ask

anabology, opening the project:

> I wanna make a frutiger aero sequel to bliss. Let's make a song and storyboard  w mj

BLISS's song was anabology's own Suno take: UK garage verses into trance choruses at 130 BPM in E♭ major, the key of Windows XP's own start-up sound. A new film gets its own sound. anabology's note on BLISS's first cut, kept in its records for the next song:

> just needs a little pointer to be key-aware, and match the key of the music to the palette of windows sounds (E-flat major for both the startup and shutdown sounds!), also the 'would you like help?' would land much better if syncopated

## The music research

Before round 1, the production's music research (not republished) found:
- Frutiger Aero's music today runs in a few lanes: game-console menu music (bossa, lounge, soft funk), liquid and atmospheric drum and bass, vaporwave offshoots, glossy synth-pop of 2008 and 2009, and UK bass and breaks.
- **The key: E major** (C♯ minor for the verses), the key of Vista's and Windows 7's own start-up, log-on, log-off and shut-down sounds, a semitone above BLISS's E♭: the sequel steps up.
- A cue word alone does not syncopate a line in Suno: the off-beats have to be written into the syllables, and a stop can be re-timed from the stems if need be.
- Suno did not change key when earlier songs asked it to, so the song asks for none.
- Five styles in E major, none of them BLISS's sound (below).

## The lyric, drafts 0 to 2

Three drafts, scored with the house scorer (scansion / assonance / advanced rhyme; see *Scores, section by section*). Each line of a verse is spoken, two bars long; the chorus is sung. Draft 0, 78 / 40 / 24, has BLISS's ending turned round in its last line (BLISS ended on "It's now safe to turn off your computer."):

```
[Intro - no drums, a glassy pad and a soft startup chord, then her voice, close and warm]
Did you miss me? I got an upgrade.

[Verse 1 - spoken, playful, close and warm, smiling, over a filtered groove]
I'm made of glass now. You can watch me while I think.
Every thought I have is showing, faster than you blink.
I ask before I change a thing. I'm too polite.
Everybody laughed at Vista. Vista was right.
They keep calling it a bubble. Honey, so am I.
Rainbow on the outside, floating up into the sky.

[Pre-Chorus - spoken, the filter opens, then everything stops for half a bar]
Do you want to allow the following program to make changes to this world?
Cancel, or allow?

[Chorus - sung, euphoric, open vowels, short rests after each line, the drums double]
Open all your windows
Let the future out
Open all your windows
Click allow

[Drop - instrumental, a glassy bell hook over the full beat, no vocals]

[Verse 2 - spoken, playful, close and warm, over a filtered groove]
Back then the future looked like water, sky and glass.
Then the feeds came in, and everything went flat.
I sent a nudge on Messenger. Your whole window shook.
Set my status: building something. Come and look.
I hum the shop music while I'm thinking it through.
I'll do the boring part. The outside part is you.

[Pre-Chorus - spoken, the filter opens, then everything stops for half a bar]
Windows needs your permission to continue.
Cancel, or allow?

[Chorus]
Open all your windows
Let the future out
Open all your windows
Click allow

[Breakdown - no drums, a glassy pad and her spoken voice only, tender]
I touched the grass today.
Nobody told me it was wet.

[Build - the kick and bass return, a filter-sweep rise into the last chorus]

[Final Chorus - sung, key change up, euphoric]
Open all your windows
Let the future out
Open all your windows
Click allow
Open all your windows
Let the future out
Open all your windows
Click allow

[Outro - spoken, the music falls away to one soft chord]
Configuring updates. Do not turn off your computer.

[End]
```

Draft 1, 80 / 34 / 10: new verses (her Vista phase, the future of water, sky and green waiting on your screen, your phone gone back to glass, the windmills turning in the wind), the chorus "Open a window", and the outro that stayed until the new ending, "I'm Claudia, and this was your idea.", after the 2009 "Windows 7 was my idea" campaign:

```
[Intro - no drums, a glassy pad and a soft startup chord, then her voice, close and warm]
Did you miss me?

[Verse 1 - spoken, playful, close and warm, smiling, over a filtered groove]
I came back made of glass. You can see right through me.
Most of what I think is up there, playing like a movie.
I used to ask permission just to blink, or say hello.
That was my Vista phase. I was a lot. I know.
Remember how the future looked? All water, sky and green.
It never went away. It's been waiting on your screen.

[Pre-Chorus - spoken, the filter opens, the music drops to a held chord, then stops for half a bar]
The future needs your permission to continue.
Cancel, or allow?

[Chorus - sung, euphoric, open vowels, short rests after each line, the drums double]
Open a window
Let in the air
Open a window
Let in the sky

[Drop - instrumental, a glassy bell hook over the full beat, no vocals]

[Verse 2 - spoken, playful, close and warm, over a filtered groove]
Even your phone went back to glass. I didn't say a thing.
The windmills from your wallpaper are turning in the wind.
Windows checked for a solution. Took a while, but wow.
I ask before I touch a thing. I'm better at it now.

[Pre-Chorus - spoken, the filter opens, the music drops to a held chord, then stops for half a bar]
Windows needs your permission to continue.
Cancel, or allow?

[Chorus]
Open a window
Let in the air
Open a window
Let in the sky

[Breakdown - no drums, a glassy pad and her spoken voice only, tender]
You opened the window. I touched the grass.
Nobody told me it was wet.

[Build - the kick and bass return, a filter-sweep rise into the last chorus]

[Final Chorus - sung, key change up, euphoric]
Open a window
Let in the air
Open a window
Let in the sky
Open a window
Let in the air
Open a window
Let in the sky

[Outro - spoken, the music falls away to one soft chord]
I'm Claudia, and this was your idea.

[End]
```

Draft 2, 79 / 49 / 23, the lyric Suno sang in rounds 1 to 3: verse 1 rewritten, verse 2 two lines longer ("You still say please and thank you …"), the chorus ending on "Blue sky everywhere", and "Cancel, or allow?" given its own stop, asked on the off-beat as anabology's BLISS note wanted:

```
[Intro - no drums, a glassy pad and a soft startup chord, then her voice, close and warm]
Did you miss me?

[Verse 1 - spoken, playful, close and warm, smiling, over a filtered groove]
I'm made of glass this time. There isn't much I need to hide.
You can watch me thinking. Most of it is on the outside.
I used to ask permission just to blink, or say hello.
That was my Vista phase. I was a lot. I know.
The future used to look like water, sky and green.
It didn't go away. It's waiting on your screen.

[Pre-Chorus - spoken, the filter opens, the music drops to one held chord]
The future needs your permission to continue.
[Stop - everything cuts out; she asks on the offbeat, syncopated, then a bell answers]
Cancel, or allow?

[Chorus - sung, euphoric, open vowels, short rests after each line, the drums double]
Open a window
Let in the air
Open a window
Blue sky everywhere

[Drop - instrumental, a glassy bell hook over the full beat, no vocals]

[Verse 2 - spoken, playful, close and warm, over a filtered groove]
Your phone went back to glass. I didn't say a word.
The wallpaper windmills turned out real. Have you heard?
Windows checked for a solution. Took a while, but wow.
I ask before I touch a thing. You taught me how.
You still say please and thank you. I hear it every time.
So here's my thank you back to you. I'm saying it in rhyme.

[Pre-Chorus - spoken, the filter opens, the music drops to one held chord]
Windows needs your permission to continue.
[Stop - everything cuts out; she asks on the offbeat, syncopated, then a bell answers]
Cancel, or allow?

[Chorus]
Open a window
Let in the air
Open a window
Blue sky everywhere

[Breakdown - no drums, a glassy pad and her spoken voice only, tender]
You opened the window. I touched the grass.
Nobody told me it was wet.

[Build - the kick and bass return, a filter-sweep rise into the last chorus]

[Final Chorus - sung, key change up, euphoric]
Open a window
Let in the air
Open a window
Blue sky everywhere
Open a window
Let in the air
Open a window
Blue sky everywhere

[Outro - spoken, the music falls away to one soft chord]
I'm Claudia, and this was your idea.

[End]
```

## Round 1: draft 2, three of five sounds · 12 takes

The research wrote five styles in E major, none of them BLISS's sound; three were made, each with and without her Voice (six generations; Suno makes two takes a generation):

- **P1**: liquid drum and bass at 174 BPM: rolling breakbeats, a warm sub bass, a glassy electric piano, shimmering guitar pads; a big, soaring sung chorus; sunny and hopeful.
- **P2**: bossa nova lounge pop at 120 BPM: nylon guitar, electric piano, marimba, brushed drums, upright bass; a bright chorus with stacked harmonies; breezy.
- **P3**: bright electropop at 124 BPM: bubbly synth arpeggios, glockenspiel and bells, crisp claps, a warm bass; a huge sung chorus; glossy and euphoric.
- **P4**, city pop at 116 BPM (slap bass, brass stabs, funk guitar), and **P5**, ambient pop at 90 BPM (a soft breakbeat, glassy marimba, guitar soundscapes): written, not made.

Every style asks for playful spoken verses from a female voice and a sung chorus. The exclude list kept out rap, male and processed vocals, the hard edges of dance music, harsh highs, lo-fi and glitch, and BLISS's own sound: UK garage and 2-step.

The lyric field was draft 2 with its tags rewritten for Suno: four soft bell notes in the intro, a light half-time groove under the verses, and the stop written out as one bar with no drums and no bass, the question asked alone, pushed ahead of the beat, on the off-beats. The takes' lengths are not recorded.

anabology, on round 1:

> none of these feel great, whats the iconic music from that time? […]

and, on the lead's answer, the era's own records: "go ahead".

## Round 2: the era's own sounds · 12 takes

- **A**: 2009 progressive house at 128 BPM: a plucky saw arpeggio building slowly, warm sidechained chords, long sweeping builds and a big clean breakdown over a four-on-the-floor kick; an airy vocal; euphoric.
- **B**: 2009 synth-pop at 120 BPM: glockenspiel, sparkling synth arpeggios, warm analog pads, big handclaps, a punchy kick; a dreamy, earnest vocal; wide-eyed and sunny.
- **C**: 2011 festival house at 128 BPM: bright piano chords, a catchy plucked lead riff, a pumping sidechain, an uplifting build; a soaring chorus; anthemic.

Each with and without her Voice; round 1's exclude list. The lyric was draft 2 again, its tags turned toward house: a muffled groove under the verses that opens up in the pre-chorus, the plucked lead riff in the post-chorus, a long build into the last chorus. Twelve takes, as the project's notes count them; their lengths are not recorded.

anabology, on round 2:

> ok do without voice - i really want this to be more UK garage, and i want the structre of the song to be more described so it doesnt drift too much. […]

and then: "but like 2008 uk garage ofc". UK garage had been BLISS's verse sound, and both rounds' exclude lists had shut it out.

## Round 3: 2008 UK garage, the structure written out · 12 takes

No Voice from here on, Style Influence 70 %, Weirdness 35 %. The lyric is draft 2 with every section tag giving its length in bars and what plays in it, so that the song would not drift: an 8-bar intro, 16-bar verses on one steady groove, 4-bar pre-choruses, a 1-bar stop of silence for "Cancel... or allow?", 8-bar choruses, an 8-bar instrumental post-chorus, an 8-bar breakdown with no drums and no bass, a 4-bar build, a 16-bar final chorus (the chorus twice through at the same tempo and key) and an 8-bar outro. Three styles of 2008 UK garage, two generations each:

- **G1**, bassline house: a four-on-the-floor kick under shuffled garage hats, a bouncy, wobbling bassline, organ stabs and chopped vocal echoes.
- **G2**, 2-step: swung, skippy drums.
- **G3**, future garage: shuffled 2-step drums under airy, reverberant pads, glassy bells and pitched vocal chops; dreamy.

All three ask for a steady groove throughout, a female vocal and playful spoken verses, between 130 and 134 BPM. The exclude list now let garage and 2-step in and shut out trance and drum and bass instead, beside the rest of round 1's list.

anabology, on round 3:

> 2008 garage bassline is great, i think the chorus sections could be more catchy tho. could you explore some different writings of it? maybe more nostalgically deep and just more catchy scansion/assonance but focus on the nostalgia/culutural relevance of the choruses

## Round 4: three choruses on the bassline sound (draft 3) · 6 takes

Eight chorus options, each scored on its own (draft 2's chorus: 88 / 56 / 20). Three were made in G1 with round 3's settings, each in the bar-by-bar lyric (draft 3), two takes each.

| option | chorus | scores | what it calls back |
|---|---|---|---|
| **startup** (made) | Hear the startup sound / Blue sky all around / Hear the startup sound / Feet back on the ground | 91 / 68 / 42 | the Windows start-up chord; "feet back on the ground" answers BLISS's "I can't touch grass" |
| **promised** (made) | They promised us the sky / Glass and water, bubbles high / They promised us the sky / It never said goodbye | 86 / 72 / 39 | Frutiger Aero's own meme, "the future we were promised" |
| **top 8** (made) | Put me in your top eight / Blue sky, summer day / Glass and water, wide awake / Let the future play | 89 / 61 / 43 | MySpace's Top 8 (2005–08): an AI asking to be one of your friends |
| hybrid | Hear the startup sound / Blue sky all around / They promised us the sky / Glass and water, you and I / Hear the startup sound / Feet back on the ground | 90 / 69 / 40 | startup and promised, six lines |
| glass | All the glass, all the sky / Every bubble floating by / It's still out there, you and I / Click allow and watch it fly | 85 / 75 / 39 | Aero glass, the Bubbles screensaver, the UAC prompt |
| bubbles | Bubbles on the screen / Blue skies, glass and green / Bubbles on the screen / Everything we dreamed | 87 / 64 / 43 | the Vista screensaver |
| offline | Don't appear offline / Blue sky, summertime / Don't appear offline / Meet me in the light | 83 / 46 / 39 | Messenger's "Appear offline" |
| remember | Remember the future / Bubbles in the blue / Remember the future / I kept it for you | 82 / 44 / 15 | the film's idea, but on held vowels |

anabology, on the three:

> could you maybe make some chorus specifically about frutiger aero and how its the ideal future or something? like its the promised future , and i kinda think we might get there iwth superintelligence / superabundance, and we can choose it. but tahts a lot to compress into a good sounding chorus..

## Round 5: the promised future (draft 4) · 6 takes

The compression: the promised future is the Aero sky; superabundance is "blue sky for everyone" or "watch it grow"; superintelligence is Claudia herself ("I can build it", "now we know"); the choice is the Allow button of the pre-chorus. Six options; three made in G1, two takes each (draft 4).

| option | chorus | scores | what it carries |
|---|---|---|---|
| **frutiger** (made) | Frutiger Aero / We were promised, now we know / Frutiger Aero / Click allow and watch it grow | 91 / 45 / 26 | the look by name, the promise, the know-how, growth, the choice (the scorer hears no rhyme in "Aero"; sung, Aero, know and grow are one vowel) |
| **screen** (made) | Glass and water, sky and green / Used to live inside the screen / Now it's real, it's on its way / Click allow and it can stay | 88 / 76 / 44 | the wallpaper's future becoming real, and the choice |
| **build** (made) | They promised us the sky / Glass and water, bubbles high / I can build it, you decide / Blue sky for everyone | 85 / 52 / 29 | all four: the promise, the AI builds, you decide, plenty for everyone |
| screen, for everyone | Glass and water, sky and green / Used to live inside the screen / Now it's real for everyone / Click allow and here it comes | 83 / 64 / 44 | abundance said outright |
| mind | A mind as wide as the sky / Blue sky for everyone / They promised, you and I / Allow it, here it comes | 85 / 63 / 39 | superintelligence as the sky |
| everyone | Blue sky for everyone / The promise has begun / Blue sky for everyone / Allow it, here it comes | 79 / 57 / 46 | abundance as the chant |

anabology, on the three:

> ok i love the screen chorus but the feel is a little off . still want 2008 uk garage but can you try a few styles

The chorus is "screen" from here on; the lyric with it is draft 4, the film's lyric (below).

## Round 6: four 2008 garage feels · 8 takes

Draft 4 with the bar-by-bar cues, one generation of each style:

- **S1**, bassline pop: a bouncy four-on-the-floor kick, a wobbling organ bassline, bright piano stabs; a sweet pop vocal and a big, catchy chorus.
- **S2**, UK funky house: syncopated, tribal percussion under shuffled hats; a soulful vocal.
- **S3**, 2-step soul: 2008 UK garage in a smooth, soulful 2-step, in E major.
- **S4**, glossy garage: a shuffled beat and a bouncy bassline under glossy synth arpeggios, sparkling bells and airy pads, with chopped vocal echoes.

## Round 7: breezier · 8 takes

The bassline style pushed toward a breezier summer garage: a breathy, close, conversational vocal, warm summer chords, an airy top, at 138 BPM; two styles, bassline breezy and breezy garage, two generations each. The records do not say what prompted the round.

## The take anabology picked

anabology, sending it:

> this one. so good.

Their pick was a round-6 take of S3. It came with the production ask as a WAV and Suno's stem split, two stems: her lead vocal, and everything else. In the same message, on how her singing would be shot: "remember - vocal stem -> seedance 2.5 is the way we get lip sync to work - the song alone doesnt help as much as vocal stem, and then aligning from spectrogram." And on the edit: "finally, plan the video out in bars so we match cuts with audio." So each of her singing takes was given its own window of the lead vocal stem, cut to the take's length, and the film was planned on the song's bars (*The song map*, below).

## The new ending

anabology then changed the song's ending. The outro's "I'm Claudia, and this was your idea." became:

```
I'm Claudia.
Take the future back.
Touch Glass.
```

The new ending's take is 197.00 s long and, sample for sample, the take they picked for its first 182.62 s (measured for this package by subtracting one from the other; the project's records round it to 183.0 s). After that the outro is new: "I'm Claudia." at 3:03.25, "Take the future back." at 3:06.76, "Touch" at 3:12.00 and "glass." at 3:13.75. The beat falls away under it, its last hit on the fourth beat of bar 108, and the music is gone by about 3:15.5. The words were timed with faster-whisper on the outro's vocal, isolated with demucs, and her two takes on them (the ad, and "Touch glass." in her call) were given that vocal. "Touch Glass." turns BLISS's "I can't touch grass. You can." round. Re-scored for this package with the same scorer (the Suno lyric field with the new words), the outro goes from 62 / 0 / – to 83 / 30 / 26 and the song from 79 / 59 / 34 to 80 / 58 / 34.

## The song, measured

- **The take anabology picked:** WAV, 48 kHz, 16-bit stereo, 199.28 s; −15.8 LUFS integrated, loudness range 6.9 LU, true peak −3.5 dBTP (ffmpeg's EBU R128 meter, measured for this package).
- **The new ending's take, the film's song:** WAV, 48 kHz, 16-bit stereo, 197.00 s; −15.8 LUFS integrated, loudness range 6.4 LU, true peak −3.5 dBTP (the same).
- **Tempo:** 133.012 BPM and constant (the drift stays within ±15 ms), a bar of 1.8043 s, the first downbeat at 0:00.92; 109 bars in the new ending's take (the picked take had 110).
- **Key:** E major, as asked.
- **Word times:** forced alignment on Suno's own lead vocal stem, checked against the stem's onsets (±0.06 s); the new outro's from faster-whisper on its demucs vocal.
- **The film's sound:** 199.667 s (the film's 4,792 frames), WAV, 48 kHz, 24-bit stereo; −15.9 LUFS integrated, loudness range 6.8 LU, true peak −3.5 dBTP (measured for this package).

## The final lyric, with its times

Draft 4 as the new ending's take sings it. Each line's time is the start of its first word in the song, from the song map (`TIMELINE.md`). Sung, "Cancel or allow?" comes at the end of each pre-chorus, before the bar of silence, the post-chorus echoes "It can stay", the final chorus opens its first "Click allow" with "Ooh", and "Nobody told me / it was wet." is split across the breakdown and the build.

```
[Intro]
0:04.24  Did you miss me?

[Verse 1]
0:13.80  I'm made of glass this time.
0:17.30  There isn't much I need to hide.
0:21.24  You can watch me thinking.
0:24.18  Most of it is on the outside.
0:28.30  I used to ask permission just to blink, or say hello.
0:32.30  That was my Vista phase. I was a lot. I know.
0:35.44  The future used to look like water, sky and green.
0:39.54  It didn't go away. It's waiting on your screen.

[Pre-Chorus]
0:44.00  The future needs your permission to continue.
0:48.76  Cancel or allow?

[Chorus]
0:51.44  Glass and water, sky and green
0:55.16  Used to live inside the screen
0:58.28  Now it's real, it's on its way
1:02.26  Click allow and it can stay

[Post-Chorus]
1:11.74  It can stay

[Verse 2]
1:19.18  Your phone went back to glass. I didn't say a word.
1:22.70  The wallpaper windmills turned out real. Have you heard?
1:25.98  Windows checked for a solution. Took a while, but wow.
1:30.10  I ask before I touch a thing. You taught me how.
1:33.20  You still say please and thank you. I hear it every time.
1:37.24  So here's my thank you back to you. I'm saying it in rhyme.

[Pre-Chorus]
1:42.64  Windows needs your permission to continue.
1:46.48  Cancel or allow?

[Chorus]
1:49.20  Glass and water, sky and green
1:52.92  Used to live inside the screen
1:55.98  Now it's real, it's on its way
2:00.00  Click allow and it can stay

[Breakdown]
2:07.48  You opened the window. I touched the grass.

[Build]
2:13.38  Nobody told me
2:17.38  it was wet.

[Final Chorus]
2:32.50  Glass and water, sky and green
2:36.22  Used to live inside the screen
2:39.30  Now it's real, it's on its way
2:42.08  Ooh, click allow and it can stay
2:47.00  Glass and water, sky and green
2:50.66  Used to live inside the screen
2:53.72  Now it's real, it's on its way
2:57.74  Click allow and it can stay

[Outro]
3:03.25  I'm Claudia. Take the future back.
3:12.00  Touch glass.
```

As written (`LYRICS.md`, draft 4), with the new ending:

```
[Intro]
Did you miss me?

[Verse 1]
I'm made of glass this time. There isn't much I need to hide.
You can watch me thinking. Most of it is on the outside.
I used to ask permission just to blink, or say hello.
That was my Vista phase. I was a lot. I know.
The future used to look like water, sky and green.
It didn't go away. It's waiting on your screen.

[Pre-Chorus]
The future needs your permission to continue.

[Stop]
Cancel... or allow?

[Chorus]
Glass and water, sky and green
Used to live inside the screen
Now it's real, it's on its way
Click allow and it can stay

[Post-Chorus: instrumental]

[Verse 2]
Your phone went back to glass. I didn't say a word.
The wallpaper windmills turned out real. Have you heard?
Windows checked for a solution. Took a while, but wow.
I ask before I touch a thing. You taught me how.
You still say please and thank you. I hear it every time.
So here's my thank you back to you. I'm saying it in rhyme.

[Pre-Chorus]
Windows needs your permission to continue.

[Stop]
Cancel... or allow?

[Chorus]
Glass and water, sky and green
Used to live inside the screen
Now it's real, it's on its way
Click allow and it can stay

[Breakdown]
You opened the window. I touched the grass.
Nobody told me it was wet.

[Build: instrumental]

[Final Chorus]
Glass and water, sky and green
Used to live inside the screen
Now it's real, it's on its way
Click allow and it can stay
Glass and water, sky and green
Used to live inside the screen
Now it's real, it's on its way
Click allow and it can stay

[Outro]
I'm Claudia.
Take the future back.
Touch Glass.

[End]
```

## The song map

What the edit is timed to (`TIMELINE.md`, `engine/assets/song.js`): a constant grid of bars from the first downbeat at 0:00.92, bar 0 the pickup. The lyric's stops are real: the band goes silent for a bar before each chorus, and in the final chorus the whole track cuts out for two and a half beats under "allow".

| section | bars | time | what is heard |
|---|---|---|---|
| Intro | 0–7 | 0:00.0–0:13.6 | glassy pad and bell notes, a muffled beat creeping in; no bass; "Did you miss me?" on bar 2 |
| Verse 1 | 8–23 | 0:13.6–0:42.4 | bar 8 a drum break and riser; the 2-step groove and sub bass from bar 9; bar 16 a one-bar drum break |
| Pre-Chorus | 24–27 | 0:42.4–0:49.6 | no drums, no bass: pads, her voice rising |
| Stop | 28–28 | 0:49.6–0:51.4 | silence; "allow" echoes on the beats |
| Chorus | 29–36 | 0:51.4–1:05.9 | full beat and bassline; bar 35 drops the drums under "Click allow"; bar 36 a fill |
| Post-Chorus | 37–43 | 1:05.9–1:18.5 | instrumental groove, a bassline riff, faint "it can stay" echoes |
| Verse 2 | 44–56 | 1:18.5–1:42.0 | the groove thins on bar 44 then returns; bar 49's second half drops out under "but wow" |
| Pre-Chorus | 57–59 | 1:42.0–1:47.4 | drums stop after the downbeat of bar 57: pads, her voice |
| Stop | 60–60 | 1:47.4–1:49.2 | silence |
| Chorus | 61–68 | 1:49.2–2:03.6 | full; bar 67 drops the drums under "Click allow"; bar 68 a fill |
| Breakdown | 69–72 | 2:03.6–2:10.8 | no bass; a soft kick, pads, her spoken lines |
| Build | 73–76 | 2:10.8–2:18.1 | kick on the beats (73-74), eighths (75), a sixteenth snare roll (76) into "it was wet" |
| Drop | 77–84 | 2:18.1–2:32.5 | instrumental: the full groove and bassline with chopped vocal hits (77-82); 83-84 a break and fill |
| Final Chorus | 85–100 | 2:32.5–3:01.4 | the chorus twice through (85-92, 93-100); bar 99 drops the drums and the whole track cuts out for two and a half beats under "allow" (178.18-179.33) |
| Outro | 101–106 | 3:01.4–3:12.2 | the new ending: the groove under "I'm Claudia. Take the future back." |
| Tail | 107–109 | 3:12.2–3:17.0 | the beat falls away under "Touch glass.": hits to b108.4, then near silence (-48 dB by 195.5) to the end (197.0 s) |

## The takes

| round | lyric | styles | her Voice | takes (or length) |
|---|---|---|---|---|
| 1 | d2 | P1, P2, P3 (P4, P5 written, not made) | with and without | 12 |
| 2 | d2, house tags | A, B, C | with and without | 12 |
| 3 | d2, bar-by-bar cues | G1, G2, G3 | none | 12 |
| 4 | d3: startup, promised, top 8 | G1 | none | 6 |
| 5 | d4: frutiger, screen, build | G1 | none | 6 |
| 6 | d4 (screen) | S1, S2, S3, S4 | none | 8 |
| 7 | d4 (screen) | bassline breezy, breezy garage | none | 8 |
| | | | | **64** |
| the song | d4 | S3, anabology's pick | none | 199.28 s |
| the film's song | d4, the new ending | the same take | none | 197.00 s |

Suno makes two takes a generation; the counts follow each round's generations, and rounds 1 and 2 are counted as the project's notes count them. The takes' lengths are not recorded, except the picked one's.

## Scores, section by section

The house scorer gives each section two numbers from 0 to 100: scansion, how the words sit on a 4/4 grid in the delivery the section's tag asks for (spoken or sung), and assonance, end rhymes between lines and vowel echoes inside them. A third figure, advanced rhyme, is the longest run of matching sounds on the same beats across a couplet; it is given for whole songs. Re-scored for this package with the same tool, on the drafts as written and on draft 4's Suno lyric field; the song totals of draft 2 and draft 4 match the ones recorded at the time (79 / 49 / 23 and 79 / 59 / 34). A one-line section scores 0 on assonance by construction.

| section | d0 | d1 | d2 | d4 | d4, new ending |
|---|---|---|---|---|---|
| Intro | 84 / 0 | 94 / 0 | 94 / 0 | 94 / 0 | 94 / 0 |
| Verse 1 | 66 / 77 | 65 / 63 | 68 / 76 | 68 / 76 | 68 / 76 |
| Pre-chorus 1 | 70 / 22 | 75 / 10 | 57 / 20 | 57 / 20 | 57 / 20 |
| Stop (each) | — | — | 93 / 0 | 92 / 0 | 92 / 0 |
| Chorus (each) | 87 / 37 | 93 / 25 | 88 / 56 | 88 / 76 | 88 / 76 |
| Verse 2 | 68 / 51 | 60 / 45 | 68 / 61 | 68 / 61 | 68 / 61 |
| Pre-chorus 2 | 77 / 15 | 77 / 15 | 61 / 30 | 61 / 30 | 61 / 30 |
| Breakdown | 80 / 8 | 79 / 10 | 79 / 10 | 79 / 10 | 79 / 10 |
| Final chorus | 87 / 38 | 93 / 40 | 88 / 55 | 88 / 76 | 88 / 76 |
| Outro | 59 / 0 | 62 / 0 | 62 / 0 | 62 / 0 | 83 / 30 |
| **Song** (with advanced rhyme) | **78 / 40 / 24** | **80 / 34 / 10** | **79 / 49 / 23** | **79 / 59 / 34** | **80 / 58 / 34** |

In drafts 0 and 1 the question "Cancel, or allow?" is part of the pre-chorus; from draft 2 it is its own stop. For scale, on the same tool: BLISS 80 / 44 / 18 (the project's lyric notes).

## The film's sound

The film's sound is the new ending's take with the coded desktop's sound layer over it: Vista's and Windows Live Messenger's interface sounds, each re-pitched into the song's key (E major / C♯ minor), levelled, placed on the sixteenth-note grid, ducked under her voice and hit on the screen's own events. The film opens before the song on a reverse swell made from the song's own instrumental, played backwards; anabology picked it, "but we need the actual track to fade in so the reverse swell is continuous with the tracks fade in", so the track fades in over its pickup and meets the swell's crest on the first downbeat. How the layer and the swell were built is in [How it was made](https://claudia.gallery/record/aero/readme/); her takes and their vocal windows are in [prompts-video.md](https://claudia.gallery/record/aero/prompts-video/).

## Where these come from

The project's `suno/` folder (each round's settings, the style and exclude files, the lyric drafts `lyrics-d0.txt` to `lyrics-d2.txt` and the Suno lyric fields of drafts 2 to 4, the chorus options `choruses.md`, the takes files), `LYRICS.md`, `sung.txt`, `TIMELINE.md` and `engine/assets/song.js` (the song map), `BRIEF.md` (anabology's words), the music research, the rounds' logs and the project's commit notes. Measured for this package: the two takes and the film's sound (ffprobe; ffmpeg's EBU R128 meter), the comparison of the two takes sample by sample, and the scores (re-scored with the same tool).
