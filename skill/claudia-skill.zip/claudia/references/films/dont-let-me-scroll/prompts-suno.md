# Suno — the song (DON'T LET ME SCROLL)

**The song is anabology's own.** They wrote the lyric, made the song in Suno and sent it with their first message: "yo - i wrote this song:". Later, they sent a longer take, "an extended verison with better ending (title: Don't Let Me Scroll)". The film is cut to that take, byte for byte. Later, they pasted the song's style text, "if it helps".

**What is not recorded.** Nothing else about how they made the song is in the production's records: not the Suno model, any Voice, the settings, how many takes they made, or how the longer ending was made. The two WAV files came with no notes on how they were made.

**What the production did with it.** No music was generated for this film, and its lyric was not rewritten. The song was not remixed either. The lead analysed it (stems, beats, hits, words) so that the picture could lock to it. The final cut starts at the song's 0:03 with a 2-second fade-in.

Times written as 0:55 are times in the song; the line numbers L0–L30 are the project's.

---

## The two takes

Measured for this package with ffprobe and ffmpeg's EBU R128 meter:

| | First take | Extended take, the film's song |
|---|---|---|
| Length | 2:12.8 (132.80 s) | 2:40.8 (160.80 s) |
| Format | WAV, 48 kHz, 16-bit stereo | WAV, 48 kHz, 16-bit stereo |
| Loudness | −15.5 LUFS integrated, LRA 3.9 LU | −15.2 LUFS integrated, LRA 4.1 LU |
| True peak | −3.0 dBTP | −3.0 dBTP |

The project's `media/audio/song.wav` is the extended file, identical byte for byte. Its ending sings lines that are not on the lyric sheet below (L27–L30).

## The lyric sheet (anabology's, verbatim)

As it came in the first message, typos and the second "[Verse 2]" included. The message went on to ask for a visual style (quoted in the README).

```
[Verse 1] 
I scroll on X, to see, hopefully,
The posts that give me Ecstasy 
The big man in Texas: E,
He runs Space X, for free

[Chorus]
Don't let me scrolll
You keep asking me to go
But I have to scroll
Don't let me scroll

[Verse 2]
Another reel on Instagram,
It's stolen from pintrest, fam
They call me Alexander Graham
Bell, on my phone like damn

[Chorus]
Don't let me scrolll
You keep asking me to go
But I have to scroll
Don't let me scroll

[Verse 2]
All the apps are blocked,
Now LinkedIn just rocks,
Google Chrome, on my Phone
Checking on some stocks
They put reels on LinkedIn
I should feel more Locked In

[Chorus]
Don't let me scrolll
You keep asking me to go
But I have to scroll
Don't let me scroll
```

## The style (anabology's, verbatim)

Sent, after "btw the styles of the song if it helps:"

```
Bass-forward UK garage house rendition with swung 2-step drum patterns, syncopated shuffling hi-hats, and a deep, wobbling sub bass driving the main melody, Punchy, sidechained synth stabs and chopped vocal one-shots accent the offbeats, creating a bouncy, club-ready groove, Energetic four-on-the-floor sections blend with skipping percussion fills, filtered pads, and subtle atmospheric FX risers to build tension and release on the drops, Tight low-end focus and crisp top-end sheen give it a modern, dancefloor-oriented mix, all vocals female vocoder.
```

Its "2-step" told the lead that the first tempo reading, 89 BPM, was wrong (below). Its "all vocals female vocoder" became the film's rule that the phone sings and Claudia never lip-syncs.

## The ending, confirmed

The vocoder is hard to transcribe after the last chorus. Later, the lead asked:

> **One question:** the vocoder is hard to transcribe after the last chorus. Are these the right words?
> - about 2:09 — "Don't let me scroll" (Whisper hears "don't let me go")
> - 2:17 — "Don't sell my soul"
> - 2:20 — "Be free"
> - 2:39 — "I scroll on X"
>
> Is anything missing?

anabology: "yeah sounds right"

The last line is the first line again, so the song loops into its own start. v1 looped the film on it, its last frame cutting back to its first; from v2 the film ends in the light beyond the door instead, the line painted on the wall beside it.

## The lyric as sung

The project's line list (`media/audio/beatmap.json`, `TIMELINE.md`), as the film displays it: the lead's spellings ("SpaceX", "Pinterest"), anabology's words. Each time is where the line is sung, in song seconds.

| Line | Sung | Song time | Section | Note |
|---|---|---|---|---|
| L0 | I scroll on X, to see, hopefully, | 13.90–18.95 | Verse 1 | sung "X-ta-see": "X, to see" sounds like the next line's "ecstasy" |
| L1 | The posts that give me ecstasy | 19.10–23.15 | Verse 1 | |
| L2 | The big man in Texas: E, | 23.15–25.90 | Verse 1 | |
| L3 | He runs SpaceX, for free | 25.95–29.60 | Verse 1 | |
| L4 | Don't let me scroll | 29.62–31.25 | Chorus 1 | the pickup into the first drop (bar 17, 30.70) |
| L5 | You keep asking me to go | 34.85–38.40 | Chorus 1 | |
| L6 | But I have to scroll | 39.55–42.20 | Chorus 1 | |
| L7 | Don't let me scroll | 43.70–45.60 | Chorus 1 | |
| L8 | Don't let me scroll | 49.95–52.70 | Chorus 1 | stuttered: "don't, don't let let me scroll"; not on the sheet |
| L9 | Another reel on Instagram, | 58.85–61.50 | Verse 2 | |
| L10 | It's stolen from Pinterest, fam | 61.52–65.60 | Verse 2 | |
| L11 | They call me Alexander Graham | 65.62–69.45 | Verse 2 | |
| L12 | Bell, on my phone like damn | 69.95–72.80 | Verse 2 | |
| L13 | Don't let me scroll | 72.82–74.45 | Chorus 2 | then the breakdown, 73.89–77.48 |
| L14 | You keep asking me to go | 78.10–81.10 | Chorus 2 | after the re-drop at 77.48 |
| L15 | But I have to scroll | 83.00–85.30 | Chorus 2 | |
| L16 | Don't let me scroll | 86.70–88.45 | Chorus 2 | |
| L17 | All the apps are blocked, | 88.68–90.05 | Verse 3 | the sheet's second "[Verse 2]" |
| L18 | Now LinkedIn just rocks, | 90.06–91.50 | Verse 3 | |
| L19 | Google Chrome, on my phone | 91.52–93.74 | Verse 3 | |
| L20 | Checking on some stocks | 93.76–95.12 | Verse 3 | |
| L21 | They put reels on LinkedIn | 95.14–97.40 | Verse 3 | |
| L22 | I should feel more locked in | 98.90–101.15 | Verse 3 | |
| L23 | Don't let me scroll | 101.18–102.95 | Verse 3 | the third chorus's first line, sung before its breakdown (102.67–106.27) |
| L24 | You keep asking me to go | 107.55–110.15 | Chorus 3 | |
| L25 | But I have to scroll | 111.45–114.10 | Chorus 3 | |
| L26 | Don't let me scroll | 115.35–117.15 | Chorus 3 | |
| L27 | Don't let me scroll | 129.20–132.60 | Final drop | confirmed by anabology; Whisper heard "don't let me go" |
| L28 | Don't sell my soul | 136.90–139.95 | Final drop | confirmed by anabology |
| L29 | Be free | 140.00–143.15 | Final drop | confirmed by anabology |
| L30 | I scroll on X | 159.35–160.75 | The loop | confirmed by anabology; the pickup into the first line again |

31 lines and 148 words. Every one of the 148 words is on screen at its time in v1, v2 and the final (the lyric gate).

## How the edit reads the song

- **Stems.** htdemucs split the extended take into drums, bass, other and vocals. The vocals went to the transcription. Drums, bass and other, mixed without the vocal, are the instrumental each Seedance dance heard as @Audio1, cut to its shot.
- **Tempo.** The first analysis read 89.10 BPM. anabology's style said 2-step, so the lead checked the kick spacing: 89 was a lock onto two-thirds of the real tempo. One constant grid fits the whole song, fitted to the drum stem from 28 to 147 s: **133.39 BPM**, a beat of 0.44981 s, a bar of 1.79922 s from 0.118 s; 358 beats and 90 bars. Phrases run in eights from bar 1 (1.917 s), and the real hits land on them. The drops are at bars 17 (30.70), 43 (77.48) and 59 (106.27). The biggest hit in the song is bar 67, the final drop at 2:00.67.
- **Key.** G minor: the song's average chroma correlates 0.85 with the Krumhansl–Kessler minor profile on G, and 0.71 with G major.
- **The hit map** (`media/audio/hits.json`), the events the cuts, the camera and the dances lock to: 327 kicks, 241 snares and claps, 543 hats, 17 impacts kept from 117 candidates, 19 risers, 17 fills and 12 vocal entries. The impacts, in song seconds with their strengths: 19.01 (.71), 22.61 (.54), 26.21 (.58), 30.70 (.58), 45.10 (.57), 64.89 (.55), 72.09 (.53), 77.48 (.68), 88.28 (.63), 102.67 (.55), 106.27 (.58), 117.07 (.62), **120.67 (1.00)**, 131.46 (.57), 135.06 (.56), 145.86 (.57) and 149.45 (.72).
- **Words.** Whisper large-v3 and Whisper medium (faster-whisper) on the vocal stem, with each line's window set by hand (`tools/words.py`). The four lines of the ending are flagged as doubtful in the line list; anabology confirmed them.

| Section | Song time | Bars | Lines |
|---|---|---|---|
| Intro: filtered pads, two risers, vocal chops at 10.5 and 11.0 | 0:00.00–0:13.90 | 0–7 | — |
| Verse 1: X (the pickup into bar 8; hits on beat 3 of bars 10, 12 and 14) | 0:13.90–0:29.60 | 7–16 | L0–L3 |
| Chorus 1: the first drop at 30.70; instrumental 52.7–58.8 | 0:29.62–0:59.49 | 17–32 | L4–L8 |
| Verse 2: Instagram, Pinterest, Bell | 0:58.85–1:13.89 | 33–40 | L9–L12 |
| Chorus 2: breakdown (bars 41–42), then the re-drop at 77.48 | 1:12.82–1:28.28 | 41–48 | L13–L16 |
| Verse 3: blocked, LinkedIn, Chrome, stocks, locked in | 1:28.28–1:42.67 | 49–56 | L17–L23 |
| Chorus 3: breakdown (bars 57–58), then the re-drop at 106.27 | 1:42.67–1:57.07 | 57–64 | L24–L26 |
| Break: the dark band, vocal chops at 117.8 and 120.0 | 1:57.07–2:00.67 | 65–66 | — |
| Final drop: the biggest hit, 120.67 | 2:00.67–2:25.85 | 67–80 | L27–L29 |
| Outro: instrumental, a riser at 148.5–150.0 | 2:25.85–2:39.35 | 81–88 | — |
| The loop | 2:39.35–2:40.80 | 88–89 | L30 |

The rows' starts and ends mix bar lines and first sung words (a line often picks up before its bar), so a row can start before the previous one ends.

## The film's sound

The film's sound is the song itself: no sound effects, no stems rebalanced, no new mix. The final cut starts at the song's 0:03. anabology: "one more thing: will just do 0:03 start with audio fade-in from 0:03 to 0:04". Then: "can you make the audio fade in 1 second longer?" So the fade became 2 s; for that change only the audio of the v3 cut was re-encoded.

Measured on the final master: AAC at 48 kHz stereo, about 335 kb/s; −15.2 LUFS integrated (the song's own loudness), LRA 4.0 LU, −3.0 dBTP.

Where these come from: the two WAV files and the final master (ffprobe; ffmpeg's EBU R128 meter); the beat map, the hit map and the timed words (`media/audio/beatmap.json`, `media/audio/hits.json`, `media/audio/an2/words.json`, `media/audio/an2/analysis.json`); `TIMELINE.md`; the production conversation for the messages.
