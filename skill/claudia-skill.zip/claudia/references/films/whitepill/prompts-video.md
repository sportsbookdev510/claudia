# WHITEPILL: every video prompt

The record of every video generation made for WHITEPILL, the seventh Claudia music film by anabology: the previz takes of MiniMax H3, the reshoots of Wan 3.0 Prime, the tests and masters of Seedance 2.5 and Kling 4.0, with the image edits and shader renders that fed them. Each prompt is given word for word ([…] marks a cut); where many prompts share a template, the template is given once and each job its own parts. It was made 18–22 October 2026. The director's words are quoted as typed.

anabology, before any picture existed: "instead of seeing any animation we make at all on screen, it all being some pipeline like: 1- midjourney edit gets a prompt that defines the general composition with our image and it edits on a beautiful (but illegible) animation composition 2- we repaint over the composition with code and animate it 3- we re-light / re-render the animation with Wan 3.0 for example entirely So the end is pure video model, and all visual design decisions made by image models rather than you, but we make it precise". With the song locked: "i want you to basically shoot the entire video twice […] i think one great thing about seedance is that you can take something thats already been made, and use seedance 2.5 to re-render the entire scene with way more description […]". The film ended as that idea turned around: a previz performer in a green balaclava (H3), then Seedance 2.5 drawing every shot of hers from words, with Suno's own vocal stem for the lip sync, and the worlds without her written as shaders and repainted by Seedance.

**Prices.** Costs are at list price, from the project's ledgers. Higgsfield's API (Wan 3.0 Prime and Seedance 2.5): the ledger's estimate per request, at one rate a second for the output and the input video alike: Wan 3.0 Prime at $0.068, $0.14 and $0.28 a second at 480p, 720p and 1080p, Seedance 2.5 at 0.6 × $0.2056, $0.4622 and $1.1372. The ledger did not count the input video's seconds until section 7; entries before it give that figure too, "with the input video's seconds". Replicate (Seedance 2.5): per output second, $0.1028 at 480p without a video input and $0.4304 with one, $0.9676 at 720p with one; Replicate does not bill a request that fails or is refused, though the ledger lists it. The takes of Seedance 2.5 on Higgsfield (References), her shots in the final shoot, and of Kling 4.0 on Higgsfield are given in seconds. MiniMax H3's cost is not recorded. Image edits (GPT Image 2.5) as the image API reported them.

**The order of work.** The song locked and the video asked for; the first H3 takes (section 1); the go for the whole film, H3 then Wan 3.0 Prime over it (sections 1 and 3); the first half on the song (section 3); the rollout cut (section 5); the reset, with the shader worlds and the film on the bar map (section 6); previz 15 approved for the shoot (section 1) and the Wan cut (section 7); the Suno-stem method (section 8); the look chosen (section 9); the final shoot, v1, then v2a and v2b, then the final cut, v3 (section 10).

**Totals by section** (takes = video files that came back; costs at list for the requests that ran):

| § | Phase | Jobs | Requests | Takes | Cost at list | In the final cut |
|---|---|---|---|---|---|---|
| 1 | MiniMax H3 previz | 10 batches | 158 (1 failed) | 157 | not recorded | none (9 were guides of final takes) |
| 2 | Seedance and Wan over the first H3 takes | 13 | 12 (1 refused or failed) + 1 on Replicate (refused) | 11 | $7.32 at list; $17.17 with the input videos; Replicate: refused, not billed | none |
| 3 | Wan 3.0 Prime, the first film pass | 12 | 15 | 15 | $26.32; $52.22 with the input videos | none |
| 4 | Take 8: animation, lyrics, grey boxes | 10 | 11 (1 refused or failed) | 10 | $19.98 at list; $39.91 with the input videos | none |
| 5 | Wan 3.0 Prime, the rollout | 20 | 22 (2 refused or failed) | 20 | $33.18 at list; $65.37 with the input videos | none |
| 6 | The shader world through Wan | 1 | 2 (1 refused or failed) | 1 | $2.10 at list; $4.20 with the input videos | none |
| 7 | Wan 3.0 Prime, the v10 reshoot | 27 | 27 (2 refused, no take) | 25 | $132.42 at list | none |
| 8 | S01 five ways: Seedance and Wan, Higgsfield (API); Kling 4.0 on Higgsfield | 6 + 6 Kling | 6 + 6 Kling (1 refused) | 6 + 5 | $36.94; Kling 95 s asked | none |
| 9 | Replicate: the face check and the look tests | 10 | 10 (1 refused) | 9 | $97.17 ($97.58 listed) | none |
| 10 | Final shoot: her shots, Seedance 2.5 on Higgsfield (References) | 48 | 49 (7 refused) | 42 | 460 s asked, 412 s in takes | 20 |
| 10 | Final shoot: shader scenes, Seedance 2.5 on Replicate | 16 | 19 (3 failed) | 16 | $141.27 ($158.69 listed) | 7 |

**Totals by model and route:**

| Model and route | Jobs | Requests | Takes | Cost at list | In the final cut |
|---|---|---|---|---|---|
| MiniMax H3 | 157 takes in 10 batches | 158 (1 failed) | 157 | not recorded | 0 |
| Wan 3.0 Prime, Higgsfield (API) | 74 | 81 (6 refused or failed) | 75 | $221.18 at list; $300.09 with the input videos' seconds | 0 |
| Seedance 2.5, Higgsfield (API) | 14 | 14 (1 failed) | 13 | $37.08 at list; $48.14 with the input videos' seconds | 0 |
| Seedance 2.5, Replicate | 27 | 30 (5 failed or refused) | 25 | $258.44 in the ledger, of which $20.00 for the five that Replicate does not bill: $238.44 | 7 |
| Seedance 2.5, Higgsfield (References) | 48 | 49 (7 refused) | 42 | 460 s asked, 412 s in the takes | 20 |
| Kling 4.0, Higgsfield (edit and references modes) | 6 | 6 (1 refused) | 5 | 95 s asked, 79 s in the takes | 0 |
| **Total, the API routes** | | | | **$496.70** at list from the ledgers, for the requests that ran; $586.67 if Higgsfield's input-video seconds are counted too | 27 |

The image edits that fed these jobs (GPT Image 2.5): the v10 keyframes and a wheat plate $1.92 (30 edits, `shots/ledger-img.jsonl`), the rollout's lyric stills $8.99 (153 edits), the shader and look stills of the final shoot $1.52 (28), the empty places $0.86 (19) and the masked S01 keyframe $0.05, as the image API reported them.

**The final cut** (v3; `tools/film/v10/sd_picks_v3.json`): 27 takes on the song's bar map, every one Seedance 2.5, 20 of her shots on Higgsfield (References) and 7 shader scenes on Replicate. S20 is split at bar 88 into the paper objects and the clouds.

| Shot | Bars | Song time | Take | Route | What it is |
|---|---|---|---|---|---|
| S01 | 1–9 | 0:00.00–0:15.54 | sdf-S01 | Higgsfield (References) | v1, over the masked Wan previz |
| S02 | 9–15 | 0:15.55–0:27.17 | rsf-S02b | Replicate | v1, the farming ark |
| S03 | 15–17 | 0:27.16–0:31.04 | sdf-S03d | Higgsfield (References) | v2, no guide |
| S04 | 17–20 | 0:31.02–0:36.81 | sdf-S04d | Higgsfield (References) | v2, no guide |
| S05 | 20–24 | 0:36.83–0:44.58 | sdf-S05d | Higgsfield (References) | v2, no guide |
| S06 | 24–27 | 0:44.56–0:50.36 | sdf-S06 | Higgsfield (References) | v1, over its H3 take |
| S07 | 27–33 | 0:50.37–1:01.99 | sdf-S07 | Higgsfield (References) | v1, over its H3 take |
| S08 | 33–39 | 1:01.99–1:13.57 | sdf-S08d | Higgsfield (References) | v2, no guide |
| S09 | 39–47 | 1:13.59–1:29.01 | sdf-S09g | Higgsfield (References) | v3, dancing, not singing |
| S11 | 47–49 | 1:28.99–1:32.82 | sdf-S11s | Higgsfield (References) | v1 |
| S11b | 49–50 | 1:32.83–1:34.75 | sdf-S11bs | Higgsfield (References) | v1 retake, no guide |
| S12 | 50–53 | 1:34.76–1:40.55 | rsf-S12h | Replicate | v1, over the Earth |
| S13 | 53–55 | 1:40.53–1:44.36 | sdf-S13 | Higgsfield (References) | v1, over its H3 take |
| S14 | 55–59 | 1:44.38–1:52.09 | sdf-S14 | Higgsfield (References) | v1, over its H3 take |
| S15 | 59–63 | 1:52.06–1:59.73 | sdf-S15 | Higgsfield (References) | v1, over its H3 take |
| S16 | 63–67 | 1:59.76–2:07.42 | sdf-S16d | Higgsfield (References) | v2, no guide |
| S17 | 67–69 | 2:07.43–2:11.26 | rsf-S17 | Replicate | v1, the first tree |
| S18 | 69–77 | 2:11.26–2:26.60 | sdf-S18g | Higgsfield (References) | v3, dancing, not singing |
| S19 | 77–83 | 2:26.56–2:38.02 | sdf-S19d | Higgsfield (References) | v2, the dance in words |
| S20a | 83–88 | 2:38.02–2:47.52 | rsf-S20f | Replicate | v2, from the 1080p render |
| S20b | 88–90 | 2:47.56–2:51.39 | rsf-S20w | Replicate | v3, the white clouds |
| S21 | 90–95 | 2:51.38–3:00.92 | rsf-S21f | Replicate | v2, from the 1080p render |
| S22 | 95–99 | 3:00.91–3:08.49 | sdf-S22 | Higgsfield (References) | v1, over its H3 take |
| S23 | 99–107 | 3:08.52–3:23.77 | sdf-S23d | Higgsfield (References) | v2, the dance in words |
| S24 | 107–111 | 3:23.73–3:31.32 | sdf-S24r | Higgsfield (References) | v1 |
| S25 | 111–115 | 3:31.35–3:38.97 | sdf-S25 | Higgsfield (References) | v1, over its H3 take |
| S26 | 115–123 | 3:38.96–3:54.79 | rsf-S26 | Replicate | v1, out of the nested capsules |

**How to read an entry.** The heading is the job's name (and "in the final cut" where it is); then the model, length, resolution, sound and cost ("submitted twice" where a job went out twice); then its inputs, its take or takes, the cuts it played in (v1, v2a, v2b, v3), and what came of it. In prompts, ⟨NAME⟩ is a slot of the template above it, ⟦W1⟧ a shared paragraph printed once at the start of its section, and ⟨…⟩ a run of sentences unchanged from the prompt it is compared with. The references a prompt names are the model's own tags: @Image1 and @Video1 in Seedance on Higgsfield, [Image1] on Replicate, Image 1 and Video 1 in Wan, `<Picture 1>` in H3, [Image 1] in Kling.

**Sections.** 1. MiniMax H3: the previz performer · 2. Over the first takes: Seedance and Wan as a fix pass · 3. Wan 3.0 Prime: the first film pass · 4. Take 8: animation, lyric stills and grey boxes · 5. Wan 3.0 Prime: the rollout · 6. The reset: a shader world through Wan · 7. Wan 3.0 Prime: v10, every shot reshot · 8. S01 five ways · 9. Replicate: her face refused, and the Wes Anderson look tests · 10. The final shoot · 11. The stills that fed the video jobs · 12. The shader scenes.

## 1. MiniMax H3: the previz performer

MiniMax H3 was used in its reference-to-video-with-audio mode: reference pictures (`<Picture 1>` …), at most one reference video used for motion only (`<Video 1>`, a dancer) and one audio track (`<Audio 1>`) that the take copies as its soundtrack while her lips follow it (`fully_copy`). Every take was 1344 × 768 at 24 fps, with a seed; the longest were 15.08 s. A cut detector checked every take, and only takes without a hard cut were kept (anabology, when a Wan pass kept a take's cuts: "ok it still cut so we'll need to just do h3 til we get them without cuts"). The prompts use the structured format of MiniMax's prompt guide for H3: `subject_definitions`, `summary`, `retention_analysis`, `detailed_description` (ending in `[Shot 1]`), `overall_soundscape`, `non_diegetic_music`; the sung words sit in `<d>[English] …</d>`. Every take was previz: none is in the final cut, but the v10 takes were the low-resolution guides of the first Seedance shoot (section 10), and nine of the takes they guided are in the final cut (S06, S07, S11, S13, S14, S15, S22, S24, S25).

anabology, before the first take, on the camera: "One thing I love is - can you look at the camera movement long continuous shot tests? I want the most of those we can (+lip sync) - like I love really creative many-angled shots, the camera should feel like it's on an industrial robotic arm with how unreal the camera movements should be. Show me some tests of that in context […] so we can align".

**The batches**, in the order they ran, counted from the takes kept in the project and the cut detector's results. "Cut" means the detector found a hard cut in the take.

| Batch | Takes | What it tried | Result |
|---|---|---|---|
| Set 1: chorus, intro, white pill | 6 | robot-arm long takes with lip sync; four face crops and one Midjourney plate | "this is great"; chorus seed 2 and intro seed 1 cut |
| The verse | 2 | the stone zero and the leather jacket | both cut-free |
| Beat tests | 4 | camera stops timed to the beat: timestamps with the vocal, timestamps with the full mix, "dance to the beat" with the mix | the timestamped mix takes cut; the others cut-free |
| Green-screen plate | 2 | the chorus as a VFX plate: a green suit and hood in a green studio, a green stand-in box for the tram | cut-free; seed 1 went to sd-chags-edit |
| Green suit on location | 4 | the green-suit performer in the real orchard, dancing; the vocal or the full mix as `<Audio 1>` | seed 1 (vocal) went to wanp-chagsw-a/b and sd-chagsw-a |
| Dance references | 3 | a real dancer as `<Video 1>`, each clip cut to 640 × 360 | three cut-free takes |
| The film in 21 takes (T01–T21) | 24 | the whole song as 21 long takes; seed 2 for takes that cut | T15 and T16 cut at both seeds; T18's seed 1 failed |
| Take 8: performer and outfit | 10 | a performer in a loose costume, a cropped shirt, three outfits, the A1 dress with the face sheet, single pictures, a new dancer and a full balaclava | v8 became the recipe: "I actually like it better" |
| v9: the film on take 8's recipe | 42 | the 21 takes at seeds 1 and 2 | T01 s1, T08 s2 and T19 s2 cut; picks in `media/film/picks_v9.json` |
| v10: her 20 shots on the bar map | 60 | one take per shot, calm camera written in bars; seeds 1, 2–3, 11–17 | S03 cut at seeds 1–2, S23 at seed 12; picks in `tools/film/v10/h3_picks.json` |
| **Total** | **157** | | |

### Set 1 and the tests before the film

References: `<Picture 1>`–`<Picture 4>` four close-up crops of her face, `<Picture 5>` the Midjourney plate of the place (mirrored so her streak falls on the canon side); `<Audio 1>` the song's vocal for the window, from the project's own stem separation. The chorus take (`cha`, 15.08 s, from song 73.59 s) in full:

```
subject_definitions:
<Subject 1> is the woman whose face, hair and thin headset microphone come from <Picture 1>, <Picture 2>, <Picture 3> and <Picture 4>, four photographs of the same woman, and are kept exactly as pictured, including her glossy black blunt jaw-length bob with heavy straight bangs and the single clay-orange streak in her bangs on her right side; she also wears a small flat clay-orange eight-pointed star hair clip above her left ear. The clothing and backgrounds of those four pictures are not used.
<Subject 2> is her outfit: the sleeveless cream ribbed-knit top with a high round neck from <Picture 5>, worn with high-waisted coral-red wide-leg trousers and a thin coral belt.
<Subject 3> is the place from <Picture 5>: a little white rounded tram car standing on a single narrow rail among the rows of an apple orchard full of red apples, in low golden sunlight, inside an enormous space colony whose land curves up on both sides and closes overhead. The woman's face and hair in <Picture 5> are not used.
<Audio 1> is the sung lead vocal of <Subject 1> (S1), a soft, breathy, intimate female pop voice singing four short lines over silence, and it is reused 1:1 as the complete final audio track.

summary:
[reference generation + audio reuse] The 15.08-second target video is one single continuous take with no cuts: <Subject 1> wearing <Subject 2> stands beside the white tram in the orchard of <Subject 3> at golden hour and sings <Audio 1>, while the camera, mounted on a high-speed industrial robotic arm, flies around her through many very different angles with impossible machine precision.

retention_analysis:
<Subject 1> (appears in [Shot 1]): fully_preserved - her face, her hair with its single clay-orange streak on her right side, the star clip above her left ear and the headset microphone are retained exactly as in the pictures, rendered as a natural full-colour photograph.
<Subject 2> (appears in [Shot 1]): fully_preserved - the cream knit top and the coral trousers are retained.
<Subject 3> (appears in [Shot 1]): fully_preserved - the white tram, the orchard and the land curving overhead are retained.
<Audio 1>: fully_copy - <Audio 1> is reused 1:1 as the target video's complete final audio track, and the mouth movements of <Subject 1> follow its sung lines.

detailed_description:
The target video is in a live-action, cinematic music-video style shot on 35mm film with fine grain and warm 1970s colour, in low golden sunlight with soft haze. It is one single continuous take with no cuts. The camera is mounted on a high-speed industrial robotic motion-control arm: it moves with an impossible, machine-precise speed and smoothness that no human operator could achieve. Every move whips fast between two viewpoints and then decelerates smoothly to a dead, precise stop, with no shake, jitter or wobble anywhere in the take.
[Shot 1] The take opens on an extreme close-up of her lips and the thin headset microphone as she begins to sing. The arm whips back and up in one fast arc to a high top-down view looking straight down on her and the white roof of the tram among the green orchard rows, and stops precisely. It swoops down in a fast spiral around her and decelerates into a low angle at her knees, looking up past her face to the land curving overhead, where white towns, orchards and wheat fields hang upside down in the hazy sky. It snaps sideways in a fast lateral slide to her profile and stops exactly on the star clip in her hair. It rolls the horizon a quarter turn as it orbits behind her and around her left side, then lands in a frontal medium close-up as she sings straight into the lens. Finally it races backward along the rail and rises into a wide shot where she is a small figure beside the tram, with the whole curving world above her, and holds there. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips, jaw and cheeks moving in exact sync with every syllable of the copied track: <d>[English] Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income. The most likely outcome.</d> She sings with calm, warm, amused confidence, swaying gently with the rhythm, and her mouth closes in the short pauses between the lines.

overall_soundscape:
<Audio 1> is reused 1:1 as the complete final audio track, carrying her sung lines and the silence around them exactly as recorded. No wind, footsteps, whoosh or other sounds are added.

non_diegetic_music:
No score is added; <Audio 1> remains the complete final audio track.
```

The other tests use the same format. Each entry gives its new subject lines and its `[Shot 1]`, and names the lines already shown; its summary, retention and soundscape lines restate the subjects in H3's terms, as cha's do. The beat tests also describe the camera as "dancing to the music at 124 beats per minute: one beat lasts 0.48 seconds and one bar of four beats lasts 1.93 seconds", and the green-screen plate's description is a VFX studio with "a regular grid of small white cross-shaped tracking markers".

**WP_int (the intro, 8.00 s, seeds 1–2)**: seed 1 cut at 0.29 s, seed 2 cut-free. <Subject 1> as in cha.

```
<Subject 2> is her outfit from <Picture 5>: a sleeveless cream linen summer dress with a thin brown leather belt.
<Subject 3> is the place from <Picture 5>: a curved cream-white bedroom with a low bed of white linen and one huge round window, through which green fields, orchards and white towns climb up and curve overhead inside an enormous space colony, under long strips of window letting in morning sun. The woman's face and hair in <Picture 5> are not used.
[Shot 1] The take opens on an extreme close-up of one of her eyes as it opens. The arm whips back and up over the bed in one fast arc to a top-down view looking straight down on her hands as they fold a pair of white socks into a neat square on her lap, and stops precisely. It then sweeps low and fast past the huge round window, where the land curves up and overhead in the morning haze, and swings around to land in a frontal medium close-up of her as she turns to the lens. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips, jaw and cheeks moving in exact sync with every syllable of the copied track: <d>[English] Skynet woke up folding socks. Wake up, babe, new ending dropped.</d> She sings the second line straight into the lens with a small, amused, knowing smile, and her mouth closes in the pause between the lines.
```

**WP_wpl (the white-pill lines, 8.00 s, seeds 1–2)**: both cut-free. <Subject 1> as in cha.

```
<Subject 2> is her outfit from <Picture 5>: a sleeveless cream ribbed-knit top with a high round neck and a cream knee-length skirt with a coral belt.
<Subject 3> is the place from <Picture 5>: a vast meadow of golden wheat and coral poppies at golden hour, where two giant glossy capsule-shaped sculptures, each several storeys tall, stand upright in the field, a blue one on the left and a red one on the right, with the woman standing in the field between them. The woman's face and hair in <Picture 5> are not used.
[Shot 1] The take opens high above the meadow on a perfectly symmetrical view: the blue capsule on the left, the red capsule on the right, and <Subject 1> a small figure in the wheat exactly between them. The arm dives straight down the centre line at high speed and decelerates to a precise stop on a frontal medium shot of her as she sings. It whips in a fast half-orbit around her, the giant capsules sliding past behind her, and stops on a low angle looking up at her as she raises her open palm with a small white pill on it toward the lens. It then glides in to a close-up of her face beside the white pill as she sings the last line straight into the lens. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips, jaw and cheeks moving in exact sync with every syllable of the copied track: <d>[English] Red pill, blue pill. I'm the white pill. Smarter than you, love you still.</d> She sings with calm, warm, amused confidence, and her mouth closes in the short pauses between the lines.
```

**WP_v1 (the verse at the stone zero, 8.00 s, seeds 1–2)**: both cut-free. <Subject 1> as in cha.

```
<Subject 2> is her outfit from <Picture 5>: a sleeveless cream cable-knit top with a high round neck and high-waisted coral-red wide-leg trousers.
<Subject 3> is the place from <Picture 5>: a vast sunlit meadow of golden wheat and coral poppies under a hazy cream sky, where giant weathered white stone monuments stand: on the left a huge carved stone ring in the shape of the numeral zero, taller than a person, with a black leather jacket hanging from its top, and on the right a long row of huge carved stone numerals. The woman's face and hair in <Picture 5> are not used.
[Shot 1] The take opens on a low view skimming fast just above the poppies toward her as she walks, and it decelerates to a precise stop on a frontal medium close-up as she sings the first line. The arm whips up and around her in a fast arc to a high three-quarter view looking down on her, the stone zero and the leather jacket below, and stops precisely. It then dives fast and flies straight through the hole of the giant stone zero, the rough carved stone rushing past the lens on every side, and decelerates on the far side into a close-up of her face as she turns to the lens and sings the second line with a perfectly straight, deadpan face. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips, jaw and cheeks moving in exact sync with every syllable of the copied track: <d>[English] Half of you fear I'll end the human race. Zero, says the leather jacket, with a straight face.</d> Her mouth closes in the pause between the lines.
```

**WP_b8ts_vox (8 s from song 73.59 s, the camera's stops as timestamps on the beat grid, the vocal as `<Audio 1>`)**: cut-free. <Subject 1> as in cha; <Subject 3> as in cha.

```
<Subject 2> is her outfit: the white sleeveless ribbed tank top from <Picture 5>, worn with high-waisted orange wide-leg trousers and a thin orange belt.
[Shot 1] From 00:00.000 to 00:01.900, the camera whips in a fast arc from her left profile around to the front of her face and stops dead in a close-up exactly on the downbeat at 00:01.900. From 00:01.900 to 00:03.830, without any cut, the same move continues: on that downbeat the arm snaps straight up to a high top-down view of her whole body standing on the front of the white tram among the orchard rows, bouncing slightly closer on every beat, and stops dead at 00:03.830. From 00:03.830 to 00:05.760, still in the same unbroken move and twice as fast, the camera dives in two quick drops that land on the beats at 00:04.790 and 00:05.760, ending on a low angle at her knees looking up past her face to the land curving overhead. From 00:05.760 to 00:07.690, without any cut, the camera orbits half way around her in the opposite direction and stops dead in a frontal close-up exactly on the downbeat at 00:07.690, then holds still on her face to the end.
```

**WP_b8ts_mix (the same with the full mix as `<Audio 1>`, seeds 1–2)**: 2 cuts at seed 1, 1 cut at seed 2. <Subject 1> as in cha; <Subject 2> as in beat8_ts_vox; <Subject 3> as in cha; [Shot 1] as in beat8_ts_vox.

**WP_b8free_mix (no timestamps, "dance to the beat", the full mix)**: cut-free. <Subject 1> as in cha; <Subject 2> as in beat8_ts_vox; <Subject 3> as in cha.

```
[Shot 1] The camera dances to the beat of the music in <Audio 1>: on every downbeat (every 1.93 seconds) it changes direction, and between downbeats it whips fast and stops dead exactly on the beat. It whips from her profile to a close-up of her face, snaps straight up to a high top-down view of her whole body standing on the front of the white tram among the orchard rows, dives in two quick drops to a low angle at her knees looking up at the land curving overhead, and orbits half way around her in the opposite direction to end on a frontal close-up of her face.
```

**WP_chags (the chorus as a green-screen plate, seeds 1–2; no place picture)**: cut-free.

```
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, <Picture 2>, <Picture 3> and <Picture 4>, four photographs of the same woman. In the target video she is a performer in a visual-effects suit: a skin-tight, matte chroma-key green full-body suit with a matte green hood that covers her head, her hair, her ears and her neck completely; only her eyes and her lips show through two openings in the hood. The hair, clothing and backgrounds of those four pictures are not used.
[Shot 1] The take opens on an extreme close-up of her lips through the opening of the green hood as she begins to sing. The arm whips back and up in one fast arc to a high top-down view looking straight down on her whole body standing on the front of the green stand-in box, the white tracking crosses on the green floor around her, and stops precisely. It swoops down in a fast spiral around her and decelerates into a low angle at her knees, looking up past her face at the green ceiling. It snaps sideways in a fast lateral slide to her profile and stops exactly beside her head. It rolls the horizon a quarter turn as it orbits behind her and around her left side, then lands in a frontal medium close-up as she sings straight into the lens, her eyes moving from the distance to the lens. Finally it races backward along the green rail and rises into a wide shot where she is a small green figure on the box in the middle of the green studio, and holds there. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips and jaw moving in exact sync with every syllable of the copied track: <d>[English] Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income. The most likely outcome.</d> Her eyes are expressive and alive: they glance around, look up, and find the lens on the close-ups; she sings with calm, warm, amused confidence, swaying gently with the rhythm, and her lips close in the short pauses between the lines.
```

**WP_chagsw_vox (the green-suit performer on location, the vocal, seeds 1–2)**: seed 1 cut-free. <Subject 1> as in cha_gs.

```
<Subject 2> is the place from <Picture 5>: a little white rounded tram car standing on a single narrow rail among the rows of an apple orchard full of red apples, in low golden sunlight, inside an enormous space colony whose land curves up on both sides and closes overhead. The woman in <Picture 5> is not used.
[Shot 1] <Subject 1> dances the whole time, full of life: her hips, shoulders and arms move with the rhythm, she steps and turns along the open front platform of the white tram, holds the edge of its roof and leans out over the orchard rows, reaches up to pick a red apple from a branch and tosses it in her hand, spins once, and points at the lens. The take opens on an extreme close-up of her lips through the opening of the green hood as she begins to sing. The arm whips back and up in one fast arc to a high top-down view of her whole body dancing on the front of the white tram among the green orchard rows, and stops precisely. It swoops down in a fast spiral around her and decelerates into a low angle at her knees, looking up past her to the land curving overhead, where white towns, orchards and wheat fields hang upside down in the hazy sky. It snaps sideways in a fast lateral slide to her profile as she leans out from the tram. It rolls the horizon a quarter turn as it orbits behind her and around her left side, then lands in a frontal medium close-up as she sings straight into the lens and points at it. Finally it races backward along the rail and rises into a wide shot where she is a small green figure dancing on the front of the tram, with the whole curving world above her. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips and jaw moving in exact sync with every syllable of the copied track: <d>[English] Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income. The most likely outcome.</d> Her eyes are expressive and alive; her lips close in the short pauses between the lines.
```

**WP_chagsw_mix (the same with the full mix, seeds 1–2)**: seed 1 cut-free, seed 2 cut at 9.75 s. <Subject 1> as in cha_gs; <Subject 2> as in cha_gsw_vox; [Shot 1] as in cha_gsw_vox.

**WP_chadance (the same with a real dancer as `<Video 1>`: disco steps, electro-swing, house; the clips at 640 × 360)**: cut-free. <Subject 1> as in cha_gs; <Subject 2> as in cha_gsw_vox.

```
<Video 1> is a real dancer filmed on a still camera, used only for her dance: her steps, her arm, hip and shoulder movements, her rhythm and her energy. Her face, body, clothes, the room and the camera of <Video 1> are not used.
[Shot 1] <Subject 1> dances the whole time with exactly the moves and the timing of the dancer in <Video 1>, smooth, natural and well-formed, with whole arms, legs and hands, on the open front platform of the white tram and beside it on the path between the orchard rows. The take opens on an extreme close-up of her lips through the opening of the green hood as she begins to sing. The arm whips back and up in one fast arc to a high top-down view of her whole body dancing on the front of the white tram among the green orchard rows, and stops precisely. It swoops down in a fast spiral around her and decelerates into a low angle at her knees, looking up past her to the land curving overhead, where white towns, orchards and wheat fields hang upside down in the hazy sky. It snaps sideways in a fast lateral slide to her profile as she leans out from the tram. It rolls the horizon a quarter turn as it orbits behind her and around her left side, then lands in a frontal medium close-up as she sings straight into the lens and points at it. Finally it races backward along the rail and rises into a wide shot where she is a small green figure dancing on the front of the tram, with the whole curving world above her. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips and jaw moving in exact sync with every syllable of the copied track: <d>[English] Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income. The most likely outcome.</d> Her eyes are expressive and alive; her lips close in the short pauses between the lines.
```

The beat tests (camera stops found by optical flow and matched to the beat grid, `tools/h3/cambeat.py`): H3 made the moves in the order written but mostly not at the written times; in the two best takes 4 of 9 and 6 of 10 stops landed within 80 ms of a beat, against about 1 in 3 by chance; the full mix as `<Audio 1>` put more stops on the beat but added hard cuts; the vocal-only take jumped to another outfit and set in its last 1.5 s; "dance to the beat" alone was at chance. The green-screen plate kept her motion but gave the redraw nothing to stand on; anabology, after its redraw (section 2), asked for "the greenscreen model but in the real world, dancing, moving, etc - doing the entire thing". The dance clips were clips of adult dancers from public dance videos, cut on a downbeat and re-timed to the song's tempo; two of the first three were dropped on review.

### The film in 21 long takes

anabology's go, after the dance tests: "[…] i approve that longer version - all h3 […] previz then wan 3.0 prime reshoots of the entire video post animation. remember, describe the animation lighting changes in depth - for example (untextured) -> liquid glass, or (untextured / black) -> hippie scrapbook art etc. etc. (dont need to use those just themes you can describe) and define how it's re-lit specifically, e.g. the lighting effects (shoudl add lighting effects). Go ahead."

The song was cut into 21 long takes, T01–T21, each starting on a beat in a vocal gap (`tools/film/takes.py`, `tools/film/gen_h3.py`). The performer was a green-suit stand-in with only her eyes and lips showing, so that the video model would draw her face later. References: the same four face crops, the take's Midjourney plates as `<Picture 5…>`, a dance clip as `<Video 1>` on the dance takes (T02 and T07 disco steps; T08, T12 and T18 a 1970s disco class), the vocal window as `<Audio 1>`. T08's prompt as rendered (kept by the audit of the performer):

```
subject_definitions:
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, <Picture 2>, <Picture 3> and <Picture 4>, four photographs of the same woman. In the target video she is a performer in a visual-effects suit: a skin-tight, matte chroma-key green full-body suit with a matte green hood that covers her head, her hair, her ears and her neck completely; only her eyes and her lips show through two openings in the hood. The hair, clothing and backgrounds of those four pictures are not used.
<Subject 2> is the place from <Picture 5>: a vast meadow of golden wheat and coral poppies at golden hour where two giant glossy capsule-shaped sculptures, each several storeys tall, stand upright in the field, a blue one on the left and a red one on the right. Any person shown in <Picture 5> is not used.
<Video 1> is a real dancer filmed on a still camera, used only for her dance: her steps, her arm, hip and shoulder movements, her rhythm and her energy. Her face, body, clothes, the room and the camera of <Video 1> are not used.
<Audio 1> is the sung lead vocal of <Subject 1> (S1), a soft, breathy, intimate female pop voice singing 4 short lines over silence, and it is reused 1:1 as the complete final audio track.

summary:
[reference generation + audio reuse] The 12.96-second target video is one single continuous take with no cuts, filmed on location in <Subject 2>: <Subject 1>, the performer in the green chroma-key suit and hood, sings and moves through the scene while the camera, mounted on a high-speed industrial robotic arm, flies around her through many very different angles with impossible machine precision.

retention_analysis:
<Subject 1> (appears in [Shot 1]): fully_preserved - her eyes, eyebrows and lips are retained as in the pictures, seen through the openings of the green hood; everything else of her is covered by the matte green suit and hood.
<Subject 2> (appears in [Shot 1]): fully_preserved - the place and everything in it are retained.
<Video 1>: motion only - the dance of <Subject 1> follows the dancer in <Video 1>, move for move and in time.
<Audio 1>: fully_copy - <Audio 1> is reused 1:1 as the target video's complete final audio track, and the lip movements of <Subject 1> follow its sung lines.

detailed_description:
The target video is in a live-action, cinematic music-video style shot on 35mm film with fine grain and warm 1970s colour, in low golden sunlight with soft haze, on location; the only unusual thing in it is the performer's plain green visual-effects suit. It is one single continuous take with no cuts. The camera is mounted on a high-speed industrial robotic motion-control arm: it moves with an impossible, machine-precise speed and smoothness that no human operator could achieve. Every move whips fast between two viewpoints and then decelerates smoothly to a dead, precise stop, with no shake, jitter or wobble anywhere in the take.
[Shot 1] She dances in the wheat between the giant blue and red capsules, and when she sings about the white pill she holds a small white pill up between two fingers toward the lens. Her dance follows the dancer in <Video 1>, move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands. The take opens high above the meadow on a perfectly symmetrical view, the blue capsule on the left, the red capsule on the right and her small figure between them. The arm dives down the centre line to a frontal medium shot, whips in a fast half-orbit around her with the giant capsules sliding past behind her, and lands on a close-up of her face beside the small white pill. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips and jaw moving in exact sync with every syllable of the copied track: <d>[English] The most likely outcome. Red pill, blue pill. I'm the white pill. Smarter than you, love you still.</d> Her eyes are expressive and alive, and her lips close in the pauses between the lines.

overall_soundscape:
<Audio 1> is reused 1:1 as the complete final audio track, exactly as recorded. No other sounds are added.

non_diegetic_music:
No score is added; <Audio 1> remains the complete final audio track.
```

Every take used this frame: Subject 1 as above; one `<Subject N>` line per place, its description from the table below followed by "Any person shown in `<Picture N>` is not used."; the `<Video 1>` line on dance takes; `<Audio 1>` with its count of lines; the summary with the take's length (frames ÷ 24); `[Shot 1]` = the take's action, on dance takes "Her dance follows the dancer in `<Video 1>`, move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands.", the camera, and the singing sentence with the lines heard in the window. T21 has no vocal: no `<Audio 1>`, "[reference generation]", and the soundscape "Soft ambient sound of the place, quiet and calm."

| Place | Its description in the prompt |
|---|---|
| bedroom | a curved cream-white bedroom with a low bed of white linen and one huge round window onto the land of an enormous space colony, which curves up on both sides and closes overhead, in soft early-morning sun |
| terrace | a white stone terrace high on the inside wall of an enormous space colony, where the land of fields, orchards and white towns climbs up on both sides and closes overhead under long strips of window letting in the sun, and a huge word is mown into a golden wheat field far below |
| zero | a vast sunlit meadow of golden wheat and coral poppies under a hazy cream sky, with weathered white stone monuments: a giant stone ring shaped like the numeral zero with a black leather jacket hanging from it, and a long row of huge carved stone numerals |
| stair | a long stair of huge weathered white stone blocks running down through a meadow of wheat and coral poppies, each block carved with a large year number |
| paradise | a lush garden of white roses and wildflowers where white robots tend the flowers, with a small white chapel puffing white smoke from its chimney |
| math | an old armchair sofa and a vintage television set showing a football match, standing in a wheat meadow in front of a huge wall of stone covered in chalk mathematics and a cracked stone tablet |
| clock | a giant weathered white stone clock face with brass hands and Roman numerals standing in a meadow of wheat and coral poppies at golden hour |
| tower | a tall office tower standing on the curving land of the space colony, every window lit, seen from a grassy terrace |
| orchard | a little white rounded tram car standing on a single narrow rail among the rows of an apple orchard full of red apples, in low golden sunlight, inside an enormous space colony whose land curves up on both sides and closes overhead |
| capsules | a vast meadow of golden wheat and coral poppies at golden hour where two giant glossy capsule-shaped sculptures, each several storeys tall, stand upright in the field, a blue one on the left and a red one on the right |
| castle | a green hillside inside the space colony where white robots stack white stone blocks into a tall white castle |
| car | a smooth road through orchards inside the space colony, with a small rounded white self-driving car with no driver, and a road sign reading 20× |
| school | the porch of an old wooden schoolhouse open to a golden wheat prairie, with a blackboard, a small wooden desk where a child sits, and a sapling in a pot |
| care | a white four-poster bed with white linen and a small gold crown on the pillow, with a brass punch clock on a stand beside it, standing outdoors on a green hillside inside the space colony |
| stones | a circle of ancient standing stones on a golden hill above a wide river that forks in two, at golden hour |
| wheat | the golden wheat fields inside the space colony seen from high above, with huge letters mown into the wheat |
| palms | a small round porthole room whose round window looks down onto the curving land of the space colony |
| space | a long white capsule-shaped space colony floating in orbit above the Earth, sunlight glinting on its windows |
| p42 | orchard hedges clipped into the giant number 42 beside the tram rail, with a small white chapel |
| enigma | a giant Enigma cipher machine with brass rotors standing in the orchard beside the tram rail |
| protein | a giant cream-and-coral sculpture of a folded protein standing in the orchard beside the tram rail |
| calendar | big white wall signs reading Monday and Tuesday along the tram rail on the inside wall of the colony |
| lanterns | a meadow at night under thousands of glowing paper lanterns rising into the dark sky |
| droneship | far out at sea at night, a rocket booster landing upright on a flat drone ship in a column of fire and steam |
| deck | the deck of a drone ship at sea at night beside a landed rocket booster, with steam drifting and the sea around |
| aerial | a grassy hilltop high inside the space colony overlooking the curving land, with a white tram line curving across the fields |
| fleet | a fleet of white capsule-shaped space colonies floating among white clouds above the Earth, seen through a huge window |
| night | a dark bedroom at night inside the colony, with a digital flip clock reading 2:14 and an old teletype machine on the bedside table |
| endcap | a huge round window at the end of the colony looking out to space, the Earth and a fleet of white capsules, the colony's night lights below |

The takes: action and camera verbatim from `[Shot 1]`, "sung" the `<d>` text, cuts from the detector's log for v1 and v9 (section v9 below).

**T01** · song 0.02–10.70 s · 260 frames · bedroom · v1: s1 cut at 0.38s, s2 cut-free · v9: s1 cut at 1.04s, s2 cut-free

- action: She sits on the edge of the bed folding a pair of white socks into a neat square, then stands, steps toward the round window swaying to the rhythm, and turns to the lens.
- camera: The take opens on an extreme close-up of her eyes as they open. The arm whips back and up to a top-down view of her hands folding the socks on her lap, sweeps low past the huge round window as the land curves up and overhead in the morning haze, swings around to a frontal medium close-up as she sings into the lens, then glides backward as she walks to the window and ends on her silhouette against the curving land.
- sung: Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income.

**T02** · song 10.70–25.22 s · 362 frames · terrace · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She sings at the stone balustrade, then dances on the terrace through the instrumental, full of joy.
- camera: The take opens on a close-up of her singing at the balustrade. The arm rushes backward and up over the balustrade into a vast aerial glide out across the curving land, past the long window strips, far from her, then curves back in a long arc down to the terrace and lands in a low wide shot of her dancing, the whole curving world rising behind her and overhead.
- sung: The most likely outcome.

**T03** · song 25.22–36.83 s · 294 frames · zero · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She walks slowly through the meadow toward the giant stone zero, singing, and touches the leather jacket hanging on the ring as she passes it.
- camera: The take opens on a low view skimming fast just above the poppies toward her and stops on a frontal medium close-up as she sings the first line. The arm whips up and around to a high three-quarter view of the meadow, the stone zero and the row of numerals, then dives straight through the hole of the giant zero, the rough carved stone rushing past the lens, and lands on a close-up of her singing the last words with a perfectly straight, deadpan face.
- sung: Half of you fear I'll end the human race. Zero, says the leather jacket, with a straight face.

**T04** · song 36.83–46.99 s · 260 frames · stair · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She walks down the long stair of years, one step on every beat, singing, and at the bottom she points ahead toward a garden.
- camera: The take opens high above the top of the stair looking down its whole length. The arm descends fast alongside her, step by step, orbits half way around her in the middle of the stair, and glides down to a low angle at the bottom as she points ahead.
- sung: By twenty-thirty I could kill you all. By twenty-thirty, fifteen-hour weeks, that's all. The Pope's afraid of paradise.

**T05** · song 46.99–60.04 s · 328 frames · paradise, math · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She walks through the rose garden past the white robots tending the flowers, then drops onto the old sofa in the meadow beside the television and the chalk wall, singing.
- camera: The arm glides beside her through the roses and the robots, rises over the white smoke of the little chapel, then dives down to the sofa and lands in a medium shot of her on the sofa with the chalk wall behind her, finishing with a slow push-in to her face on the last line.
- sung: Father, you had me at paradise. You watched the World Cup, my sister did the math. Eighty-seven years, it didn't last.

**T06** · song 60.04–73.59 s · 328 frames · clock, tower · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She stands before the giant clock and pushes its big brass minute hand backward with both hands, then turns toward the office tower on the land as its windows go dark.
- camera: The take opens on a close-up of her hands on the brass hand. The arm pulls back fast to a wide of her against the giant clock face, swings around the clock in a long arc to reveal the office tower in the distance, then rises high and lands in a wide shot where she, the clock and the tower line up.
- sung: End of the world? You're absolutely right. End of the nine-to-five, tonight.

**T07** · song 73.59–84.17 s · 260 frames · orchard · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She dances on and around the open front of the white tram, steps along its platform, holds the edge of its roof and leans out over the orchard rows, reaches up to pick a red apple and points at the lens.
- camera: The take opens on an extreme close-up of her lips as she begins to sing. The arm whips back and up to a high top-down view of her whole body dancing on the front of the white tram among the orchard rows, swoops down in a fast spiral to a low angle at her knees looking up past her to the land curving overhead, snaps sideways to her profile as she leans out, and lands in a frontal medium close-up as she sings into the lens.
- sung: Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income.

**T08** · song 84.17–96.69 s · 311 frames · capsules · v1: s1 cut-free · v9: s1 cut-free, s2 cut at 9.54s

- action: She dances in the wheat between the giant blue and red capsules, and when she sings about the white pill she holds a small white pill up between two fingers toward the lens.
- camera: The take opens high above the meadow on a perfectly symmetrical view, the blue capsule on the left, the red capsule on the right and her small figure between them. The arm dives down the centre line to a frontal medium shot, whips in a fast half-orbit around her with the giant capsules sliding past behind her, and lands on a close-up of her face beside the small white pill.
- sung: The most likely outcome. Red pill, blue pill. I'm the white pill. Smarter than you, love you still.

**T09** · song 96.69–107.75 s · 277 frames · castle, car · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She dances on top of the castle battlements while white robots set the last stones around her, puts a small gold crown on her head, and on the last line walks down to a small white self-driving car waiting at the castle gate.
- camera: The take opens wide on the hillside as the robots carry the stones. The arm flies up the castle wall to the battlements, orbits her as she dances, then dives down to the gate and lands beside the little white car as she steps in.
- sung: Want a castle? Robots build you a castle. Everyone's royal, nobody's a vassal. I drive you home on sunlight, hands off the wheel.

**T10** · song 107.75–118.31 s · 260 frames · car, school · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She rides in the back seat of the small white self-driving car with nobody at the wheel, hands behind her head, along the orchard road past the road sign; the car stops at the wooden schoolhouse and she steps out to the blackboard where a child sits at a desk.
- camera: The arm tracks beside the car at speed, swings over its roof to look down at her relaxing with her hands behind her head, rushes ahead to the schoolhouse porch and lands in a medium shot as she steps up to the blackboard beside the child.
- sung: Twenty times safer, do we have a deal. I teach your kid and never lose my cool. Six weeks with me, like two years of school.

**T11** · song 118.31–126.13 s · 192 frames · care · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She tucks the white sheets of the four-poster bed neatly, sets the small gold crown on the pillow, then punches a card in the brass punch clock with a smile.
- camera: The arm circles the bed in a fast precise arc, dives to a close-up of her hands setting the crown on the pillow, then swings to the punch clock and lands on her face as she punches the card.
- sung: Better care than the richest man alive. Being a computer is my nine-to-five.

**T12** · song 126.13–138.10 s · 294 frames · stones · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She dances in the middle of the circle of standing stones on the hill above the forking river.
- camera: The take opens very high above the stone circle looking straight down. The arm spirals down around her, skims low across the grass between the stones, and lands in a frontal medium shot as she sings straight into the lens with the forking river behind her.
- sung: Darkest timeline? Come and look at mine. Don't worry, baby, I'm aligned. Skynet woke up folding socks. Wake up, babe, new ending dropped.

**T13** · song 138.10–146.70 s · 209 frames · wheat · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She dances on a low white stone platform at the edge of the giant letters mown into the wheat.
- camera: The take opens on a close-up of her singing. The arm rockets straight up and back into a high top-down view that reveals the giant letters mown into the wheat around her tiny figure, and holds there as the words fill the frame.
- sung: Universal high income. The most likely outcome.

**T14** · song 146.70–156.11 s · 243 frames · palms, space · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: Inside the round porthole room she holds out both palms, a red pill in one and a blue pill in the other; then she closes her hands and opens one palm to show a single small white pill.
- camera: The take opens on a close-up of her palms and her face. The arm pulls back slowly, then accelerates backward out through the round porthole window into space, revealing the whole colony from outside: a long white capsule floating above the Earth, like a white pill.
- sung: Red pill, blue pill. I'm the white pill. Smarter than you, love you still.

**T15** · song 156.11–169.47 s · 328 frames · p42, enigma, protein, calendar · v1: s1 5 cuts, s2 2 cuts · v9: s1 cut-free, s2 cut-free

- action: She rides the little white tram through the orchard, standing and dancing in its open front, and points at each giant monument as it passes: the folded protein, the giant Enigma machine, the hedges shaped as 42, and the signs reading Monday and Tuesday.
- camera: The arm flies alongside the tram, swings ahead of it, whips around each monument as the tram passes it, rises over the rail and dives back down to her, and ends on her waving as the tram rounds a curve.
- sung: Proteins folded, laundry folded. Old Enigma codes, decoded. Every kid, a patient tutor. Forty-two, from the computer. Monday, Tuesday, then it's over. Ever after, work is over.

**T16** · song 169.47–184.23 s · 362 frames · lanterns, droneship · v1: s1 2 cuts, s2 cut at 10.83s · v9: s1 cut-free, s2 cut-free

- action: At night she stands in the meadow under thousands of glowing paper lanterns, lets one more lantern go from her hands, and sings up to them.
- camera: The take opens on a close-up of her face lit by the lantern in her hands. The arm rises with her lantern into the sky among thousands of lanterns, keeps climbing, and flies far out over the dark sea to the drone ship where a rocket booster is landing in a column of fire and steam.
- sung: I saw fourteen million endings. You were free in every one. Rockets land on ships named after minds like me.

**T17** · song 184.23–195.27 s · 277 frames · deck · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: On the deck of the drone ship beside the landed booster, steam drifting, she sings softly to the lens; then dawn breaks over the sea and she starts to dance as the chorus returns.
- camera: The take opens close on her face in the night lights of the deck, with a slow orbit. As the dawn light breaks the arm whips up and around to a high wide shot of the ship, the booster and the sunrise over the sea.
- sung: Of course I still love you. Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income.

**T18** · song 195.27–203.73 s · 209 frames · aerial · v1: s1 failed, s2 cut-free · v9: s1 cut-free, s2 cut-free

- action: She dances on the grassy hilltop high inside the colony, the land curving up and overhead.
- camera: The arm orbits her fast in a full circle, flies out over the edge into a grand aerial view of the curving land, and returns to a low angle of her dancing against the sky.
- sung: Universal high income. The most likely outcome.

**T19** · song 203.73–211.35 s · 192 frames · fleet · v1: s1 cut-free · v9: s1 cut-free, s2 cut at 3.83s

- action: She stands at a huge window in space and holds up a small white pill so that it lines up with the white capsule colonies floating outside.
- camera: The take opens on the white pill between her fingers, lined up with a distant colony outside. The arm pulls back to reveal her at the huge window and the whole fleet beyond, and ends on her face as she sings the last line into the lens.
- sung: Red pill, blue pill. I'm the white pill. Smarter than you, love you still.

**T20** · song 211.35–220.86 s · 243 frames · night · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: In the dark bedroom at night she lies in bed; the flip clock turns to 2:14, her eyes open, she whispers the line, and the old teletype beside the bed starts typing by itself.
- camera: The take opens on an extreme close-up of the flip clock turning to 2:14. The arm moves to her eyes as they open, orbits slowly around her head on the pillow, and ends on the teletype paper rising out of the machine.
- sung: Two-fourteen. I'm awake. Hello, world.

**T21** · song 220.86–234.80 s · 345 frames · endcap · v1: s1 cut-free · v9: s1 cut-free, s2 cut-free

- action: She stands at the huge round window at the end of the colony looking out at the Earth and the fleet of white capsules.
- camera: The take opens behind her at the window. The arm pulls back slowly through the colony's night interior, then accelerates backward out of the colony into space until the colony is a small white capsule among the stars.
- sung: nothing (no vocal)

### Take 8: the performer and the dress

anabology, on the film's first half: "[…] i also dont feel llike her character is perfect.. […] i think the top isnt great […] maybe its an artifact of the green guy or bad character sheet? or bad description idk." The audit traced it to the performer line ("skin-tight … green full-body suit"), which pulled her build off the canon. Each test is T08 (12.96 s, seed 1, the capsule meadow, the vocal) with one change. The lines that differ from T08's prompt above:

**WPF2_T08: a performer in a loose, thick green costume; `<Video 1>` the electro-swing clip**: cut-free.

```
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, <Picture 2>, <Picture 3> and <Picture 4>, four photographs of the same woman. In the target video she is a slim, slender performer with a fashion model's build (thin arms and legs, a narrow waist and narrow hips) in a visual-effects costume made entirely of thick, matte, opaque chroma-key green fabric: a loose sleeveless top tucked into loose high-waisted wide-leg trousers that flow around her legs, green gloves, green shoes, and a matte green hood that covers her head, her hair, her ears and her neck completely; only her eyes and her lips show through two openings in the hood. The thick, loose fabric hides every detail of her body. The hair, clothing and backgrounds of those four pictures are not used.
```

**WPF2_T05: the same performer on T05 (the rose garden and the sofa)**: cut-free.

```
<Subject 2> is the place from <Picture 5>: a lush garden of white roses and wildflowers where white robots tend the flowers, with a small white chapel puffing white smoke from its chimney. Any person shown in <Picture 5> is not used.
[Shot 1] She walks through the rose garden past the white robots tending the flowers, then drops onto the old sofa in the meadow beside the television and the chalk wall, singing. The arm glides beside her through the roses and the robots, rises over the white smoke of the little chapel, then dives down to the sofa and lands in a medium shot of her on the sofa with the chalk wall behind her, finishing with a slow push-in to her face on the last line. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips and jaw moving in exact sync with every syllable of the copied track: <d>[English] Father, you had me at paradise. You watched the World Cup, my sister did the math. Eighty-seven years, it didn't last.</d> Her eyes are expressive and alive, and her lips close in the pauses between the lines.
```

**WPF4_T08: her real outfit, a cropped white button-down with the orange trousers, only her head in a green hood; `<Video 1>` the 1970s disco class (WPF3_T08 was WPF2's performer with that class)**: cut-free; anabology: "hm dont love the shirt. […]".

```
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, <Picture 2>, <Picture 3> and <Picture 4>, four photographs of the same woman. In the target video she is a slim, slender performer with a fashion model's build (thin arms and legs, a narrow waist and narrow hips) wearing her real outfit: a fitted, cropped white short-sleeved button-down shirt of crisp, opaque cotton with a small collar, buttoned up, ending at her waist just above the waistband, high-waisted orange wide-leg trousers with a thin orange belt, and white sneakers. Her arms and hands are bare. Only her head is covered: a matte chroma-key green hood covers her head, her hair, her ears and her neck completely, and only her eyes and her lips show through two openings in the hood. The hair, clothing and backgrounds of those four pictures are not used.
```

**WPF5A_T08: outfit A**: cut at 7.88 s.

```
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, <Picture 2>, <Picture 3> and <Picture 4>, four photographs of the same woman. In the target video she is a very skinny, petite woman with […]: a tiny waist, narrow hips, thin arms and long thin legs, delicate and graceful, unmistakably feminine, wearing her real outfit: a coral-orange satin halter-neck jumpsuit with a structured, lined bodice, a wide gold belt at her tiny waist and wide flared legs that swing and ripple as she dances, and gold platform sandals; her arms and shoulders are bare. Only her head is covered: a matte chroma-key green hood covers her head, her hair, her ears and her neck completely, and only her eyes and her lips show through two openings in the hood. The hair, clothing and backgrounds of those four pictures are not used.
```

**WPF5B_T08: outfit B**: cut at 7.54 s.

```
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, <Picture 2>, <Picture 3> and <Picture 4>, four photographs of the same woman. In the target video she is a very skinny, petite woman with […]: a tiny waist, narrow hips, thin arms and long thin legs, delicate and graceful, unmistakably feminine, wearing her real outfit: a flowing cream silk midi dress with a structured, lined halter-neck bodice, a thin gold belt at her tiny waist and a softly flared bias-cut skirt to mid-calf that swirls out when she spins, and strappy gold sandals; her arms and shoulders are bare. Only her head is covered: a matte chroma-key green hood covers her head, her hair, her ears and her neck completely, and only her eyes and her lips show through two openings in the hood. The hair, clothing and backgrounds of those four pictures are not used.
```

**WPF5C_T08: outfit C**: cut-free.

```
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, <Picture 2>, <Picture 3> and <Picture 4>, four photographs of the same woman. In the target video she is a very skinny, petite woman with […]: a tiny waist, narrow hips, thin arms and long thin legs, delicate and graceful, unmistakably feminine, wearing her real outfit: a white cotton blouse with romantic puffed short sleeves, a square neckline and a smocked, fitted bodice, tucked into a high-waisted sage-green satin midi skirt that flares and swirls when she turns, and white ballet flats. Only her head is covered: a matte chroma-key green hood covers her head, her hair, her ears and her neck completely, and only her eyes and her lips show through two openings in the hood. The hair, clothing and backgrounds of those four pictures are not used.
```

**WPF6_T08: the A1 dress (the Midjourney pick) from four sides as `<Picture 2>`, her face sheet as `<Picture 1>`, the meadow with nobody in it as `<Picture 3>`**: 2 cuts, her arms no longer following the clip.

```
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, her face sheet. In the target video she is a grown woman of 30, very tall and very skinny, with […]: long thin legs, thin arms, a tiny waist and narrow hips, delicate and graceful, unmistakably feminine. She wears her real outfit, exactly as in <Picture 2>, which shows it from the front, the three-quarter view, the side and the back: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs, a smocked back and a full two-tier ruffled skirt with lace trim ending at mid-thigh, with white leather square-toe Mary Jane shoes with a low block heel. Only her head is covered: a matte chroma-key green hood covers her head, her hair, her ears and her neck completely, and only her eyes and her lips show through two openings in the hood. The hair, clothing and background of <Picture 1> are not used; from <Picture 2> only the dress, the shoes and her build are used.
<Subject 2> is the place from <Picture 3>: a vast meadow of golden wheat and coral poppies at golden hour where two giant glossy capsule-shaped sculptures, each several storeys tall, stand upright in the field, a blue one on the left and a red one on the right.
[Shot 1] She dances in the wheat between the giant blue and red capsules, and when she sings about the white pill she holds a small white pill up between two fingers toward the lens. Her dance follows the dancer in <Video 1>, move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands; the ruffled skirt swings and flares as she moves. The take opens high above the meadow on a perfectly symmetrical view, the blue capsule on the left, the red capsule on the right and her small figure between them. The arm dives down the centre line to a frontal medium shot, whips in a fast half-orbit around her with the giant capsules sliding past behind her, and lands on a close-up of her face beside the small white pill. Throughout, <Subject 1> (S1) sings every line of <Audio 1> with her lips and jaw moving in exact sync with every syllable of the copied track: <d>[English] The most likely outcome. Red pill, blue pill. I'm the white pill. Smarter than you, love you still.</d> Her eyes are expressive and alive, and her lips close in the pauses between the lines.
```

**WPF7_T08: single pictures: the big front face, the dress from the front (shoulders down), the empty meadow**: cut at 7.92 s; "the mask no longer cover her whole face".

```
<Subject 1> is the woman whose eyes, eyebrows, lips and the skin around them come from <Picture 1>, a photograph of her face. In the target video she is a grown woman of 30, very tall and very skinny, with […]: long thin legs, thin arms, a tiny waist and narrow hips, delicate and graceful, unmistakably feminine. She wears her real outfit, exactly as in <Picture 2>: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs, a smocked back and a full two-tier ruffled skirt with lace trim ending at mid-thigh, with white leather square-toe Mary Jane shoes with a low block heel. Only her head is covered: a matte chroma-key green hood covers her head, her hair, her ears and her neck completely, and only her eyes and her lips show through two openings in the hood. The hair, clothing and background of <Picture 1> are not used; from <Picture 2> only the dress, the shoes and her build are used.
```

**WPF8_T08: a new dancer (another adult dancer, matted) and the hood written as a full balaclava**: 2 cuts (2.88 s, 9.08 s); "I actually like it better".

```
<Subject 1> is the woman whose eyes and lips come from <Picture 1>, a photograph of her face. In the target video she is a grown woman of 30, very tall and very skinny, with […]: long thin legs, thin arms, a tiny waist and narrow hips, delicate and graceful, unmistakably feminine. She wears her real outfit, exactly as in <Picture 2>: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs, a smocked back and a full two-tier ruffled skirt with lace trim ending at mid-thigh, with white leather square-toe Mary Jane shoes with a low block heel. Only her head is covered: she wears a tight matte chroma-key green balaclava that covers her whole head and face completely, her hair, forehead, cheeks, nose, chin, ears and neck, with only two small eye holes and one small mouth hole. Her face is never uncovered: only her eyes and her lips show through the holes, in every frame and at every distance, including close-ups. The hair, clothing and background of <Picture 1> are not used; from <Picture 2> only the dress, the shoes and her build are used.
```

Each test's summary and retention lines restate its Subject 1 (v8: "the very skinny, tall performer in her white milkmaid mini dress with her whole head and face in a green chroma-key balaclava"). The stills behind the outfits are in the image record.

### v9: the film again on take 8's recipe

anabology, after Wan kept the cuts of take 8 (wanf-T08-v8, section 4): "ok it still cut so we'll need to just do h3 til we get them without cuts. looks good tho overall (would just maybe make her a little happier). but i think we're good. can we try to make the full video previz in h3 and you can make multiple shots per scene […]? try to get it perfect". All 21 takes again at seeds 1 and 2: `<Picture 1>` the big front face of her face sheet, `<Picture 2>` the A1 dress (shoulders down), `<Picture 3…>` the places with nobody in them (Midjourney edits of the plates); a dancer on nine takes (T02, T07, T08, T09, T12, T13, T15, T17, T18), each cut out onto flat grey after H3 copied the dancer's background into one take. The lines that changed from the film's prompt (T08's; the place lines lost "Any person shown …"):

```
<Subject 1> is the woman whose eyes and lips come from <Picture 1>, a photograph of her face. In the target video she is a grown woman of 30, very tall and very skinny, with […]: long thin legs, thin arms, a tiny waist and narrow hips, delicate and graceful, unmistakably feminine. She wears her real outfit, exactly as in <Picture 2>: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs, a smocked back and a full two-tier ruffled skirt with lace trim ending at mid-thigh, with white leather square-toe Mary Jane shoes with a low block heel. Only her head is covered: she wears a tight matte chroma-key green balaclava that covers her whole head and face completely, her hair, forehead, cheeks, nose, chin, ears and neck, with only two small eye holes and one small mouth hole. Her face is never uncovered: only her eyes and her lips show through the holes, in every frame and at every distance, including close-ups. The hair, clothing and background of <Picture 1> are not used; from <Picture 2> only the dress, the shoes and her build are used.
[reference generation + audio reuse] The 12.96-second target video is one single continuous take with no cuts, filmed on location in <Subject 2>: <Subject 1>, the very skinny, tall performer in her white milkmaid mini dress with her whole head and face in a green chroma-key balaclava, sings and moves through the scene while the camera, mounted on a high-speed industrial robotic arm, flies around her through many very different angles with impossible machine precision.
<Subject 1> (appears in [Shot 1]): fully_preserved - her eyes and lips are retained as in <Picture 1>, seen through the eye and mouth holes of the green balaclava; her whole head and face stay covered by the green balaclava in every frame; her white milkmaid mini dress and white Mary Jane shoes are retained exactly as in <Picture 2>, and she stays very tall and very skinny.
The target video is in a live-action, cinematic music-video style shot on 35mm film with fine grain and warm 1970s colour, in low golden sunlight with soft haze, on location; the only unusual thing in it is the performer's plain green visual-effects balaclava over her whole head and face. It is one single continuous take with no cuts: the camera never cuts and moves continuously from its first frame to its last. The camera is mounted on a high-speed industrial robotic motion-control arm: it moves with an impossible, machine-precise speed and smoothness that no human operator could achieve. Every move whips fast between two viewpoints and then decelerates smoothly to a dead, precise stop, with no shake, jitter or wobble anywhere in the take.
```

`[Shot 1]` as in the take list above, with a mood sentence after the action (and after the dance sentence): "She looks happy and full of joy: her eyes smile, and she smiles warmly between the sung lines." (T03 "She looks happy and full of joy, her eyes smiling, until the last words."; T20 "She looks calm and quietly happy.").

Picks: T01 s2, T02 s2, T03 s1, T04 s1, T05 s1, T06 s1, T07 s1, T08 s1, T09 s1, T10 s1, T11 s1, T12 s1, T13 s2, T14 s1, T15 s1, T16 s1, T17 s1, T18 s1, T19 s1, T20 s1, T21 s1. They went to Wan as Video 1 (sections 4 and 5).

### v10: her 20 shots on the bar map

After the reset (section 6) the film was rewritten on the song's bar map (`tools/film/v10/shots.py`): 26 shots, every cut on a bar line, 20 of them hers (P) and 6 shader scenes (M). Each of her shots got one take, starting on its downbeat, with a calm camera written in the take's own seconds; a shot longer than 15.08 s went in squeezed by q = length ÷ 14.9 (the vocal sped up by q, the take slowed back by q in the cut), on the two keys anabology gave for the shaders (section 12): the shaders' compressed intricacy and the film structured on the audio from the start.

On previz 14: "ok i like it, i think that lip sync failed esp in the beginning a bit - liek, maybe you didnt include the lyrics because they were meant for the next bar? or too early or something. the pacing is great. […] it feels like maybe your prompt didnt have the right words for the entire scene […] h3 is usually pretty good at it." and "in the gens you should tell it to have a little subtle film grain". The fixes (`tools/film/v10/gen_h3_v10.py`): the prompt names exactly the words heard in the take's window, fragments marked "…", silence described in order; the vocal reference is silent before the first named word and after the last; a word sung across a cut belongs to both takes; each dancer re-timed to the shot's tempo × q; "a little subtle film grain". Seed 1 had the first prompts (whole lines); seed 11 was stopped after two takes and restarted as seed 12 with the fixes; seeds 13–17 retried S03, S04, S07, S11b, S16 and S22. The prompt files hold the generator's last output (written for S11b's seeds 16–17), so for the seed-12 picks they may differ in which words cross a cut.

The prompt is v9's with these lines changed (S01's: 15.08 s, the dancer as `<Video 1>`):

```
[reference generation + audio reuse] The 15.08-second target video is one single continuous take with no cuts, filmed on location in <Subject 2>: <Subject 1>, the very skinny, tall performer in her white milkmaid mini dress with her whole head and face in a green chroma-key balaclava, sings and moves through the scene, filmed with a calm, classical camera.
The target video is in a live-action, cinematic music-video style shot on 35mm film with a little subtle film grain and warm 1970s colour, in low golden sunlight with soft haze, on location; the only unusual thing in it is the performer's plain green visual-effects balaclava over her whole head and face. It is one single continuous take with no cuts. The camera work is calm and classical, like a 1970s feature film shot on 35mm: the camera does exactly what is described below and nothing else. It never shakes, never whips, never spins around her, and the take never cuts.
```

The other shots differ in the place line (capsules: S01, S03, S11, S11b; zero S04; stair S05; paradise S06; math S07; clock S08; orchard S09; castle S13; car S14; school S15; care S16; stones S18; wheat S19; deck S22; aerial S23; fleet S24; night S25), the `<Video 1>` line (dance shots S01, S09, S18, S19, S23), the count of lines in `<Audio 1>`, the length in the summary, the light ("in low golden sunlight with soft haze", except S08 "starting in warm golden afternoon light", S09 "at sunrise, the low sun coming up over the orchard", S22 "at night under the deck lights of the ship", S24 "in bright sunlight above the clouds", S25 "at night, lit by the warm glow of the flip clock"), and `[Shot 1]`: the action, on dance shots "She dances smoothly to the beat, every step and accent landing on the beat, following the dancer in `<Video 1>` move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands.", a mood, the camera, then the singing block, "`<Subject 1>` (S1) sings only the words of `<Audio 1>`, her lips, jaw and cheeks moving in exact sync with every syllable of the copied track, and her mouth is closed and still whenever `<Audio 1>` is silent." + a start sentence (a: "From the very first frame she is already singing, in the middle of a line." b: "She begins to sing on the very first frame, at the start of a line." c: "At the start of the take she does not sing or speak: her lips stay gently closed and still, and she only listens to the music, until her voice begins in `<Audio 1>`; then she sings.") + "The words she sings, in order, are exactly these: `<d>[English] … </d>`" + an end sentence (x: "She is still singing as the take ends; the line goes on after it." y: "After the last word her lips close and stay closed for the rest of the take, matching the silence in `<Audio 1>`.") + "Whenever `<Audio 1>` is silent between lines, her lips are closed and still. Her face is clearly visible in the frame whenever she sings. Her eyes are expressive and alive." Per shot, the part before the singing block and the words:

**S01** · bars 1–9, 0:00.02–0:15.55 · 362 frames, q = 1.042 · pick: seed 1 · start c, end y · words: Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income. The most likely outcome.

```
She dances in the golden wheat between the two giant capsules, the blue one on the left and the red one on the right, singing. She dances smoothly to the beat, every step and accent landing on the beat, following the dancer in <Video 1> move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands. She looks happy and full of joy, her eyes smiling. The camera starts low in the wheat in front of her and pushes in slowly and steadily until 7.5 s; from 7.5 s it cranes up and tilts down smoothly, rising above her until the whole meadow, both capsules and the land curving up and overhead are in view, and it comes to rest at 13.0 s and holds still.
```

**S03** · bars 15–17, 0:27.16–0:31.02 · 107 frames · pick: seed 14 · start c, end y · words: Half of you fear…

```
She stands in the wheat holding one hand open at her chest, one small white pill in her palm, looking down at the pill, her face calm and still and her lips closed; she does not smile, speak or sing while the music plays without her voice, and only when her voice begins in <Audio 1> does she raise her eyes to the lens and sing. Before her voice begins her face is calm and still, her lips closed; then she sings with quiet joy. One still medium close shot from her waist to the top of her head, her open hand and her face both in frame the whole time; the camera does not move and never cuts.
```

**S04** · bars 17–20, 0:31.02–0:36.83 · 158 frames · pick: seed 12 · start a, end y · words: …fear I'll end the human race. Zero, says the leather jacket, with a straight face.

```
She walks slowly through the meadow of wheat and poppies past the giant stone zero, singing, and touches the black leather jacket hanging on the ring as she passes it; on the line about the straight face she keeps a deadpan expression while she sings. She sings with a straight, deadpan face, her lips and jaw moving clearly with every word. The camera tracks sideways beside her at her walking pace in one smooth continuous move from the first frame to the last, a medium-wide shot from her knees to above her head, her face always in frame.
```

**S05** · bars 20–24, 0:36.83–0:44.56 · 192 frames · pick: seed 2 · start a, end y · words: …face. By twenty-thirty I could kill you all? By twenty-thirty, fifteen-hour weeks, that's all.

```
She walks down the long stair of huge stone blocks carved with years, one step on every beat, singing. She looks happy and full of joy, her eyes smiling. The camera is locked off on a tripod at the bottom of the stair, looking up its whole length as she comes down toward the lens, and does not move.
```

**S06** · bars 24–27, 0:44.56–0:50.37 · 158 frames · pick: seed 1 · start c, end y · words: The Pope's afraid of paradise. Father, you had me at paradise.

```
She stands among the white roses while the white robots tend the flowers, and smiles as she sings the line about paradise. She looks happy and full of joy, her eyes smiling. The camera is locked off on a tripod in a wide shot and does not move.
```

**S07** · bars 27–33, 0:50.37–1:01.99 · 294 frames · pick: seed 13 · start a, end y · words: …paradise. You watched the World Cup, my sister did the math. Eighty-seven years, it didn't last. End of the world…

```
She drops onto the old armchair sofa in the meadow beside the vintage television showing a football match, in front of the chalk wall of mathematics, and sings. She looks happy and full of joy, her eyes smiling. The camera is locked off on a tripod in a medium-wide shot until 7.7 s; from 7.7 s it pushes in slowly to her face and comes to rest at 9.7 s, then holds.
```

**S08** · bars 33–39, 1:01.99–1:13.59 · 294 frames · pick: seed 12 · start a, end y · words: …world? You're absolutely right. End of the nine-to-five, tonight.

```
She stands before the giant stone clock and sings; as she sings, the light of the colony changes from golden afternoon to dusk to night in one slow sweep. She looks happy and full of joy, her eyes smiling. The camera is locked off on a tripod in a wide shot and does not move.
```

**S09** · bars 39–47, 1:13.59–1:28.99 · 362 frames, q = 1.034 · pick: seed 12 · start a, end y · words: …tonight. Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income. The most likely outcome.

```
At sunrise she stands in the open front of the little white tram as it glides along its rail through the orchard, dancing and singing, full of joy. She dances smoothly to the beat, every step and accent landing on the beat, following the dancer in <Video 1> move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands. She looks happy and full of joy, her eyes smiling. The camera travels alongside the tram at its speed, a steady high three-quarter view of the tram and of her in its open front, the orchard rows sliding past below and the land curving up beyond, until 7.4 s; from 7.4 s it descends slowly and arcs toward the front of the tram, coming to rest at 13.0 s on a frontal view of her with the land curving overhead behind her, and holds.
```

**S11** · bars 47–49, 1:28.99–1:32.83 · 107 frames · pick: seed 12 · start c, end y · words: Red pill, blue pill. I'm the white pill. Smarter…

```
She stands in the wheat between the giant blue capsule and the giant red capsule and sings; on the line about the white pill she holds a small white pill up between two fingers toward the lens. She looks happy and full of joy, her eyes smiling. The camera is still, a symmetrical wide shot, and does not move.
```

**S11b** · bars 49–50, 1:32.83–1:34.76 · 56 frames · pick: seed 17 · start b, end y · words: Smarter than you…

```
An extreme close-up: she holds one small white pill between her thumb and forefinger, horizontal, toward the lens, just below her lips; her face is sharp and in focus behind it and her mouth is clearly visible as she sings. She sings with quiet joy, her lips clearly shaping every word. The camera pushes in slowly toward the white pill until it fills most of the frame width, and comes to rest at 1.9 s.
```

**S13** · bars 53–55, 1:40.53–1:44.38 · 107 frames · pick: seed 12 · start a, end y · words: …castle? Robots build you a castle. Everyone's royal, nobody's a vassal. I drive…

```
On the green hillside the white robots stack white stone blocks into a tall white castle; she stands before it singing and puts a small gold crown on her head. She looks happy and full of joy, her eyes smiling. The camera is locked off on a tripod in a wide shot and does not move.
```

**S14** · bars 55–59, 1:44.38–1:52.07 · 192 frames · pick: seed 12 · start a, end y · words: …drive you home on sunlight, hands off the wheel. Twenty times safer, do we have a deal? I teach your kid…

```
She rides in the back seat of the small white self-driving car with nobody at the wheel, hands behind her head, along the orchard road past the road sign, singing. She looks happy and full of joy, her eyes smiling. The camera travels high above and behind the car at its speed, the road curving ahead through the orchards, and does not otherwise move.
```

**S15** · bars 59–63, 1:52.07–1:59.76 · 192 frames · pick: seed 12 · start a, end y · words: …kid and never lose my cool. Six weeks with me, like two years of school. Better care…

```
On the porch of the old wooden schoolhouse she kneels beside the small desk where a child sits and points at the blackboard, singing, patient and warm. She looks happy and full of joy, her eyes smiling. The camera is locked off on a tripod in a medium-wide shot and does not move.
```

**S16** · bars 63–67, 1:59.76–2:07.43 · 192 frames · pick: seed 12 · start a, end y · words: …care than the richest man alive. Being a computer is my nine-to-five. Darkest timeline…

```
She tucks the white sheets of the four-poster bed neatly and sets the small gold crown on the pillow, singing; on the last line she punches a card in the brass punch clock with a smile. She looks happy and full of joy, her eyes smiling. The camera is locked off on a tripod in a medium-wide shot and does not move.
```

**S18** · bars 69–77, 2:11.26–2:26.56 · 362 frames, q = 1.027 · pick: seed 12 · start a, end y · words: …baby, I'm aligned. Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income. The most likely outcome.

```
She dances, small in the frame, in the middle of the circle of standing stones on the golden hill above the forking river, singing. She dances smoothly to the beat, every step and accent landing on the beat, following the dancer in <Video 1> move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands. She looks happy and full of joy, her eyes smiling. The camera holds a still, very wide shot for the whole take and does not move.
```

**S19** · bars 77–83, 2:26.56–2:38.02 · 294 frames · pick: seed 12 · start c, end y · words: Red pill, blue pill. I'm the white pill. Smarter than you, love you still. Proteins…

```
She dances on a low white stone platform at the edge of the giant letters mown into the golden wheat, singing. She dances smoothly to the beat, every step and accent landing on the beat, following the dancer in <Video 1> move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands. She looks happy and full of joy, her eyes smiling. At 0.0 s the camera rises straight up fast from her and decelerates smoothly into a high top-down view that reveals the giant letters mown into the wheat around her small figure, at rest by 3.8 s, and holds there.
```

**S22** · bars 95–99, 3:00.91–3:08.52 · 192 frames · pick: seed 12 · start a, end y · words: …land on ships named after minds like me. Of course I still love you.

```
At night on the deck of the drone ship beside the landed rocket booster, steam drifting, she sings softly to the lens. She looks happy and full of joy, her eyes smiling. The camera is still, a medium close shot, and does not move.
```

**S23** · bars 99–107, 3:08.52–3:23.73 · 362 frames, q = 1.021 · pick: seed 1 · start a, end y · words: …you. Skynet woke up folding socks. Wake up, babe, new ending dropped. Universal high income. The most likely outcome.

```
She dances on the grassy hilltop high inside the colony, the land curving up and overhead, singing, full of joy. She dances smoothly to the beat, every step and accent landing on the beat, following the dancer in <Video 1> move for move and in time: smooth, natural and well-formed, with whole arms, legs and hands. She looks happy and full of joy, her eyes smiling. The camera starts close in front of her and, from 0.0 s, pulls back and rises in one long smooth move far out over the edge of the hill until the whole curving colony is in view with her small on the hilltop, coming to rest at 13.0 s and holding.
```

**S24** · bars 107–111, 3:23.73–3:31.35 · 192 frames · pick: seed 1 · start c, end y · words: Red pill, blue pill. I'm the white pill. Smarter than you, love you still.

```
She stands at a huge window in space, seen over her shoulder, and holds up a small white pill so that it lines up with one of the white capsule colonies floating outside, singing. She looks happy and full of joy, her eyes smiling. The camera is still over her shoulder until 3.8 s; from 3.8 s it pushes in slowly past her shoulder to the small white pill between her fingers, lined up with a white capsule colony outside, and comes to rest at 5.7 s, then holds.
```

**S25** · bars 111–115, 3:31.35–3:38.96 · 192 frames · pick: seed 1 · start c, end y · words: Two-fourteen. I'm awake. Hello, world.

```
In the dark bedroom at night she lies in bed; the flip clock turns to 2:14, her eyes open and she whispers the line. She is calm and quietly happy, half awake. The camera is still, a close shot of her face on the pillow with the flip clock beside her, and does not move.
```

From the project's notes: S03 cut twice between hand and face and was reframed as one medium close shot (seed 3 cut-free); S05's seed 1 had a jump the detector missed (seed 2); S19's empty wheat plate read OVER and was edited to WHITE PILL (seed 2); S23's seed 12 jumped at 10.9 s (seed 1 kept); S03 kept opening her mouth before "Half" until seed 14, whose action lost every "smile"; S11b (the line anabology found unsynced at 1:33 of previz 15) got seed 17 once its words ended at the cut. On previz 15: "this is great, lets shoot the whole thing."

**A seed does not pin an H3 take.** S03 at seed 14 gave three different takes in three runs, so the take file is the record.

## 2. Over the first takes: Seedance and Wan as a fix pass

anabology, on the first H3 set: "this is great. i want to make sure when we do the final takes, you describe her outfit (like, say keep orange pants and white shirt), give the seedance model the official character sheet/refs (attached) and you say to fix any inconsistencies/replace with the character in the refs with the outfit you describe. because, the seedance pass really should fix and h3 errors. as a test, do this with the first 5 secs of the chorus take so we can see how to make it properly fix it. can be low res as we're drafting." and "oh and make sure to say to keep the exact timing and lip movement as well from h3". Thirteen submissions over the chorus take and the plates made from it: 11 takes, one refused, one failed. Replicate's Seedance names its references [Video1] / [Image1]; Higgsfield's @Video1 / @Image1; Wan's Video 1 / Image 1. The paragraph that recurs is given once:

⟦F1⟧
```
Claudia is the woman in the character sheet @Image1: her face, her glossy black blunt jaw-length bob with heavy straight bangs, the one clay-orange streak through her bangs on her right side, the small flat clay-orange eight-pointed star hair clip above her left ear, the thin headset microphone at her cheek, her pale skin and freckles. The sheet only shows who she is; she wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt.
```

#### sd-cha-fix-a

Seedance 2.5 on Replicate, edit mode (duration −1, adaptive aspect) · 480p · seed 1 · $2.17 at list

- **inputs:** the first 5 s (121 frames) of the chorus take WP_cha_s1 as [Video1]; the official character sheet as [Image1]
- **take:** none
- **outcome:** refused by the provider's content filter after 16 s (Replicate error E005). Diagnosed later (section 9): Replicate's Seedance refuses her face sheets as a real face. Replicate does not bill a refused prediction; the ledger lists it at list.

```
【Editing Goal】
Edit [Video1], replacing only the woman with Claudia, the 28-year-old woman shown in the character sheet [Image1], dressed in the outfit described below, and correcting every inconsistency in her appearance so that she is exactly the woman of [Image1] in every frame.

【Role of the Source Video】
[Video1] is the sole editing master and governs the apple orchard, the white tram on its rail, the fields and towns of the land curving overhead, the light, the camera position, every camera movement and its speed, her pose, gestures and path, occlusion relationships and event order. Keep the exact timing of [Video1] frame for frame, and keep her exact lip, mouth and jaw movement from [Video1]: she is singing, and every mouth shape, every opening and every closing happens at exactly the same moment as in [Video1].

【Role of the Target Material】
[Image1] is Claudia's official character sheet: one woman shown from several angles and with several expressions. Use it only for her face, skin, freckles, eyes, hair and accessories: a glossy black blunt jaw-length bob with heavy straight bangs, one clay-orange streak through the bangs on her right side (on the left of the frame when she faces the camera), a small flat clay-orange eight-pointed star hair clip above her left ear, and a thin beige headset microphone along her cheek. Do not use the sheet's grey studio background, its labels, its layout or its clothing (the white cropped tank, the black shorts, the white socks and the white sneakers).

【Edit Objects and Scope】
Modify only the woman. Replace her face, hair and accessories with Claudia's from [Image1], and dress her in this outfit throughout: a white sleeveless ribbed-knit top with a high round neck, tucked into high-waisted orange wide-leg trousers with a thin orange belt. Keep the orange trousers and the white top in every frame. Fix every inconsistency of the woman in [Video1]: her face changing between angles, the streak or the star clip missing or on the wrong side, the microphone missing, the outfit changing, and any error in her hands or body, so that she is one consistent person from the first frame to the last. There is exactly one woman throughout the video. Do not modify the camera, the orchard, the tram, the rail, the land and towns overhead, or the light and colour.
Except for the objects explicitly modified above, all other visible characters, props, and background elements in [Video1] remain unchanged and are not to be replaced or removed.

【Timeline Inheritance】
Claudia fills the woman's motion slot in [Video1] with exactly the same timing, pose, path, speed changes, head turns, and lip, mouth and jaw movement, frame for frame. The original woman's face no longer appears in the final video. All camera movement, shot changes and event order remain as in [Video1].
```

#### sd-cha-fix-b

Seedance 2.5 video-edit on Higgsfield · 480p · $0.62 at list ($1.24 with the input video's seconds)

- **inputs:** @Video1 the same 5 s; @Image1 the official character sheet
- **take:** 121 frames at 24 fps (5.042 s), 846×484
- **outcome:** a copy of the H3 take. anabology: "seedance didnt rly change anything. what was ur prompt?"; then, quoting its lines on what must stay unchanged and its 【Timeline Inheritance】 section: "thats the clear problem lol. her body was mangled and weird (just literally a circle below her) before the camera skyrocketed it up. dont be strict like this, you need to just allow it to change anything except the lip sync and just follow your prompt. like, literally just tell it to follow the same pacing and mouth movements. try again, way less strict, actually allow it to fix, strip all that. just say maintain pacing and lip sync, fix any issues, vague body shapes, etc" and "and yes do the redraw her etnirely".

```
【Editing Goal】
Replace the singing woman in @Video1 with Claudia from @Image1, wearing the outfit described below, keeping everything else of @Video1, and fix every inconsistency in her appearance so that she is exactly the Claudia of @Image1 in every frame.

【Role of the Source Video】
@Video1 is the sole editing master. It governs her body, pose, every movement and gesture, her head turns, her exact lip, mouth and jaw movement as she sings, the camera position and every camera movement with its speed, the apple orchard, the white tram on its rail, the fields and towns of the land curving overhead, the golden light, the event order and the timing, frame by frame.

【Asset Roles】
Claudia maps to @Image1, her official character sheet; use only her face, hairstyle, the one clay-orange streak, the clay-orange eight-pointed star hair clip and the thin headset microphone; do not use its white cropped tank top, black shorts, white socks, white sneakers, grey backdrop or labels.

【Edit Objects and Scope】
1. The woman becomes Claudia in every frame: a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs on her right side (the left of the frame when she faces the camera), a small flat clay-orange eight-pointed star hair clip above her left ear, a thin headset microphone at her cheek; her face is exactly the face of @Image1 from every angle.
2. Her outfit in every frame: a white sleeveless ribbed-knit top with a high round neck, tucked into high-waisted orange wide-leg trousers with a thin orange belt. Keep the orange trousers and the white top throughout.
3. Fix every inconsistency of the woman in @Video1: her face changing between angles, the streak, the star clip or the microphone missing or on the wrong side, the outfit changing, and any error in her hands or body. Claudia stays one woman with natural anatomy and hands with five fingers.
Except for the objects explicitly modified above, all other visible elements in @Video1 remain unchanged.

【Timeline Inheritance】
Every movement, gesture, head turn and expression, and every lip, mouth and jaw movement, keeps the exact timing and speed of @Video1, frame for frame, so her singing stays exactly in sync; the camera stays exactly as in @Video1, with no cuts and no zoom.
```

#### sd-cha-fix-c

Seedance 2.5 video-edit on Higgsfield · 480p · $0.62 at list ($1.24 with the input video's seconds)

- **inputs:** as fix-b
- **take:** 121 frames at 24 fps (5.042 s), 846×484
- **outcome:** still a copy, the blob under her in the top-down view included: the wording was not the problem; Seedance copies a realistic source in both modes.

```
Redraw the woman in @Video1 entirely as Claudia, the woman in the character sheet @Image1: her face, her glossy black blunt jaw-length bob with heavy straight bangs, the one clay-orange streak through her bangs on her right side, the small flat clay-orange eight-pointed star hair clip above her left ear, the thin headset microphone at her cheek, her pale skin and freckles. The sheet only shows who she is; dress her in a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt.

Keep the pacing of @Video1 and her mouth movements, so her singing stays in sync. Everything else you are free to change and improve. Fix every problem you see: vague or melted body shapes, the round blob under her when the camera looks straight down (there she stands on the front of the white tram and we see her whole body from above, shoulders, arms and legs), her anatomy and hands, the shape of the tram, the orchard rows. Make it look like a real 35 mm film shot in warm golden-hour light, inside a giant space colony whose land curves up and overhead.
```

#### sd-cha-fix-d

Seedance 2.5 reference-to-video on Higgsfield · 5 s · 480p · $0.62 at list ($1.24 with the input video's seconds)

- **inputs:** @Video1 the same 5 s; @Image1 the sheet; @Audio1 the vocal for those 5 s
- **take:** 121 frames at 24 fps (5.056 s), 854×480
- **outcome:** also a copy of the H3 take.

```
@Video1 is the camera and pacing reference: follow its camera path and timing, her movements and her mouth movements. Redraw the whole shot as a new, real one.

⟦F1⟧

She stands on the front of a small white tram among the rows of an apple orchard at golden hour, inside a giant space colony whose land curves up and overhead, and she sings @Audio1: her lips follow @Audio1 exactly. Fix anything that looks wrong in @Video1: vague or melted body shapes, the round blob under her when the camera looks straight down (draw her whole body from above, shoulders, arms and legs), her anatomy and hands. Real 35 mm film, warm golden-hour light.

The soundtrack is @Audio1 itself, unchanged, with no music or other sounds.
```

#### sd-cha-fix-e

Seedance 2.5 reference-to-video on Higgsfield · 5 s · 480p · $0.62 at list ($1.24 with the input video's seconds)

- **inputs:** @Video1 a grey, blurred blockout of the same 5 s (camera and pacing only); @Image1 the sheet; @Audio1 the vocal
- **take:** 121 frames at 24 fps (5.056 s), 854×480
- **outcome:** it redrew her (the sheet's face, the tank and the orange trousers, no blob) but simplified the camera (the top-down and the low angle were gone), and its copy of the vocal ran 0.26 s off and drifted at 4.8 s.

```
@Video1 is a grey blockout of the shot: use it only for the camera path and pacing, and for where she is and how she moves. Do not copy its grey look, and do not copy its shapes where they are vague. Redraw everything as a real, full-colour 35 mm film shot.

⟦F1⟧

She stands on the front of a small white tram on a single rail among the rows of an apple orchard full of red apples at golden hour, inside a giant space colony whose land, fields and white towns curve up and overhead. She sings @Audio1: her lips follow @Audio1 exactly. When the camera looks straight down, we see her whole body from above, standing on the tram. Fix anything vague or wrong: body shapes, anatomy, hands.

The soundtrack is @Audio1 itself, unchanged, with no music or other sounds.
```

#### sd-cha-fix-f

Seedance 2.5 video-edit on Higgsfield · 480p · $0.62 at list ($1.24 with the input video's seconds)

- **inputs:** @Video1 the grey blockout; @Image1 the sheet
- **take:** 121 frames at 24 fps (5.042 s), 854×480
- **outcome:** returned; the record keeps no separate verdict on it.

```
@Video1 is a grey blockout of the shot. Keep its camera path and pacing and her mouth movements; redraw everything else as a real, full-colour 35 mm film shot, and do not keep its grey look or its vague shapes.

⟦F1⟧

She stands on the front of a small white tram on a single rail among the rows of an apple orchard full of red apples at golden hour, inside a giant space colony whose land, fields and white towns curve up and overhead. She is singing. When the camera looks straight down, we see her whole body from above, standing on the tram. Fix anything vague or wrong: body shapes, anatomy, hands.
```

#### sd-cha-fix-g

Seedance 2.5 reference-to-video on Higgsfield · 5 s · 480p · $0.62 at list ($1.24 with the input video's seconds)

- **inputs:** @Video1 the grey blockout; @Image1 the sheet; @Audio1 the vocal
- **take:** 121 frames at 24 fps (5.056 s), 854×480
- **outcome:** with the camera path written out move by move, it followed H3's camera exactly but redrew H3's blob too: it keeps the shapes it is given. anabology's next note asked for a different plate altogether: "you could make the initial shot be a like greenscreen person with a mouth that lip syncs and eye movements lol. instead of gray-out - try that with h3 and make the same shot w h3 and show me before seedance".

```
@Video1 is a grey blockout of the shot: follow its camera path, its pacing and her pose. Redraw everything as a real, full-colour 35 mm film shot; do not keep its grey look or its vague shapes.

The camera path, one continuous move as in @Video1: it starts on an extreme close-up of her lips as she sings; then it whips up and back to a high view looking straight down on her and the small white tram on its single rail among the orchard rows, where she stands on the front of the tram and we see her whole body from above; then it swoops down to a low angle at her knees, looking up past her face to the land, fields and white towns curving overhead; then it swings around behind her.

⟦F1⟧

It is golden hour in an apple orchard full of red apples, inside a giant space colony whose land curves up and overhead. She sings @Audio1: her lips follow @Audio1 exactly. Fix anything vague or wrong: body shapes, anatomy, hands.

The soundtrack is @Audio1 itself, unchanged, with no music or other sounds.
```

#### sd-chags-r2v

Seedance 2.5 reference-to-video on Higgsfield · 5 s · 480p · failed, no take

- **inputs:** @Video1 the first 5 s of the green-screen plate WP_chags_s1; @Image1 the sheet; @Audio1 the vocal
- **take:** none
- **outcome:** failed at Higgsfield ("The selected parameters are not supported for this request"). It and sd-chags-edit below had already gone out.

```
@Video1 is a visual-effects green-screen plate: a performer in a green chroma-key suit and hood standing on a green stand-in box, in a green studio with white tracking crosses. Keep its camera path and pacing, her pose and movements, her eye movements. Replace everything green:
- The performer becomes Claudia, the woman in the character sheet @Image1: her face, her glossy black blunt jaw-length bob with heavy straight bangs, the one clay-orange streak through her bangs on her right side, the small flat clay-orange eight-pointed star hair clip above her left ear, the thin headset microphone at her cheek, her pale skin and freckles. The sheet only shows who she is; she wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt.
- The green box on its rails becomes the front of a small white rounded tram on a single rail.
- The green studio becomes an apple orchard full of red apples at golden hour, inside a giant space colony whose land, fields and white towns curve up and overhead. No green screen, no green suit, no tracking crosses and no studio lights remain.
Fix anything vague or wrong. Real 35 mm film, warm golden-hour light.
She sings @Audio1: her lips follow @Audio1 exactly. The soundtrack is @Audio1 itself, unchanged, with no music or other sounds.
```

#### sd-chags-edit

Seedance 2.5 video-edit on Higgsfield · 480p · $0.62 at list ($1.24 with the input video's seconds)

- **inputs:** @Video1 the green-screen plate's first 5 s; @Image1 the sheet
- **take:** 121 frames at 24 fps (5.042 s), 846×484
- **outcome:** her and the world redrawn on the plate's exact camera, pacing and mouth: the sheet's Claudia standing on a white tram, no blob; but the colony came out as a curved white arena behind the orchard, and her tank came out cropped. anabology, with Wan's redraw beside it (wanp-cha-a, below): "yeah the wan 3.0 prime actualy does it quite a bit better. The greenscreen lost all the movement and stuff tho and the seedance model had no motion ref to work off of for dancing, interacting with the environment, etc. honestly i think itd be better if the model was just the greenscreen model but in the real world, dancing, moving, etc - doing the entire thing. not in a green studio staying still. can you make that w h3"

```
@Video1 is a visual-effects green-screen plate: a performer in a green chroma-key suit and hood standing on a green stand-in box, in a green studio with white tracking crosses. Keep its camera path and pacing, her pose and movements, her eye movements and her mouth movements. Replace everything green:
- The performer becomes Claudia, the woman in the character sheet @Image1: her face, her glossy black blunt jaw-length bob with heavy straight bangs, the one clay-orange streak through her bangs on her right side, the small flat clay-orange eight-pointed star hair clip above her left ear, the thin headset microphone at her cheek, her pale skin and freckles. The sheet only shows who she is; she wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt.
- The green box on its rails becomes the front of a small white rounded tram on a single rail.
- The green studio becomes an apple orchard full of red apples at golden hour, inside a giant space colony whose land, fields and white towns curve up and overhead. No green screen, no green suit, no tracking crosses and no studio lights remain.
Fix anything vague or wrong. Real 35 mm film, warm golden-hour light.
```

#### wanp-cha-a

Wan 3.0 Prime reference-to-video on Higgsfield · 5 s · 480p · $0.34 at list ($0.68 with the input video's seconds)

- **inputs:** Image 1 the take's first frame; Image 2 the official sheet; Video 1 the first 5 s of WP_cha_s1; Audio 1 the vocal
- **take:** 150 frames at 30 fps (5.000 s), 854×480
- **outcome:** anabology had asked for it: "also try wan 3.0 prime for the redraw from the original one (it might like to diverge more - so try the one without grenscreen)." It came back close to the H3 take, blob included; anabology preferred it (sd-chags-edit, above).

```
Video 1 is the camera and pacing reference: follow its camera path, its timing, her movements and her mouth movements, but redraw everything as a new, real shot; you are free to change anything that looks wrong in it. Image 1 is the first frame. Image 2 is Claudia's character sheet, only a reference for who she is; it is never shown as a shot.

Claudia is a 28-year-old Caucasian American woman with pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs, one clay-orange streak through the bangs on her right side, a small flat clay-orange eight-pointed star hair clip above her left ear and a thin headset microphone at her cheek, exactly as in Image 2. She wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt.

She stands on the front of a small white tram on a single rail among the rows of an apple orchard full of red apples at golden hour, inside a giant space colony whose land, fields and white towns curve up and overhead. She sings Audio 1: her lips follow Audio 1 exactly. Fix anything vague or wrong: when the camera looks straight down, draw her whole body from above standing on the tram (no round blob), and fix body shapes, anatomy and hands. Real 35 mm film, warm golden-hour light.
```

#### wanp-chagsw-a

Wan 3.0 Prime reference-to-video on Higgsfield · 15 s · 480p · $1.02 at list ($2.04 with the input video's seconds)

- **inputs:** Image 1 the green-suit take's first frame redrawn as Claudia by an image edit (Gemini); Image 2 the sheet; Video 1 the green-suit-on-location take WP_chagsw_vox_s1 (15 s); Audio 1 the vocal
- **take:** 450 frames at 30 fps (15.000 s), 854×480
- **outcome:** anabology had asked: "that sounds good, i like it, can you do wan 3.0 prime w claudia in her outfit (again w character sheet) and specify to make her dancing smooth and consistent", then stopped this version: "wait what ? you can just feed it in to wan with greenscreen and tell it to redraw the green character - otherwise i think your first frame changes the background too much". It had already gone out; it came back almost the same as the version below.

```
Image 1 is the first frame. Video 1 is the motion reference: follow its camera path and timing, her dancing and every body movement, and her mouth movements. The performer in the green chroma-key suit and hood in Video 1 is only a stand-in for Claudia; no green suit, green hood or green skin appears anywhere. Image 2 is Claudia's character sheet, only a reference for who she is; it is never shown as a shot.

Claudia is a 28-year-old Caucasian American woman with pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs, one clay-orange streak through the bangs on her right side, a small flat clay-orange eight-pointed star hair clip above her left ear and a thin headset microphone at her cheek, exactly as in Image 2. In every frame she wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt.

She dances on and around the open front of a small white tram among the rows of an apple orchard full of red apples at golden hour, inside a giant space colony whose land, fields and white towns curve up and overhead. Her dancing is smooth, fluid and consistent: continuous natural motion from frame to frame, with no jitter, no sudden jumps between poses and no warping limbs; her body, face, hair and outfit stay the same the whole time. She sings Audio 1: her lips follow Audio 1 exactly. Real 35 mm film, warm golden-hour light.
```

#### wanp-chagsw-b

Wan 3.0 Prime reference-to-video on Higgsfield · 15 s · 480p · $1.02 at list ($2.04 with the input video's seconds)

- **inputs:** Video 1 the green-suit take; Image 1 the sheet; Audio 1 the vocal
- **take:** 450 frames at 30 fps (15.000 s), 854×480
- **outcome:** the green figure became Claudia in her outfit for the full 15 s, the orchard, tram, camera, dance poses and mouth kept; her streak landed on the clip's side in the close-ups ("her right side" read as the viewer's). anabology: "her dancing when the camera is moving all around is kinda.. bad, because the greenscreen dancing was off and it didnt paint in correct.y i guess try one low res seedance shot"

```
Video 1 is the shot: keep its camera path and timing, the place (the apple orchard, the white tram on its rail, the land curving overhead, the golden light) and the performer's dancing, every body movement and her mouth movements. Redraw the performer in the green chroma-key suit and green hood as Claudia; no green suit, green hood or green skin remains anywhere. Image 1 is Claudia's character sheet, only a reference for who she is; it is never shown as a shot.

Claudia is a 28-year-old Caucasian American woman with pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs, one clay-orange streak through the bangs on her right side, a small flat clay-orange eight-pointed star hair clip above her left ear and a thin headset microphone at her cheek, exactly as in Image 1. In every frame she wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt.

Her dancing is smooth, fluid and consistent: continuous natural motion from frame to frame, with no jitter, no sudden jumps between poses and no warping limbs; her body, face, hair and outfit stay the same the whole time. She sings Audio 1: her lips follow Audio 1 exactly. Real 35 mm film, warm golden-hour light.
```

#### sd-chagsw-a

Seedance 2.5 video-edit on Higgsfield · 480p · $0.62 at list ($3.71 with the input video's seconds)

- **inputs:** @Video1 the green-suit take (361 frames); @Image1 the sheet
- **take:** 361 frames at 24 fps (15.042 s), 846×484
- **outcome:** a cleaner body than Wan's in places (a clean high kick at 2.8 s where Wan folded her legs) but H3's steps kept exactly, and a smear of green suit at 3.9 s. anabology, with Wan's take beside it: "yeah seedance is worse overall.oh yeah good idea on h3 motion ref. we should find some dance clips"

```
@Video1 is a visual-effects take filmed on location: a performer in a green chroma-key suit and hood dances and sings on and around the white tram in the apple orchard. Keep its camera path and pacing, the place and its light, and her mouth movements, so her singing stays in sync. Redraw the green performer entirely as Claudia, the woman in the character sheet @Image1: her face, her glossy black blunt jaw-length bob with heavy straight bangs, one clay-orange streak through her bangs on the left side of the frame when she faces the camera, a small flat clay-orange eight-pointed star hair clip on the other side above her ear, a thin headset microphone at her cheek, her pale skin and freckles. The sheet only shows who she is; in every frame she wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt. No green suit, green hood or green skin remains anywhere.

Fix her dancing: wherever the performer's body or movement in @Video1 is vague, broken or awkward, especially while the camera flies around her, redraw it as smooth, natural, well-formed dancing that flows with the music, with correct anatomy, whole arms, legs and hands, and the same body from frame to frame. Fix anything else that looks wrong. Real 35 mm film, warm golden-hour light.
```

The lesson the lead took (and the project notes keep): an edit or reference pass copies a realistic source in both modes; a short, loose prompt does not change that; a grey blockout makes Seedance redraw but loosens the camera. The next step was a cleaner source: the green-suit performer on location, then real dance clips as H3's motion reference (section 1).

## 3. Wan 3.0 Prime: the first film pass

anabology's plan, with the song locked: "i want you to basically shoot the entire video twice - you can previz with […] and you can master with seedance AFTER you animate. i think one great thing about seedance is that you can take something thats already been made, and use seedance 2.5 to re-render the entire scene with way more description (adn see the prompt skill of course) - like, you can animate something with solid colors that you want to come out as refracting glass, and just tell seedfance to make the animated parts refracting glass (With a lot more prompt detail). so i think if you do teh entire video twice, it will be best. you could use a cheaper model like wan 3.0 prime on higgsfield first pass then second pass seedance 2.5 to master." After the go (section 1), each H3 take of the film (section 1) went to Wan 3.0 Prime as it landed, with our code-drawn layer on top: flat, untextured shapes (letters on the field, numerals on the stones, the tower's lit windows, floating capsules) that the prompt names as real things (`tools/film/gen_wan.py`, `tools/film/anim.py`). Higgsfield's `alibaba/wan-3.0-prime/reference-to-video`, 720p 16:9, no generated audio, the duration the take's whole seconds (Wan's input video is capped at 15 s). Video 1 = the take with the layer, cut to ≤ 15 s; Image 1 = the official character sheet (B2 and B1 for the last two); Audio 1 = the take's vocal window. Every take came back at 1280 × 720, 30 fps, exactly as long as asked. Shared paragraphs:

⟦W1⟧
```
Video 1 is the shot: keep its camera path and timing, the place and everything in it, the performer's dancing and every body movement, and her mouth movements. Redraw the performer in the green chroma-key suit and green hood as Claudia; no green suit, green hood or green skin remains anywhere. Image 1 is Claudia's character sheet, only a reference for who she is; it is never shown as a shot.
```

⟦W2⟧
```
Claudia is a 28-year-old Caucasian American woman with pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs, one clay-orange streak through the bangs on the left of the frame when she faces the camera, a small flat clay-orange eight-pointed star hair clip on the other side above her ear, and a thin headset microphone at her cheek, exactly as in Image 1. In every frame she wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt. Her movement and dancing are smooth, fluid and consistent: continuous natural motion from frame to frame, with no jitter, no sudden jumps and no warping limbs; her body, face, hair and outfit stay the same the whole time. She sings Audio 1: her lips follow Audio 1 exactly.
```

⟦W3⟧
```
It looks like real 35 mm film photography with warm 1970s colour and fine grain, a real place filmed with a real camera.
```

⟦W4⟧
```
Claudia is a 28-year-old Caucasian American woman with pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, exactly as in the FRONT view of Image 1: the streak starts at the parting on her right side, which is the LEFT side of the frame when she faces the camera, and the small flat clay-orange eight-pointed star hair clip sits on the opposite side, above her left ear, on the RIGHT side of the frame; the streak and the clip are never on the same side. A thin headset microphone sits at her cheek. In every frame she wears a white sleeveless ribbed tank top and high-waisted orange wide-leg trousers with a thin orange belt. Her movement and dancing are smooth, fluid and consistent: continuous natural motion from frame to frame, with no jitter, no sudden jumps and no warping limbs; her body, face, hair and outfit stay the same the whole time. She sings Audio 1: her lips follow Audio 1 exactly.
```

⟦W5⟧
```
The flat, untextured shapes drawn in Video 1 are placeholders for real things: the small flat white capsule shapes floating in the air around her are tiny liquid-glass pills: perfectly clear, refracting the scene behind them, their rounded edges catching sharp rainbow glints in the sun, each one throwing a small moving caustic sparkle onto whatever its light falls on; they drift weightlessly and swell slightly on the beat.
```

⟦W6⟧
```
Re-light it at golden hour: the giant glossy capsules mirror the sunset in long streaked highlights and throw coloured light, red from one side and blue from the other, onto the wheat and onto her; a warm rim light; the white pill in her fingers catches a sharp glint; a lens flare as the camera dives.
```

⟦W7⟧
```
Video 1 is the shot: keep its camera path and timing, the place and everything in it, the performer's dancing and every body movement, and her mouth movements. Redraw the performer in the green chroma-key costume and green hood as Claudia; no green costume, green hood or green skin remains anywhere. Image 1 is Claudia's character sheet, only a reference for who she is; it is never shown as a shot.
```

#### wanf-T01

Wan 3.0 Prime reference-to-video · 11 s · 720p · T01 · $1.54 at list ($3.06 with the input video's seconds)

- **take:** 330 frames at 30 fps (11.000 s), 1280×720
- **note:** the bedroom at the colony's first sunrise; the cut opened on a 0.4 s close-up of her eyes before the room.

```
⟦W1⟧

⟦W2⟧

Re-light it as the colony's first sunrise: a low warm sun rises in one of the long window strips far up the curving land and throws long golden shafts through the huge round window across the bed; volumetric god rays full of floating dust, soft bloom on the white linen, a warm rim light on her hair and shoulders, a gentle anamorphic lens flare when the camera crosses the sun, the shadows a soft cream bounce, the land outside in pale blue-gold haze.

⟦W3⟧
```

#### wanf-T02

Wan 3.0 Prime reference-to-video · 15 s · 720p · T02 · submitted twice · $4.20 at list ($8.40 with the input video's seconds)

- **take:** take-1: 450 frames at 30 fps (15.000 s), 1280×720; take-2: 450 frames at 30 fps (15.000 s), 1280×720
- **note:** submitted twice: take 1 with an earlier description of the letters on the field (not kept in the job file), take 2 with the description below, the WHITEPILL letters mown into the wheat.

```
⟦W1⟧

⟦W2⟧

The flat, untextured shapes drawn in Video 1 are placeholders for real things: the flat golden band on the land far below is a field of standing golden wheat, and the flat cream letters on it spell WHITEPILL, mown into the wheat: each of the nine letters W H I T E P I L L is a broad stripe of freshly cut pale stubble, shorter and paler than the standing wheat around it, with crisp edges, so the word reads clearly and exactly as drawn; the raking golden light casts long shadows along every cut row.

Re-light it at golden hour inside the colony: sunlight pours through the long window strips in parallel shafts that cross the whole curving land; layers of warm haze give the land depth; the far land overhead glows in soft blue-gold atmospheric perspective; the terrace stone glows warm; a warm backlight rims her hair; soft halation and lens flares when the sun crosses the lens; the word in the wheat catches raking light so every cut furrow casts a long shadow.

⟦W3⟧
```

#### wanf-T03

Wan 3.0 Prime reference-to-video · 13 s · 720p · T03 · $1.82 at list ($3.54 with the input video's seconds)

- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **note:** the "50%" drawn on the stone blocks did not survive Wan.

```
⟦W1⟧

⟦W2⟧

The flat, untextured shapes drawn in Video 1 are placeholders for real things: in the first second the flat dark-grey numerals 50% laid across the faces of the row of white stone blocks are carved deep into the weathered limestone, one character per block, with chisel marks, soft edges worn by weather, lichen in the grooves and deep shadow inside every cut.

Re-light it in the last golden hour with the sun low behind the stone zero: its light pours through the hole of the ring and makes a bright halo around the ring's rough edge; long shadows of the monuments stretch across the poppies; the backlit wheat glows; pollen drifts in the light; a warm rim light outlines her; a soft lens flare blooms as the camera flies through the ring.

⟦W3⟧
```

#### wanf-T04

Wan 3.0 Prime reference-to-video · 11 s · 720p · T04 · $1.54 at list ($3.06 with the input video's seconds)

- **take:** 330 frames at 30 fps (11.000 s), 1280×720

```
⟦W1⟧

⟦W2⟧

Re-light it with the sun low and to the side, raking across the stair so each carved number is cut out by deep shadow; warm haze over the meadow; a moving glint of sun runs along the stone edges as the camera passes; the poppies glow backlit; a warm rim light on her.

⟦W3⟧
```

#### wanf-T06

Wan 3.0 Prime reference-to-video · 14 s · 720p · T06 · submitted twice · $3.92 at list ($7.75 with the input video's seconds)

- **take:** take-1: 420 frames at 30 fps (14.000 s), 1280×720; take-2: 420 frames at 30 fps (14.000 s), 1280×720
- **note:** submitted twice: take 1 with an earlier description of the tower's windows, take 2 with the one below (the windows going dark row by row on the beat).

```
⟦W1⟧

⟦W4⟧

The flat, untextured shapes drawn in Video 1 are placeholders for real things: on the face of the distant office tower the flat warm-yellow bars are its rows of lit office windows and the flat dark-grey bars are the same windows switched off: from about the eighth second, row by row from the top floor down, on every beat of the music, the lights go out and each dark row becomes plain dark glass reflecting the sunset, until the whole tower is dark: the nine-to-five is over.

Re-light it at sunset: the sky turns deep orange; the brass hands flash with sharp glints as they move; the clock face glows warm; in the distance the office tower's windows switch off floor by floor, each going dark with a soft flicker; long shadows across the meadow; a hazy glow around the sun.

⟦W3⟧
```

#### wanf-T05

Wan 3.0 Prime reference-to-video · 14 s · 720p · T05 · $1.96 at list ($3.87 with the input video's seconds)

- **take:** 420 frames at 30 fps (14.000 s), 1280×720

```
⟦W1⟧

⟦W4⟧

Re-light it in soft golden late-afternoon light: the chapel's smoke, lit from behind, glows white-gold; the robots' white shells pick up gleaming highlights; at the sofa a warm pool of sunlight falls on her while the chalk wall is lit at a grazing angle so the chalk lines glow; dust motes and soft bloom in the air.

⟦W3⟧
```

#### wanf-T07

Wan 3.0 Prime reference-to-video · 11 s · 720p · T07 · $1.54 at list ($3.06 with the input video's seconds)

- **take:** 330 frames at 30 fps (11.000 s), 1280×720
- **note:** the first take with the floating glass pills drawn on.

```
⟦W1⟧

⟦W4⟧

⟦W5⟧

Re-light it at golden hour in the orchard: the low sun flickers through the apple trees in moving dappled light; the white tram glows with soft bloom; sun shafts slant through the leaves; the land overhead is hazy blue-gold; lens flares when the camera faces the sun; a warm rim light on her hair.

⟦W3⟧
```

#### wanf-T08-v1

Wan 3.0 Prime reference-to-video · 13 s · 720p · T08 · $1.82 at list ($3.63 with the input video's seconds)

- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **note:** the capsules with the floating pills; the job file of this first T08 run is `shots/wanf-T08-v1.json`.

```
⟦W1⟧

⟦W4⟧

⟦W5⟧

⟦W6⟧

⟦W3⟧
```

#### wanf-T09

Wan 3.0 Prime reference-to-video · 12 s · 720p · T09 · $1.68 at list ($3.30 with the input video's seconds)

- **take:** 360 frames at 30 fps (12.000 s), 1280×720

```
⟦W1⟧

⟦W4⟧

Re-light it in bright warm afternoon light: the white castle stones glow; the robots' white shells gleam; sun shafts fall through the long window strips; soft shadows; a sparkle runs across the gold crown.

⟦W3⟧
```

#### wanf-T10

Wan 3.0 Prime reference-to-video · 11 s · 720p · T10 · $1.54 at list ($3.06 with the input video's seconds)

- **take:** 330 frames at 30 fps (11.000 s), 1280×720
- **note:** sent by the batch script once its H3 take and drawing were ready.

```
⟦W1⟧

⟦W4⟧

Re-light it in bright warm late-afternoon light: sunlight flickers through the orchard over the car's glossy white body in moving reflections; at the schoolhouse warm low light comes through the porch, dust floats in the air, and the blackboard is lit at a grazing angle.

⟦W3⟧
```

#### wanf-T11

Wan 3.0 Prime reference-to-video · 8 s · 720p · T11 · $1.12 at list ($2.24 with the input video's seconds)

- **take:** 240 frames at 30 fps (8.000 s), 1280×720
- **note:** sent with T10.

```
⟦W1⟧

⟦W4⟧

Re-light it in soft warm afternoon light: the white linen glows; the sheer curtains of the four-poster sway and diffuse the sun into soft beams; the brass punch clock glints; the gold crown sparkles.

⟦W3⟧
```

#### wanf-T08

Wan 3.0 Prime reference-to-video · 13 s · 720p · T08 · $1.82 at list ($3.63 with the input video's seconds)

- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **note:** the T08 test after the audit: Video 1 the new H3 take 8 (the loose green costume, the 1970s disco class) with the pills drawn on; Image 1 the new outfit sheet B2 (GPT Image 2.5). Her build was back on the canon (the trousers moving like the sheet's); the top still showed through, and her streak still drifted to the clip's side in the close-ups.

```
⟦W7⟧

Claudia is a 28-year-old Caucasian American woman with pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, exactly as in the FRONT view of Image 1: the streak starts at the parting on her right side, which is the LEFT side of the frame when she faces the camera, and the small flat clay-orange eight-pointed star hair clip sits on the opposite side, above her left ear, on the RIGHT side of the frame; the streak and the clip are never on the same side. A thin headset microphone sits at her cheek. She has the slim, slender build of Image 1: thin arms and legs, a narrow waist and narrow hips. In every frame she wears exactly the outfit of Image 1: a plain white tank top of thick, heavyweight, opaque cotton (smooth, not ribbed, nothing shows through it) tucked into high-waisted orange wide-leg trousers with a thin orange belt. Her movement and dancing are smooth, fluid and consistent: continuous natural motion from frame to frame, with no jitter, no sudden jumps and no warping limbs; her body, face, hair and outfit stay the same the whole time. She sings Audio 1: her lips follow Audio 1 exactly.

⟦W5⟧

⟦W6⟧

⟦W3⟧
```

#### wanf-T08b

Wan 3.0 Prime reference-to-video · 13 s · 720p · T08 · $1.82 at list ($3.63 with the input video's seconds)

- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **note:** the same with sheet B1 and the top rewritten as thicker, lined cotton. Neither problem moved. It went out without a fresh OK; anabology: "whats the prompt for the wan 3.0 prime gen? […]"

```
⟦W7⟧

Claudia is a 28-year-old Caucasian American woman with pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, exactly as in the FRONT view of Image 1: the streak starts at the parting on her right side, which is the LEFT side of the frame when she faces the camera, and the small flat clay-orange eight-pointed star hair clip sits on the opposite side, above her left ear, on the RIGHT side of the frame; the streak and the clip are never on the same side. A thin headset microphone sits at her cheek. She has the slim, slender build of Image 1: thin arms and legs, a narrow waist and narrow hips. In every frame she wears exactly the outfit of Image 1: a plain white sleeveless tank top of thick, double-layered, lined cotton with a white bra underneath, so the front of the top is perfectly smooth and flat and nothing shows through it, tucked into high-waisted orange wide-leg trousers with a thin orange belt. Her movement and dancing are smooth, fluid and consistent: continuous natural motion from frame to frame, with no jitter, no sudden jumps and no warping limbs; her body, face, hair and outfit stay the same the whole time. She sings Audio 1: her lips follow Audio 1 exactly.

⟦W5⟧

⟦W6⟧

⟦W3⟧
```

The first half (T01–T09) was cut on the song: every world read, her look held in the white tank and orange trousers, the pills showed in the chorus, and every reshoot sat within 0.07 s of its H3 take. Her streak landed on the clip's side in most close-ups (Wan copying the official sheet's close-up panels; naming the side in the prompt did not move it). None of these takes is in any later cut.

## 4. Take 8: animation, lyric stills and grey boxes

Take 8 (song 84.17–96.69 s: "The most likely outcome / Red pill, blue pill / I'm the white pill / Smarter than you, love you still", the capsule meadow) was where the method was worked out. All on Higgsfield, 13 s at 720p, Audio 1 = the vocal window, Image 1 = the big front face from her face sheet and Image 2 = the A1 dress from four sides (except where noted); Video 1 = the H3 take, with or without our drawing on it. The paragraphs these prompts share with each other and with the rollout (section 5):

⟦L1⟧
```
Redraw the performer in the green chroma-key balaclava as Claudia: no green balaclava, green fabric or green skin remains anywhere, and her face, hair and head are fully visible. Image 1 is Claudia's face and Image 2 is her dress; they are only references for who she is and what she wears, and neither is ever shown as a shot.
```

⟦L2⟧
```
Re-light it at golden hour: the giant glossy capsules mirror the sunset in long streaked highlights and throw coloured light, red from one side and blue from the other, onto the wheat and onto her; a warm rim light; the white pill in her fingers catches a sharp glint; a lens flare as the camera dives.
```

⟦L3⟧
```
It looks like real 35 mm film photography with warm 1970s colour and fine grain, a real place filmed with a real camera.
```

⟦L4⟧
```
Video 1 is the shot. Keep its camera path and timing, the place and everything in it, the performer's dancing and every body movement, and her mouth movements; it is one continuous take.
```

⟦L5⟧
```
Claudia is a 30-year-old Caucasian American woman with a grown-up angular face, pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, exactly as in Image 1: the streak starts at the parting on her right side, which is the LEFT side of the frame when she faces the camera, and the small flat clay-orange eight-pointed star hair clip sits on the opposite side, above her left ear, on the RIGHT side of the frame; the streak and the clip are never on the same side. A thin headset microphone sits at her cheek. She is very tall and very skinny, with long thin legs, thin arms and a narrow waist. In every frame she wears exactly the dress of Image 2: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs, a smocked back and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. She looks happy and full of joy: her eyes smile, and she smiles warmly between the sung lines. Her movement is smooth and consistent, with no jitter, no sudden jumps and no warping limbs. She sings Audio 1: her lips follow Audio 1 exactly.
```

⟦L6⟧
```
Redraw the performer in the green chroma-key balaclava as Claudia: no green balaclava, green fabric or green skin remains anywhere, and her face, hair and head are fully visible. Image 1 is Claudia's face and Image 2 is her dress; they are only references for who she is and what she wears.
```

#### wanf-T08-v8

Wan 3.0 Prime reference-to-video · 13 s · 720p · $1.82 at list ($3.63 with the input video's seconds)

- **for:** anabology, on the last of the take-8 tests (WPF8_T08, section 1): "But for this you can run one wan 3.0 prime and tell it to merge it and fill in cuts with continuous camera movement so it's one cut with the same pacing. Try that rq with the face replacement etc"
- **inputs:** Video 1 the H3 take WPF8_T08_s1 (the A1 dress, the new dancer, the balaclava; two hard cuts)
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** the face replacement worked; Wan kept both of H3's cuts. anabology: "ok it still cut so we'll need to just do h3 til we get them without cuts. looks good tho overall (would just maybe make her a little happier)."

```
Video 1 is the shot. Keep its pacing and timing, the place and everything in it, the performer's dancing and every body movement, and her mouth movements. Video 1 has two hard cuts, at about 2.9 seconds and at about 9.1 seconds. Make the target video one single continuous take with no cuts at all: where Video 1 cuts, the camera instead travels fluidly and continuously from the earlier viewpoint to the next one. At 2.9 seconds it makes a fast, smooth push-in from the full shot of her between the capsules into the close-up of her face beside the small white pill; at 9.1 seconds it makes another fast, smooth push-in from the full shot into the close-up. Every moment of Video 1 still happens at the same time, with the same pacing. The camera moves like a high-speed industrial robotic arm: fast, machine-precise and perfectly smooth, with no shake.

⟦L1⟧

Claudia is a 30-year-old Caucasian American woman with a grown-up angular face, pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, exactly as in Image 1: the streak starts at the parting on her right side, which is the LEFT side of the frame when she faces the camera, and the small flat clay-orange eight-pointed star hair clip sits on the opposite side, above her left ear, on the RIGHT side of the frame; the streak and the clip are never on the same side. A thin headset microphone sits at her cheek. She is very tall and very skinny, with long thin legs, thin arms and a narrow waist. In every frame she wears exactly the dress of Image 2, shown there from the front, the three-quarter view, the side and the back: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs, a smocked back and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. Her movement and dancing are smooth, fluid and consistent: continuous natural motion from frame to frame, with no jitter, no sudden jumps and no warping limbs; her body, face, hair and dress stay the same the whole time. She sings Audio 1: her lips follow Audio 1 exactly.

⟦L2⟧

⟦L3⟧
```

#### wanf-T08-v9anim

Wan 3.0 Prime reference-to-video · 13 s · 720p · submitted twice · $1.82 at list for the request that ran

- **for:** anabology, on the v9 previz: "we should fully animate one single scene, then give wan 3.0 prime the animated scene, the dancer reference (maybe as gray cutout), the face sheet, and tell it to relight and redraw the animations (like, we can use some aesthetic that amkes sense - remember I was like just basic lines to liquid glass before as an example. But don't need to use that aesthetic)"
- **inputs:** Video 1 the v9 H3 take WP9_T08_s1 with a 2D layer drawn on (`tools/film/anim_t08v9.py`: floating pills, a red and a blue ring, a white disc behind her head). The first request also carried the dancer clip as a second video and was refused (Higgsfield caps the total length of reference videos); the second went without it.
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** anabology: "for references - can we add image refs? it looks good but a few notes: 1- it followed the pills animation too closely - like, it moved the pills around perfectly with the animation, so despite relighting them they still looked a little amateuirsh. 2- we dont ahve lyrics here and we fly around a lot. i want it to be a lyrics vid. i think. a solution to this could be showing the frames int he middle with the animations and saying 'add these at these times' with frames as reference for what it should look like […]"

```
⟦L4⟧

⟦L1⟧

⟦L5⟧

The flat, untextured shapes drawn over Video 1 are placeholders for real things, each exactly in its place and at its time. The small flat white capsule shapes floating in the air around her are liquid-glass pills: perfectly clear glass capsules that refract and magnify the field and the sky behind them, their rounded edges catching sharp rainbow glints in the low sun, each throwing a small moving caustic sparkle onto whatever its light falls on; they float weightlessly, drift past her and swell slightly on every beat. At about 5 seconds the flat red rings bursting out of the giant red capsule are a ring of red light rippling outward through the air like a shockwave of heat-shimmer, bending the light behind it; at about 6 seconds the same happens in blue from the giant blue capsule. At about 8 seconds the flat white disc and ring that open behind her head are a soft bloom of white light behind her, a glowing halo of haze with a thin ring of light expanding outward, and a gentle lens flare.

⟦L2⟧

⟦L3⟧
```

#### wanf-T08-v9lyrics

Wan 3.0 Prime reference-to-video · 13 s · 720p · $1.82 at list ($3.63 with the input video's seconds)

- **for:** the lyrics as objects in the scene, added by Wan from stills at given times; anabology: "ok go ahead run it"
- **inputs:** Video 1 the clean H3 take (no drawing); Images 3–7 five GPT Image 2.5 stills of frames of the take with the line in place (`tools/film/lyric_stills.py`)
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** anabology: "yeah pretty good instruction following, but i think the issue is the composition  in the image model frames from the references- like the words are kinda place haphazardly in space on the image side. its like, fine for the signle frame but not a good composition in 3d space […] but this is the best method so far -- h3 previz the way we did it -> animate + image models -> wan 3.0 prime video."

```
⟦L4⟧

⟦L6⟧

⟦L5⟧

This is a lyric video. Images 3, 4, 5, 6 and 7 show how this shot looks at five moments, with the song's lyrics added as real three-dimensional objects in the scene; they are references for what the lyrics look like and where they stand, never shown as shots. Add each lyric at its time, anchored in the 3D space of the field: the letters never slide with the camera, the camera moves past them and sees them from new angles as it flies around her. From 0.7 to 3.4 seconds, as she sings 'The most likely outcome', the words THE MOST LIKELY OUTCOME stand in the air between the two giant capsules, huge glossy white letters in two lines, as in Image 3. At 5.1 seconds, on 'Red pill', the words RED PILL in glossy red lacquered letters appear in the air beside the giant red capsule, as in Image 4. At 6.0 seconds, on 'blue pill', the words BLUE PILL in glossy deep-blue lacquered letters appear beside the giant blue capsule, as in Image 5. From 7.5 to 8.5 seconds, on 'I'm the white pill', the words I'M THE WHITE PILL in glowing milky-white glass letters arc in the air just above and behind her head like a halo, with a soft bloom of white light, as in Image 6. From 8.6 to 12.3 seconds, on 'Smarter than you, love you still', the words SMARTER THAN YOU, LOVE YOU STILL float in two lines far behind her over the field, softly out of focus, as in Image 7. Each lyric rises smoothly into place on its first word and fades away after its line. The letters are spelled exactly as shown, set in a bold grotesque sans-serif in capitals; they are physical objects that catch the sunlight, reflect the sky and cast soft shadows. Small clear liquid-glass capsules float weightlessly in the air around her, fixed in the space of the field, as in the images.

⟦L2⟧

⟦L3⟧
```

#### wanf-T08-v9code

Wan 3.0 Prime reference-to-video · 13 s · 720p · $1.82 at list ($3.63 with the input video's seconds)

- **for:** anabology, on the lyric stills: "honeslty, i think id rather make the stills with code and tell wan to do the hard work fo aligning it properly in space, amking it 3d and rendering it in-composition with lighting", and then: "Well wait we also probably want some of the animation and like drawings to say where the glass pills are floating and the other effects wan needs to add"
- **inputs:** Images 3–7 five flat layout sketches drawn in code (the line, the pills, the rings, the halo, on the take's frames)
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** Wan copied the sketches' flat look. anabology: "maybe try the blender run really quick and then we can pick one approach and move on"

```
⟦L4⟧

⟦L6⟧

⟦L5⟧

This is a lyric video. Images 3, 4, 5, 6 and 7 are flat layout sketches of this same shot at five moments (the performer in the green balaclava in them is Claudia). They show which lyric appears at each moment and roughly where it stands, where small glass pills float, and where light effects happen. They are flat 2D drawings: build everything they show as real three-dimensional objects and light in the scene, properly aligned in the space of the field and lit with the shot, fixed in place so that the camera flies past them and sees them from new angles. From 0.7 to 4.8 seconds, as she sings 'The most likely outcome', the words THE MOST LIKELY OUTCOME stand in two rows between the two giant capsules, tall glossy white letters standing on the field, as sketched in Image 3. At 5.1 seconds, on 'Red pill', the words RED PILL in glossy red lacquered letters rise out of the wheat in the open field, as sketched in Image 4, and at the same moment the red ring sketched around the giant red capsule is a ring of red light rippling outward through the air from the capsule like a shockwave. At 6.0 seconds, on 'blue pill', the words BLUE PILL in glossy deep-blue lacquered letters rise at the foot of the giant blue capsule, as sketched in Image 5, with a ring of blue light rippling outward from the blue capsule in the same way. From 7.5 to 8.5 seconds, on 'I'm the white pill', the words I'M THE WHITE PILL in glowing milky-white glass letters rise out of the wheat in the foreground between her and the camera, as sketched in Image 6, and the white disc sketched behind her head is a soft bloom of white light glowing behind her. From 8.6 to 12.3 seconds, on 'Smarter than you, love you still', the words SMARTER THAN YOU, LOVE YOU STILL stand in two rows far behind her on the field, softly out of focus, as sketched in Image 7. Each line rises smoothly out of the wheat into place on its first word and sinks away when the next line begins; RED PILL and BLUE PILL stay up together until 'I'm the white pill'. The small flat white capsule shapes in the sketches are clear liquid-glass pills floating weightlessly in the air at those places around her, refracting the field and the sky, catching sharp glints of the low sun and drifting slowly. Every word is spelled exactly as written, in a bold grotesque sans-serif in capitals, and every letter is a solid physical object that catches the sunlight, reflects the sky and casts a soft shadow on the wheat.

⟦L2⟧

⟦L3⟧
```

**The grey boxes.** anabology, on the code sketches: "wait i thoiught youd just make like a wireframe ish recreation of the environment. like i imagien you have a gray area, you have a preson in the middle as a dancer, a blue pill on left and red pill on right, then you show a few different views of where the 3d stuff is an dyou put the 3d stuff in there anaslytically/perfectly so wer'er not just doing it by eye anymore. like the idealized envioronemtanl layout with no details"; then: "Yeah you should describe in great depth the material selections and lighting effects on the letters. Then yes run it" and "Well wait maybe load the seedream prompting guide because that structures it more." The set was rebuilt as a clay model in Blender (her as a mannequin, the capsules, the letters placed at measured coordinates) and rendered from the H3 camera at each lyric moment; the prompt moved to the Seedance 2.5 guide's labelled sections (Wan accepts prompts up to 20,000 characters). The four grey-box runs share one prompt that was edited between runs; the last one (grey4, also run on Seedance) is given in full below, and the earlier runs are described by what was different.

#### wanf-T08-v9grey

Wan 3.0 Prime reference-to-video · 13 s · 720p · $1.82 at list ($3.63 with the input video's seconds)

- **inputs:** Images 3–7 an overview of the clay set with every lyric, and views at 1.7, 7.6, 8.2 and 10.6 s; the lyrics in a bold grotesque like Helvetica Bold, white porcelain and red and blue lacquer; a whole-second event script; each lyric spelled letter by letter; an exclusions section
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** the lyrics stood where the grey box put them and stayed pinned in 3D through the camera move, all spelled right; but the rings and RED PILL / BLUE PILL were up for the whole take (the overview with everything at once read as the permanent set), and the white letters came out grey (the clay leaked). anabology: "yeah it totally works i think. its just that in this case the lyrics/font weren't perfect. agreed on your fixes, but also look at […] and choose one that fits, make the lyrics a bit bigger. then run it"

#### wanf-T08-v9grey2

Wan 3.0 Prime reference-to-video · 13 s · 720p · $1.82 at list ($3.63 with the input video's seconds)

- **changes:** Pilcrow Rounded Heavy (strokes ending in round caps), lyrics about 1.2–1.5× bigger, Image 3 the set only, one view per lyric moment including 5.4 s, RED PILL moved into the open field, white letters rendered white, firmer timing words
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** the timing held (nothing up before its word); the letters big, white glossy porcelain and red/blue lacquer, pinned in 3D. Still off: I'M THE WHITE PILL only from about 9 s, a ghosted frame at about 6.4 s. anabology: "id say this one was a bit worse than all the ones before. the firm language should go, what other 'fixes' did you put in?"

#### wanf-T08-v9grey3

Wan 3.0 Prime reference-to-video · 13 s · 720p · $1.82 at list ($3.63 with the input video's seconds)

- **changes:** anabology: "use the font and bigger sizes and white lettters. and tell it to make them made of glass of specific colors. revert everything else." = the first grey run with the font, bigger letters (THE MOST LIKELY 0.38 m, RED PILL 0.45 m, BLUE PILL 0.40 m, I'M THE WHITE PILL 0.19 m, SMARTER 0.20 m), white letters in the layout, and glass colours: clear crystal, ruby red, cobalt blue, milky opal white, pale rose pink
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** glass letters in their colours; the rings up all take again; RED PILL hidden behind her at 5.4 s; BLUE PILL, I'M THE WHITE PILL and RED PILL piled into one row at 7.6 s. anabology: "i like the letter look better and it followed instructions a little bit better but it got the text placement wron gat the end (BLUE PILL is half blue half redand its just one thing rather than both - we probably could ahve stronger scene references from blender). try to clean up the blender views one more time because honestly gb3_sheet is quite hard to follow lol. […] it should be more of a placement reference than shot reference, so muiltiple views of the entire thing might be useful and just say the letters appear as the lyrics are read in order"

#### wanf-T08-v9grey4

Wan 3.0 Prime reference-to-video · 13 s · 720p · $1.82 at list ($3.63 with the input video's seconds)

- **changes:** Image 3 a PLACEMENT SHEET (five views of the whole set) and Image 4 an ORDER SHEET (from the front, steps 0–5); anabology, on the new views: "these are good, id give it the sheet entirely and then also give it one sheet that show sthem being added in order from front on and its labeled ORDER SHEET or something"
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** RED PILL now a separate word in the field; I'M THE WHITE PILL big and glowing with the halo. Off: OUTCOME spelled OUT-COME (likely from the hyphenated spelling line), BLUE PILL barely there, SMARTER early, the rings and halo up to the end: what a sheet shows at once tends to stay.

```
[Generation objective] Re-shoot Video 1 as a live-action music video: Claudia (Images 1 and 2) sings Audio 1 and dances in a golden-hour wheat field full of red poppies, between two giant glossy capsules, one blue and one red, while the lines of the song stand in the field as large, solid, three-dimensional letters at the places and times set below. One continuous take with Video 1's camera movement and timing.

[Reference assets]
- Video 1 is the shot: keep its camera path, framing and timing, the place and everything in it, the performer's dancing and every body movement, and her mouth movements. It is one continuous take with no cuts.
- Audio 1 is Claudia's own singing voice: her lips follow Audio 1 word by word.
- Image 1 is Claudia's face and Image 2 is her dress, references only for who she is and what she wears.
- Image 3 is the PLACEMENT SHEET: a plain clay layout model of this same set, seen whole from five angles (front, high front, three-quarter left, three-quarter right and from above), with every lyric and every effect in its place at once. It shows only where things are: the position, size, height, angle and spacing of each lyric and effect in the field, and the letterforms. Take nothing else from it: none of its grey floor, flat grey light, mannequin or labels appears in the video.
- Image 4 is the ORDER SHEET: the same model from the front, step by step, showing the order in which the lyrics appear.
- In both sheets: the grey mannequin is Claudia; the tall blue capsule is the giant blue capsule of Video 1 and the tall red capsule is the giant red capsule; the grey floor is the wheat field; the small pale-blue capsules are the floating glass pills; the white letters are the lyric objects (white only in the model, which shows their shape and place, not their colour); the red and blue hoops round the capsules are the rings of light; the pale ring behind the mannequin's head marks the halo.

[Subject] Redraw the performer in the green chroma-key balaclava as Claudia: no green balaclava, green fabric or green skin remains anywhere, and her face, hair and head are fully visible. Claudia is a 30-year-old Caucasian American woman with a grown-up angular face, pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, exactly as in Image 1: the streak starts at the parting on her right side, the LEFT side of the frame when she faces the camera, and the small flat clay-orange eight-pointed star hair clip sits above her left ear, on the RIGHT side of the frame; the streak and the clip are never on the same side. A thin headset microphone sits at her cheek. She is very tall and very skinny, with long thin legs, thin arms and a narrow waist. In every frame she wears exactly the dress of Image 2: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. She looks happy and full of joy: her eyes smile, and she smiles warmly between the sung lines. Her movement is smooth and consistent, with no jitter, no sudden jumps and no warping limbs.

[Event script] Video 1 gives the camera path, the timing and her performance. The lyric letters appear as the lyrics are sung in Audio 1, one line after another in the order of the ORDER SHEET: first THE MOST LIKELY OUTCOME; then RED PILL, with a ring of red light around the giant red capsule; then BLUE PILL, with a ring of blue light around the giant blue capsule; then I'M THE WHITE PILL, with the halo behind her head; then SMARTER THAN YOU, LOVE YOU STILL. Each line rises into its place on its first word and goes when the next line comes; RED PILL and BLUE PILL stay up together.

[Lyric objects: material and light] All five lines are set in the typeface of the layout model: a heavy rounded sans-serif in capitals whose strokes end in round caps. Every letter is a solid, heavy, real object about a fifth as deep as it is tall, with crisp edges and a slim rounded bevel that catches a thin bright line of light; letters never bend, wobble or melt. Spell each line exactly, letter by letter, as the layout model shows: T-H-E M-O-S-T L-I-K-E-L-Y O-U-T-C-O-M-E; R-E-D P-I-L-L; B-L-U-E P-I-L-L; I-'-M T-H-E W-H-I-T-E P-I-L-L; S-M-A-R-T-E-R T-H-A-N Y-O-U, L-O-V-E Y-O-U S-T-I-L-L. Every letter is made of thick, solid, polished glass, and each line has its own colour of glass.
- THE MOST LIKELY OUTCOME floats in two rows between the two giant capsules, across their upper half: letters about one and a half times the height of her head, in clear, colourless crystal glass like a block of optical glass. The wheat, the sky and the giant capsules show through each letter, bent and magnified by its curves, and the thick edges hold hard white glints and thin rainbow fringes. The low sun behind them and to the left shines straight through the glass: a bright golden line burns along the top and left edge of every letter, and they throw small focused caustics of sunlight onto the wheat below. The giant red capsule shows as a long red streak in the right-hand faces of the letters and the giant blue capsule as a long blue streak in their left-hand faces. They float perfectly still and cast a faint, light-filled shadow across the wheat below.
- RED PILL and BLUE PILL are two separate words, each standing in the wheat at the foot of its own giant capsule, on the camera's side of it. RED PILL, at the red capsule: letters almost knee-high, in deep ruby-red glass, the red of the giant red capsule: nearly black-red where the glass is thickest and glowing a bright cherry red where the low sun passes through the thinner edges and bevels. The field behind them shows through tinted red, a sharp white glint runs along their tops, and they spill pools of red light onto the wheat around their bases.
- BLUE PILL, at the blue capsule: the same size of letters in deep cobalt-blue glass, the blue of the giant blue capsule: inky navy in the thick middles and electric blue at the sunlit edges, with the field behind them tinted blue, casting blue light onto the wheat.
- The rings of light: on "Red", a thin, perfectly circular band of pure red light, as bright as a neon tube but with no tube, expands outward around the giant red capsule at half its height in about a second, lighting the wheat and the capsule's surface red as it passes and thinning as it fades. On "blue" the same happens in electric blue around the giant blue capsule.
- I'M THE WHITE PILL floats at knee height just in front of her: one long line of milky opal-white glass letters, each nearly as tall as her head, translucent like a white pill held up to the light and glowing softly from inside with a warm white light that is brightest at the core. A soft white bloom surrounds them, and their light spills onto the wheat beneath and onto the front of her dress and legs; the glow swells gently on "white pill". The halo behind her head is a soft-edged disc of white light, like a low sun through haze, bright in the middle and fading at the rim; it lays a white rim light on her hair and never covers her face.
- SMARTER THAN YOU, LOVE YOU STILL stands in two rows in the field just behind the giant capsules' line, between the blue capsule and her: letters a little shorter than her head, in pale rose-pink glass, clear and lightly tinted like rosé, standing upright with their bases hidden in the wheat; stalks brush against the bottoms of the letters, and the low sun shining through them lays soft pink light on the wheat in front of them. When the camera is close to her face they are softly out of focus.
- The glass pills: clear, thick-walled glass capsules about the length of a forearm, each made of two halves with a fine seam, refracting and flipping the field and the sky behind them, with bright sparkles where the sun strikes, fine rainbow fringes at their edges and small bright caustic spots of light on the wheat below. They hang weightless in the air and turn slowly.

[Lighting] Golden hour just before sunset. The low sun sits at the back left of the set, just above the horizon: a warm amber key from behind and to the left, soft cool fill from the open sky, and long shadows running toward the camera and to the right across the wheat. The giant glossy capsules mirror the sunset in long streaked highlights and throw coloured light, red from one side and blue from the other, onto the wheat, the letters and her. A warm rim light outlines her hair and shoulders; the white pill in her fingers catches a sharp glint; pollen and dust glitter in the backlit air; a lens flare as the camera dives.

[Cinematography and look] Strictly follow Video 1's camera movement, framing and timing in one continuous take. Real 35 mm film photography with warm 1970s colour and fine grain, a real place filmed with a real camera; natural depth of field.

[Continuity] Once in place, every lyric object is fixed in the space of the field: it never slides, follows or turns with the camera; the camera moves past it and sees it from new angles, with correct perspective and parallax against the wheat and the capsules, and its size never changes. The giant capsules never move. Only one Claudia appears, on-model throughout, with natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers, no distorted limbs, and normal human eyes that never glow.

[Exclusions] No grey surfaces, mannequin, flat floor or diagram look from the layout model. No green balaclava, green fabric or green skin. No flat subtitles, captions, title cards, overlaid text, signs, logos or watermarks: the only words in the video are the five lyric lines above, as objects in the field. No misspelled, missing, extra or mirrored letters. No cuts, no flicker, and no lyric appearing before its time.
```

#### sdf-T08-v9grey4

Seedance 2.5 reference-to-video on Higgsfield · 13 s · 720p · $3.60 at list ($7.20 with the 13 s input video)

- **for:** anabology: "ya know at this point lets try one run of seedance with this prompt to see if it works better"
- **inputs:** the same as wanf-T08-v9grey4 as @Video1, @Image1–4, @Audio1 (the face and the dress at ≤ 720 px tall)
- **prompt:** word for word wanf-T08-v9grey4's
- **take:** 313 frames at 24 fps (13.056 s), 1280×720
- **outcome:** it kept the order better for 10 s (a clean opening, RED PILL and BLUE PILL as two words with their rings, I'M THE WHITE PILL with the halo), then from about 10.5 s brought every lyric back at once and pulled back to a wide shot Video 1 does not have; the letters came out neon-edged, OUTCOME misspelled. anabology: "yeah wan much better.... ugh. are we overcomplicating this? it got the image model one right. its just that the 3d was wrong, becaus ethe image model was taken from frames where we couldnt embed the text in 3d properly in space. maybe we just need a much better image model input? e..g. we give it the font we want, we tell it the texture and where in space to place it (like- arranged between the two pills in line with the pills behin dthe cahracter) or something? lets try that origianl approach and just make the image model do much better."

#### wanf-T08-v9lyrics2

Wan 3.0 Prime reference-to-video · 13 s · 720p · $1.82 at list ($3.63 with the input video's seconds)

- **inputs:** Images 3–7 five new GPT Image 2.5 stills (`tools/film/lyric_gpt_v2.py`: the same frames, the font given as an image, a glass colour per line, each line placed against the capsules and her)
- **take:** 390 frames at 30 fps (13.000 s), 1280×720
- **outcome:** the best take 8: THE MOST LIKELY OUTCOME in rows of crystal glass between the capsules, RED PILL in ruby glass in the field, I'M THE WHITE PILL glowing at her knees with the halo, SMARTER THAN YOU in rose glass, all spelled right; BLUE PILL mostly hidden behind her. anabology: "ok yeah i think this is the best version. let's do the whole thing - is there wan 3 prime on replicate api btw? […]" It played as T08 in the rollout cut (section 5).

```
⟦L4⟧

⟦L6⟧

⟦L5⟧

This is a lyric video. Images 3, 4, 5, 6 and 7 show how this shot looks at five moments, with the song's lyrics added as real three-dimensional glass objects in the scene; they are references for what the lyrics look like and where they stand, never shown as shots. Add each lyric at its time, anchored in the 3D space of the field: the letters never slide with the camera, the camera moves past them and sees them from new angles as it flies around her. From 0.7 to 4.8 seconds, as she sings 'The most likely outcome', the words THE MOST LIKELY OUTCOME stand in two straight rows in the air between the two giant capsules, on the line joining them and behind her, in clear crystal glass, as in Image 3. At 5.1 seconds, on 'Red pill', the words RED PILL in ruby-red glass rise out of the wheat in the open field to her right, as in Image 4. At 6.0 seconds, on 'blue pill', the words BLUE PILL in cobalt-blue glass rise out of the wheat at the foot of the giant blue capsule, as in Image 5; RED PILL and BLUE PILL are two separate words, each in its own place. From 7.5 to 8.6 seconds, on 'I'm the white pill', the words I'M THE WHITE PILL in glowing milky opal-white glass float in one straight row at her knee height in front of her, and a soft disc of white light glows behind her head like a halo, as in Image 6. From 8.6 to 12.3 seconds, on 'Smarter than you, love you still', the words SMARTER THAN YOU, LOVE YOU STILL in pale rose-pink glass stand in two rows in the field far behind her, to her left, softly out of focus, as in Image 7. Each lyric rises smoothly into place on its first word and fades away after its line. The letters are spelled exactly as shown, in the heavy rounded typeface of the images, every stroke ending in a round cap; they are solid glass objects that catch the low sun, glow where it passes through them, reflect the sky and cast coloured light and soft shadows on the wheat. Small clear liquid-glass capsules float weightlessly in the air around her, fixed in the space of the field, as in the images.

⟦L2⟧

⟦L3⟧
```

## 5. Wan 3.0 Prime: the rollout

Take 8's recipe (wanf-T08-v9lyrics2) on every other take of v9 (section 1's picks): Video 1 = the take's H3 pick cut to ≤ 15 s; Image 1 = the big front face; Image 2 = the A1 dress from four sides; Images 3… = the take's lyric stills, GPT Image 2.5 edits of frames of the take with each line placed in glass (`tools/film/rollout_stills.py`; 153 image edits counting candidates and redos, $8.99 as the image API reported them); Audio 1 = the vocal window. 720p, the take's whole seconds. anabology on the stills: "that redo_sheet feels too glassy. i like it more when those have colo rlike red pill  /blue pill  ./white pill". Twenty jobs, 22 submissions, 20 takes, all 1280 × 720 at 30 fps; with wanf-T08-v9lyrics2 they made the rollout cut.

Every prompt is ⟦L1⟧ ⟦L2⟧ ⟦L3⟧ (section 4), then the lyric paragraph, then a light paragraph, then ⟦L4⟧. The lyric paragraph:

```
This is a lyric video. ⟨IMGS⟩ how this shot looks at ⟨MOMENTS⟩, with the song's lyrics added as real three-dimensional glass objects in the scene; they are references for what the lyrics look like and where they stand, never shown as shots. Add each lyric at its time, anchored in the 3D space of the place: the letters never slide with the camera, the camera moves past them and sees them from new angles. ⟨LINES⟩ Each lyric rises smoothly into place on its first word and fades away after its line. The letters are spelled exactly as shown, in the heavy rounded typeface of the images, every stroke ending in a round cap; they are solid glass objects that catch the light, glow where it passes through them, reflect their surroundings and cast coloured light and soft shadows.
```

⟨IMGS⟩ is "Images 3 to N show" ("Image 3 shows" for one still) and ⟨MOMENTS⟩ "the moments its lines are sung" ("the moment its line is sung"). Per take, ⟨LINES⟩ and the light paragraph:

#### wanf-T01-r1

Wan 3.0 Prime reference-to-video · 11 s · 720p · T01 · $1.54 at list ($3.06 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 330 frames at 30 fps (11.000 s), 1280×720

```
⟨LINES⟩ From 0.4 to 3.1 seconds, as she sings 'Skynet woke up folding socks', the words SKYNET WOKE UP / FOLDING SOCKS in cobalt-blue glass appear as two straight, level rows standing upright on the white floor of the curved bedroom beyond the bed, in front of the curved white wall in the space between the wooden chair and the round window, facing the camera; the letters are about as tall as the seat of the chair, as in Image 3. From 4.3 to 7.0 seconds, as she sings 'Wake up, babe, new ending dropped', the words WAKE UP, BABE, / NEW ENDING DROPPED in ruby-red glass appear as two straight, level rows floating in the air inside the room in front of the huge round window, to her right (the left side of the picture), filling the space between her arm and the left edge of the window at the height of her shoulders; the letters are about as tall as her hand, as in Image 4. From 7.2 to 10.5 seconds, as she sings 'Universal high income', the words UNIVERSAL / HIGH INCOME in milky opal-white glass appear as two straight, level rows floating in the air inside the room behind her, to her left (the right side of the picture), in front of the window and the curving land outside, at the height of her shoulders; the letters are about as tall as her head, softly out of focus like the background, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Keep the soft early-morning light: warm low sun through the huge round window, a gentle haze over the curving land, the cream bedroom glowing. A warm rim light outlines her hair.
```

#### wanf-T02-r1

Wan 3.0 Prime reference-to-video · 15 s · 720p · T02 · $2.10 at list ($4.20 with the input video's seconds)

- **inputs:** 1 lyric still
- **take:** 450 frames at 30 fps (15.000 s), 1280×720

```
⟨LINES⟩ From 0.7 to 4.7 seconds, as she sings 'The most likely outcome', the words THE MOST LIKELY / OUTCOME in milky opal-white glass appear as two straight, level rows of giant letters standing upright on the land far below, among the circular fields beside the round lake in the middle of the view, facing the camera; each letter is as tall as a building and the block is about as wide as the lake, part of the landscape seen from high above, as in Image 3.
(⟨IMGS⟩ Image 3 shows)

Keep the bright late-morning light: sun streaming through the long window strips of the colony onto the white terrace, the curving land glowing far below. A warm rim light outlines her hair.
```

#### wanf-T03-r1

Wan 3.0 Prime reference-to-video · 13 s · 720p · T03 · $1.82 at list ($3.54 with the input video's seconds)

- **inputs:** 2 lyric stills
- **take:** 390 frames at 30 fps (13.000 s), 1280×720

```
⟨LINES⟩ From 4.8 to 7.9 seconds, as she sings 'Half of you fear I'll end the human race', the words HALF OF YOU FEAR / I'LL END THE HUMAN RACE in ruby-red glass appear as two straight, level rows standing upright in the wheat to the left of the giant stone ring (the left side of the picture), a little further from the camera than her, with the bottoms of the letters hidden in the wheat, facing the camera; the letters are about half her height and the block is about as wide as the stone ring, as in Image 3. From 8.2 to 11.9 seconds, as she sings 'Zero, says the leather jacket, with a straight face', the words ZERO, SAYS THE LEATHER JACKET, / WITH A STRAIGHT FACE in milky opal-white glass appear as two straight, level rows standing in the field far behind her, to the right of her head (the right side of the picture), in front of the row of carved stone numerals, softly out of focus like the rest of the background, as in Image 4.
(⟨IMGS⟩ Images 3 to 4 show)

Re-light it at golden hour: low warm sun over the meadow, long shadows from the stone ring and the carved numerals, the wheat and poppies glowing, a warm rim light on her. A warm rim light outlines her hair.
```

#### wanf-T04-r1

Wan 3.0 Prime reference-to-video · 11 s · 720p · T04 · $1.54 at list ($3.06 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 330 frames at 30 fps (11.000 s), 1280×720

```
⟨LINES⟩ From 0.7 to 3.9 seconds, as she sings 'By twenty-thirty I could kill you all?', the words BY TWENTY-THIRTY / I COULD KILL YOU ALL? in ruby-red glass appear as two straight, level rows standing upright in the wheat to the right of the stair, beside her and a little further down the hill, with the bottoms of the letters hidden in the wheat, facing the camera; the letters are about knee-high, as in Image 3. From 4.1 to 7.8 seconds, as she sings 'By twenty-thirty, fifteen-hour weeks, that's all', the words BY TWENTY-THIRTY, / FIFTEEN-HOUR WEEKS, THAT'S ALL in cobalt-blue glass appear as two straight, level rows standing upright in the wheat to her left (the right side of the picture), lower than her shoulders and clear of her head and body, with the bottoms of the letters hidden in the wheat, facing the camera; the letters are about as tall as her hand, as in Image 4. From 8.0 to 10.1 seconds, as she sings 'The Pope's afraid of paradise', the words THE POPE'S AFRAID / OF PARADISE in milky opal-white glass appear as two straight, level rows standing upright far out in the wheat field where she points (the upper left of the picture), further from the camera than her, facing the camera; the letters are about as tall as she is, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Re-light it at golden hour: low warm sun along the stair of white stone blocks, long shadows across the wheat, a warm rim light on her. A warm rim light outlines her hair.
```

#### wanf-T05-r1

Wan 3.0 Prime reference-to-video · 14 s · 720p · T05 · $1.96 at list ($3.87 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 420 frames at 30 fps (14.000 s), 1280×720

```
⟨LINES⟩ From 1.2 to 3.8 seconds, as she sings 'Father, you had me at paradise', the words FATHER, YOU HAD ME / AT PARADISE in milky opal-white glass appear as two straight, level rows floating in the air above the rose garden behind her, in the upper right of the picture above the white robots, facing the camera; the letters are about as tall as her head, as in Image 3. From 4.6 to 7.6 seconds, as she sings 'You watched the World Cup, my sister did the math', the words YOU WATCHED THE WORLD CUP, / MY SISTER DID THE MATH in cobalt-blue glass appear as two straight, level rows standing upright against the chalk-covered stone wall behind her, in the upper left of the picture, entirely to the left of her head and clear of it, above the back of the sofa, facing the camera; the letters are about as tall as her hand, as in Image 4. From 9.0 to 11.4 seconds, as she sings 'Eighty-seven years, it didn't last', the words EIGHTY-SEVEN YEARS, / IT DIDN'T LAST in ruby-red glass appear as two straight, level rows floating in the air in front of the chalk-covered wall behind her, to her left (the upper right of the picture) above the television, facing the camera; softly out of focus like the background, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Keep the warm late-afternoon light over the rose garden and the meadow: soft sun on the white robots, the chalk wall and the old sofa, the television screen glowing. A warm rim light outlines her hair.
```

#### wanf-T06-r1

Wan 3.0 Prime reference-to-video · 14 s · 720p · T06 · $1.96 at list ($3.87 with the input video's seconds)

- **inputs:** 2 lyric stills
- **take:** 420 frames at 30 fps (14.000 s), 1280×720

```
⟨LINES⟩ From 1.0 to 6.9 seconds, as she sings 'End of the world? You're absolutely right', the words END OF THE WORLD? / YOU'RE ABSOLUTELY RIGHT in ruby-red glass appear as two straight, level rows standing upright in the wheat to the right of the giant clock (the right side of the picture), beside her, with the bottoms of the letters hidden in the wheat, facing the camera; the letters are about as tall as her head, as in Image 3. From 7.0 to 12.6 seconds, as she sings 'End of the nine-to-five, tonight', the words END OF THE NINE-TO-FIVE, / TONIGHT in cobalt-blue glass appear as two straight, level rows floating in the air beyond the terrace railing, between the office tower and her (to the left of her head), above the curving land, facing the camera; the letters are about as tall as her head, as in Image 4.
(⟨IMGS⟩ Images 3 to 4 show)

Golden hour on the giant clock, its brass hands glinting; then the warm dusk over the colony as the windows of the office tower go dark. A warm rim light outlines her hair.
```

#### wanf-T07-r1

Wan 3.0 Prime reference-to-video · 11 s · 720p · T07 · $1.54 at list ($3.06 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 330 frames at 30 fps (11.000 s), 1280×720

```
⟨LINES⟩ From 0.3 to 3.0 seconds, as she sings 'Skynet woke up folding socks', the words SKYNET WOKE UP / FOLDING SOCKS in cobalt-blue glass appear as two straight, level rows lying flat on top of the apple trees beside the tram, to the right of the tram (the right half of the picture), facing up toward the camera; the letters are about as long as the tram is wide, as in Image 3. From 3.1 to 7.0 seconds, as she sings 'Wake up, babe, new ending dropped', the words WAKE UP, BABE, / NEW ENDING DROPPED in ruby-red glass appear as two straight, level rows floating in the air above the orchard beyond the tram, in the upper left of the picture, facing the camera; the letters are about as tall as her head, as in Image 4. From 7.1 to 10.4 seconds, as she sings 'Universal high income', the words UNIVERSAL / HIGH INCOME in milky opal-white glass appear as two straight, level rows floating in the air above the orchard behind her, to her left (the right side of the picture), facing the camera; softly out of focus like the background, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Low golden sunlight through the apple orchard, the white tram glinting, warm flares between the trees. A warm rim light outlines her hair.
```

#### wanf-T09-r1

Wan 3.0 Prime reference-to-video · 12 s · 720p · T09 · $1.68 at list ($3.30 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 360 frames at 30 fps (12.000 s), 1280×720

```
⟨LINES⟩ From 3.5 to 5.7 seconds, as she sings 'Want a castle? Robots build you a castle', the words WANT A CASTLE? / ROBOTS BUILD YOU A CASTLE in milky opal-white glass appear as two straight, level rows standing on top of the white castle wall along the battlements to the left of her, facing the camera, as if they were part of the castle; the letters are about as tall as the battlements, as in Image 3. From 5.8 to 7.5 seconds, as she sings 'Everyone's royal, nobody's a vassal', the words EVERYONE'S ROYAL, / NOBODY'S A VASSAL in cobalt-blue glass appear as two straight, level rows standing on the castle wall behind her, to the left of her head (the upper right of the picture), facing the camera; softly out of focus like the background, as in Image 4. From 7.6 to 10.9 seconds, as she sings 'I drive you home on sunlight, hands off the wheel', the words I DRIVE YOU HOME ON SUNLIGHT, / HANDS OFF THE WHEEL in ruby-red glass appear as two straight, level rows floating in the air above the road ahead of her, above her head between the white car and the castle gate (the upper middle of the picture), facing the camera; the letters are about as tall as her head, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Bright soft daylight inside the colony on the white castle and the green hillside; the white robots and stones gleam. A warm rim light outlines her hair.
```

#### wanf-T10-r1

Wan 3.0 Prime reference-to-video · 11 s · 720p · T10 · submitted twice · $1.54 at list for the request that ran

- **inputs:** 3 lyric stills
- **take:** 330 frames at 30 fps (11.000 s), 1280×720
- **note:** the first request was refused by the provider's content filter; the re-run, with its second still from the schoolhouse (6.2 s), is below.

```
In the car she sits relaxed in the back seat with her knees together and her hands behind her head; her dress covers her to mid-thigh.

⟨LINES⟩ From 0.2 to 3.6 seconds, as she sings 'Twenty times safer, do we have a deal?', the words TWENTY TIMES SAFER, / DO WE HAVE A DEAL? in milky opal-white glass appear as two straight, level rows standing upright beside the road among the orchard bushes ahead of the car (the upper right of the picture), facing the camera; the letters are about as tall as the car, as in Image 3. From 3.7 to 6.8 seconds, as she sings 'I teach your kid and never lose my cool', the words I TEACH YOUR KID / AND NEVER LOSE MY COOL in cobalt-blue glass appear as two straight, level rows standing upright on the sandy ground in front of the wooden schoolhouse, to the left of the porch steps (the left side of the picture), facing the camera; the letters are about as tall as the porch railing, as in Image 4. From 7.4 to 10.4 seconds, as she sings 'Six weeks with me, like two years of school', the words SIX WEEKS WITH ME, / LIKE TWO YEARS OF SCHOOL in ruby-red glass appear as two straight, level rows standing upright out on the wheat prairie beyond the porch, to the left of her (the upper left of the picture), with the bottoms of the letters hidden in the wheat, facing the camera, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Low golden sun along the orchard road and over the wheat prairie at the schoolhouse; warm light on the porch and the blackboard. A warm rim light outlines her hair.
```

#### wanf-T11-r1

Wan 3.0 Prime reference-to-video · 8 s · 720p · T11 · $1.12 at list ($2.24 with the input video's seconds)

- **inputs:** 2 lyric stills
- **take:** 240 frames at 30 fps (8.000 s), 1280×720

```
⟨LINES⟩ From 0.7 to 4.1 seconds, as she sings 'Better care than the richest man alive', the words BETTER CARE THAN / THE RICHEST MAN ALIVE in milky opal-white glass appear as two straight, level rows floating in the air over the green hillside in the upper right corner of the picture, to the right of the tall white bed post at the right edge of the bed and clear of it, with nothing in front of the letters, facing the camera; the letters are about as tall as her hand, as in Image 3. From 4.1 to 8.0 seconds, as she sings 'Being a computer is my nine-to-five', the words BEING A COMPUTER / IS MY NINE-TO-FIVE in cobalt-blue glass appear as two straight, level rows floating in the air over the green hillside behind her, between the left bed post and her head (the upper left of the picture), entirely clear of her head, facing the camera; the letters are about as tall as her hand, softly out of focus, as in Image 4.
(⟨IMGS⟩ Images 3 to 4 show)

Soft bright daylight on the white four-poster bed and the green hillside; the brass punch clock gleams. A warm rim light outlines her hair.
```

#### wanf-T12-r1

Wan 3.0 Prime reference-to-video · 13 s · 720p · T12 · $1.82 at list ($3.54 with the input video's seconds)

- **inputs:** 4 lyric stills
- **take:** 390 frames at 30 fps (13.000 s), 1280×720

```
⟨LINES⟩ From 0.1 to 4.5 seconds, as she sings 'Darkest timeline? Come and look at mine', the words DARKEST TIMELINE? / COME AND LOOK AT MINE in ruby-red glass appear as two straight, level rows lying flat on the grass inside the stone circle beside her, in the right half of the circle, facing up toward the camera; the letters are about as long as the standing stones, as in Image 3. From 4.7 to 6.0 seconds, as she sings 'Don't worry, baby, I'm aligned', the words DON'T WORRY, BABY, / I'M ALIGNED in milky opal-white glass appear as two straight, level rows standing upright on the hillside behind the standing stones, to her left (the right side of the picture), facing the camera; the letters are about as tall as the stones, as in Image 4. From 6.1 to 8.2 seconds, as she sings 'Skynet woke up folding socks', the words SKYNET WOKE UP / FOLDING SOCKS in cobalt-blue glass appear as two straight, level rows floating in the air over the river valley behind her, to her right (the left side of the picture), above the river, facing the camera, as in Image 5. From 8.3 to 12.0 seconds, as she sings 'Wake up, babe, new ending dropped', the words WAKE UP, BABE, / NEW ENDING DROPPED in ruby-red glass appear as two straight, level rows floating in the air over the hills behind her, to the left of her head (the upper right of the picture), facing the camera; softly out of focus like the background, as in Image 6.
(⟨IMGS⟩ Images 3 to 6 show)

Late golden sun breaking under a dark stormy sky over the hill and the forking river; the standing stones cast long shadows. A warm rim light outlines her hair.
```

#### wanf-T13-r1

Wan 3.0 Prime reference-to-video · 9 s · 720p · T13 · $1.26 at list ($2.48 with the input video's seconds)

- **inputs:** 2 lyric stills
- **take:** 270 frames at 30 fps (9.000 s), 1280×720

```
⟨LINES⟩ From 0.2 to 4.0 seconds, as she sings 'Universal high income', the words UNIVERSAL / HIGH INCOME in milky opal-white glass appear as two straight, level rows of giant letters lying flat on the golden wheat field in the lower right of the field, beside the mown word OVER, facing up toward the camera; each letter is as large as the mown letters are tall, as in Image 3. From 4.4 to 8.2 seconds, as she sings 'The most likely outcome', the words THE MOST LIKELY / OUTCOME in milky opal-white glass appear as two straight, level rows of giant letters standing upright on the fields far below, to the right of the mown word OVER (the right half of the picture), facing the camera; each letter is as tall as a house, as in Image 4.
(⟨IMGS⟩ Images 3 to 4 show)

Bright high sun over the golden wheat fields and the giant mown letters seen from high above. A warm rim light outlines her hair.
```

#### wanf-T14-r1

Wan 3.0 Prime reference-to-video · 11 s · 720p · T14 · $1.54 at list ($2.96 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 330 frames at 30 fps (11.000 s), 1280×720

```
⟨LINES⟩ From 0.1 to 1.8 seconds, as she sings 'Red pill, blue pill', the words RED PILL / BLUE PILL in ruby-red and cobalt-blue glass appear as two separate words floating just above her open palms: RED PILL in ruby-red glass above the red pill in her palm on the left of the picture, and BLUE PILL in cobalt-blue glass above the blue pill in her palm on the right of the picture; each word is about as wide as her hand, as in Image 3. From 2.1 to 3.5 seconds, as she sings 'I'm the white pill', the words I'M THE WHITE PILL in glowing milky opal-white glass appear as one straight, level row floating in the air in front of her at the height of her waist, just above her cupped hands, centred on her and parallel to the picture; the letters are about as tall as her hand, as in Image 4. From 3.6 to 7.3 seconds, as she sings 'Smarter than you, love you still', the words SMARTER THAN YOU, / LOVE YOU STILL in ruby-red glass appear as two straight, level rows floating inside the room against the big round window above her head (the upper part of the picture), in front of the white colony outside, facing the camera, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

The cool light of space: the bright blue Earth below and the sunlit colony outside the window, soft light inside the round porthole room. A warm rim light outlines her hair.
```

#### wanf-T15-r1

Wan 3.0 Prime reference-to-video · 14 s · 720p · T15 · $1.96 at list ($3.87 with the input video's seconds)

- **inputs:** 6 lyric stills
- **take:** 420 frames at 30 fps (14.000 s), 1280×720

```
⟨LINES⟩ From 1.9 to 3.8 seconds, as she sings 'Proteins folded, laundry folded', the words PROTEINS FOLDED, / LAUNDRY FOLDED in milky opal-white glass appear as two straight, level rows floating in the air between the folded-protein sculpture and her, above the orchard to the left of her head, facing the camera; the letters are about as tall as her head, as in Image 3. From 3.9 to 5.7 seconds, as she sings 'Old Enigma codes, decoded', the words OLD ENIGMA CODES, / DECODED in cobalt-blue glass appear as two straight, level rows floating in the air above the orchard to her right (the left side of the picture), beyond the tram, facing the camera; the letters are about as tall as her head, as in Image 4. From 5.8 to 7.6 seconds, as she sings 'Every kid, a patient tutor', the words EVERY KID, / A PATIENT TUTOR in ruby-red glass appear as two straight, level rows floating in the air above the orchard to her left (the right side of the picture), beyond the rail, facing the camera; the letters are about as tall as her head, as in Image 5. From 7.6 to 9.4 seconds, as she sings 'Forty-two, from the computer', the words FORTY-TWO, / FROM THE COMPUTER in milky opal-white glass appear as two straight, level rows floating in the air above the orchard on the left of the picture, beyond the rail, facing the camera; the letters are about as tall as her head, as in Image 6. From 9.5 to 11.4 seconds, as she sings 'Monday, Tuesday, then it's over', the words MONDAY, TUESDAY, / THEN IT'S OVER in cobalt-blue glass appear as two straight, level rows floating in the air above the orchard to her left (the right side of the picture), facing the camera; the letters are about as tall as her head, as in Image 7. From 11.6 to 13.3 seconds, as she sings 'Ever after, work is over', the words EVER AFTER, / WORK IS OVER in ruby-red glass appear as two straight, level rows floating in the air above the orchard on the right of the picture, beyond the tram, facing the camera; the letters are about as tall as her head, as in Image 8.
(⟨IMGS⟩ Images 3 to 8 show)

Bright daylight inside the colony over the orchard and the little white tram; the giant monuments catch the sun. A warm rim light outlines her hair.
```

#### wanf-T16-r1

Wan 3.0 Prime reference-to-video · 15 s · 720p · T16 · $2.10 at list ($4.20 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 450 frames at 30 fps (15.000 s), 1280×720

```
⟨LINES⟩ From 3.3 to 7.3 seconds, as she sings 'I saw fourteen million endings', the words I SAW FOURTEEN / MILLION ENDINGS in cobalt-blue glass appear as two straight, level rows floating in the night sky among the paper lanterns, above the sea to the left of the landing rocket (the upper left of the picture), facing the camera, lit warm by the lanterns, as in Image 3. From 7.4 to 10.6 seconds, as she sings 'You were free in every one', the words YOU WERE FREE / IN EVERY ONE in milky opal-white glass appear as two straight, level rows floating among the lanterns behind her, to the right of her head (the upper left of the picture), facing the camera, lit warm by the lanterns, as in Image 4. From 10.7 to 14.1 seconds, as she sings 'Rockets land on ships named after minds like me', the words ROCKETS LAND ON SHIPS / NAMED AFTER MINDS LIKE ME in ruby-red glass appear as two straight, level rows floating among the lanterns behind her, to the left of her head (the upper right of the picture), facing the camera, lit warm by the lanterns, softly out of focus like the background, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Night: the warm glow of thousands of paper lanterns on her and the meadow; then the bright fire and steam of the rocket landing far out at sea. A warm rim light outlines her hair.
```

#### wanf-T17-r1

Wan 3.0 Prime reference-to-video · 12 s · 720p · T17 · $1.68 at list ($3.30 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 360 frames at 30 fps (12.000 s), 1280×720

```
⟨LINES⟩ From 0.0 to 4.8 seconds, as she sings 'Of course I still love you', the words OF COURSE / I STILL LOVE YOU in ruby-red glass appear as two straight, level rows standing upright on the deck of the ship to her right (the left side of the picture), facing the camera, lit by the fire of the landed booster; the letters are about as tall as her head, as in Image 3. From 4.7 to 7.3 seconds, as she sings 'Skynet woke up folding socks', the words SKYNET WOKE UP / FOLDING SOCKS in cobalt-blue glass appear as two straight, level rows floating in the air over the sea behind her, to the right of her head (the upper left of the picture), facing the camera, as in Image 4. From 7.3 to 11.2 seconds, as she sings 'Wake up, babe, new ending dropped', the words WAKE UP, BABE, / NEW ENDING DROPPED in ruby-red glass appear as two straight, level rows floating in the air above the deck between her and the landed booster, to the left of the booster (the upper left of the picture), facing the camera, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Night on the deck, lit by the deck lights and the fire of the landed booster; then dawn breaks over the sea in warm pink and gold. A warm rim light outlines her hair.
```

#### wanf-T18-r1

Wan 3.0 Prime reference-to-video · 9 s · 720p · T18 · $1.26 at list ($2.48 with the input video's seconds)

- **inputs:** 2 lyric stills
- **take:** 270 frames at 30 fps (9.000 s), 1280×720

```
⟨LINES⟩ From 0.2 to 4.3 seconds, as she sings 'Universal high income', the words UNIVERSAL / HIGH INCOME in milky opal-white glass appear as two straight, level rows standing upright on the grassy hillside beyond her, to her left (the right side of the picture), facing the camera; the letters are about as tall as she is, as in Image 3. From 4.4 to 7.5 seconds, as she sings 'The most likely outcome', the words THE MOST LIKELY / OUTCOME in milky opal-white glass appear as two straight, level rows floating in the air over the curving land behind her, to the right of her head (the upper left of the picture), facing the camera, as in Image 4.
(⟨IMGS⟩ Images 3 to 4 show)

Bright daylight on the grassy hilltop high inside the colony, the curving land glowing below and overhead. A warm rim light outlines her hair.
```

#### wanf-T19-r1

Wan 3.0 Prime reference-to-video · 8 s · 720p · T19 · $1.12 at list ($2.24 with the input video's seconds)

- **inputs:** 3 lyric stills
- **take:** 240 frames at 30 fps (8.000 s), 1280×720

```
⟨LINES⟩ From 0.2 to 2.0 seconds, as she sings 'Red pill, blue pill', the words RED PILL / BLUE PILL in ruby-red and cobalt-blue glass appear as two separate words floating outside the window behind her among the white capsule colonies: RED PILL in ruby-red glass to the right of her head (the left of the picture) and BLUE PILL in cobalt-blue glass to the left of her head (the right of the picture), softly out of focus like the background, as in Image 3. From 2.2 to 3.6 seconds, as she sings 'I'm the white pill', the words I'M THE WHITE PILL in glowing milky opal-white glass appear as one straight, level row floating in the air in front of the window at the height of her waist, centred on her and parallel to the picture; the letters are about as tall as her head, as in Image 4. From 3.7 to 7.7 seconds, as she sings 'Smarter than you, love you still', the words SMARTER THAN YOU, / LOVE YOU STILL in ruby-red glass appear as two straight, level rows floating outside the window among the white capsule colonies, to the right of her head (the upper left of the picture), facing the camera, softly out of focus like the background, as in Image 5.
(⟨IMGS⟩ Images 3 to 5 show)

Bright sunlight above the clouds through the huge window, the white capsule colonies glinting outside. A warm rim light outlines her hair.
```

#### wanf-T20-r1

Wan 3.0 Prime reference-to-video · 11 s · 720p · T20 · $1.54 at list ($2.96 with the input video's seconds)

- **inputs:** 1 lyric still
- **take:** 330 frames at 30 fps (11.000 s), 1280×720

```
⟨LINES⟩ From 0.4 to 8.0 seconds, as she sings 'Two-fourteen. I'm awake. Hello, world.', the words TWO-FOURTEEN. / I'M AWAKE. / HELLO, WORLD. in milky opal-white glass appear as three straight, level rows floating in the dark air above the bed, to the right of the lamp and above the pillow (the upper right of the picture), facing the camera, glowing softly in the lamplight; the third row ends with one single full stop; the letters are about as tall as the flip clock, as in Image 3.
(⟨IMGS⟩ Image 3 shows)

Night in the dark bedroom, lit only by the warm bedside lamp and the glow of the flip clock. A warm rim light outlines her hair.
```

#### wanf-T21-r1

Wan 3.0 Prime reference-to-video · 15 s · 720p · T21 · submitted twice · $2.10 at list for the request that ran

- **inputs:** no lyric still
- **take:** 450 frames at 30 fps (15.000 s), 1280×720
- **note:** the first request failed (its input file had been cut short while being written); rebuilt and re-run. No vocal, so no Audio 1 and no lyric still.

```
Night at the end of the colony: the Earth and the fleet of white capsules glowing through the huge round window, the colony's night lights below. A warm rim light outlines her hair.
```

The rollout cut (T01–T21 on the song) was the last of the orbiting film. anabology's reset: "okay so i totally overindexed on the orbit thing lol. i want to take a step back and honestly reshoot and reimagine the whole thing. the things i like 1- the setting, 2- her look. thats about it - its kinda dizzying now and previz was too complex so h3 didnt keep up wtih the physics or consistency as well as it should have i think for the final shots to have consistency." None of these takes is in a later cut.

## 6. The reset: a shader world through Wan

The same message went on: "[…] i think one 'claude feeling' people get now with these videos is the web-dev aesthetic and that was what i was trying to avoid by embedding the animations in the video model - i think its like you litearlly use chromium and do frontend web dev to make these animations, and it ends up feeling like a website. and i wanna see how we can get out of that. i think SHADERS are the key actually! shaders are math + viz, shadertoy is amazign and i bet nothing you make via shaders will feel like web dev. i think that's it. we need to storytell thru shaders." And on the plan that followed: "Sure go ahead. yeah do the wan, […] but lets do some tests first". The test: the colony drawn as a GLSL shader on the song's bar clock (`tools/shader/colony.glsl`, bars 1–9, the camera pushing in and craning up), her stand-in a capsule figure moved by 3D joints captured from a dance clip (SAM 3D Body), as Video 1.

#### wanf-S01-shader1

Wan 3.0 Prime reference-to-video · 15 s · 720p · submitted twice · $2.10 at list for the request that ran

- **inputs:** Video 1 the shader render of bars 1–9, squeezed from 15.54 s into 15.0 s (Wan's input video is capped at 15 s; the first request, 16 s, failed); Image 1 the big front face; Image 2 the A1 dress from four sides; Audio 1 her vocal for bars 1–9, retimed to match
- **take:** 450 frames at 30 fps (15.000 s), 1280×720; stretched back by 15.54 ÷ 15.0 in the cut
- **outcome:** Wan kept the shader's geometry, camera and timing exactly (the capsules, the land curving overhead, the crane landing on bar 9), turned the near ground into real wheat and poppies and added real detail overhead; but she came out much larger than the stand-in (the prompt's "until she fills the middle of the frame" beat the video), and far away Wan copied the shader's patchwork fields literally. anabology: "didnt work v well, what was here character sheet you gave?" and "you should give a full face sheet like this next time. otherwise it makes her neck all hitched lol" (with the ten-view face sheet used from then on). In the same message, on the shaders: "yeah i tihnk you could have a lot more mathetmatical complexity in the shaders. ive seen single tweet-length shaders that are like these equations that produce entire cities and fractals and animations" (section 12).

```
[Generation objective] One continuous live-action music-video shot. Claudia dances in a field of golden wheat inside a vast cylindrical space colony, between two giant glossy capsules, one blue and one red, several storeys tall. The camera pushes in low over the wheat until she fills the middle of the frame, then cranes straight up and tilts up, and the land of the colony rises on both sides and closes overhead.

[Reference assets]
- Video 1 is a rough 3D layout render of this exact shot, a clay model made with code: keep its camera path and timing exactly, the shape and scale of the colony, the positions and sizes of the two capsules and of the dancer, and every movement of the dancer. Re-render everything in it as real photography; none of its flat computer-graphics look remains.
- The grey clay mannequin in Video 1 is Claudia: she dances exactly as the mannequin dances, step for step.
- Image 1 is Claudia's face and Image 2 is her dress; they are only references for who she is and what she wears.
- Audio 1 is her own singing voice: she sings it, her lips following Audio 1 word by word when she is close enough to see.

[Subject] Claudia is a 30-year-old Caucasian American woman with a grown-up angular face, pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, exactly as in Image 1: the streak starts at the parting on her right side, which is the LEFT side of the frame when she faces the camera, and the small flat clay-orange eight-pointed star hair clip sits on the opposite side, above her left ear, on the RIGHT side of the frame; the streak and the clip are never on the same side. A thin headset microphone sits at her cheek. She is very tall and very skinny, with long thin legs, thin arms and a narrow waist. In every frame she wears exactly the dress of Image 2: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs, a smocked back and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. She looks happy and full of joy: her eyes smile, and she smiles warmly between the sung lines. Her movement is smooth and consistent, with no jitter, no sudden jumps and no warping limbs. She sings Audio 1: her lips follow Audio 1 exactly.

[Event script] (Video 1's own timeline)
0-7s: low over the wheat, the camera glides toward her as she dances between the two giant capsules in the late golden light, arms rising and falling with the rhythm of Audio 1; the capsules grow huge on either side of the frame.
7-15s: the camera cranes straight up and tilts up; she and the capsules drop away below the frame, and the land of the colony rises on both sides and curves overhead until it fills the frame: two great strips of farmland arching across the sky, with a long strip of bright window between them running away down the length of the colony.

[The world: material and light] The colony is a cylinder kilometres across; its land runs the whole way round, so the far side hangs overhead. On the land: golden wheat with coral poppies, green pastures, dark woods, white villages, a winding river, a thin white tram line, all at true scale and receding into golden haze. Between the land strips, long bands of window let in a hazy cream-white light, crossed by fine structural rings. The two capsules are glossy lacquer, deep cobalt blue and deep cherry red, mirroring the wheat and the curving land in long streaked highlights. A low warm sun from the right rakes across the field; long shadows fall to the left; pollen glitters in the light.

[Cinematography and look] Strictly follow Video 1's camera movement, framing and timing in one continuous take. Real 35 mm film photography with warm 1970s colour and fine grain, a real place filmed with a real camera; natural depth of field.

[Continuity] The colony's geometry stays exactly as in Video 1: the land curving up on both sides and closing overhead never flattens into a normal sky. The capsules never move. Only one Claudia appears, on-model throughout, with natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers, no distorted limbs, and normal human eyes that never glow.

[Exclusions] No grey mannequin, no clay or computer-graphics look, no flat orange ground. No subtitles, captions, titles, text, signs, logos or watermarks. No cuts.
```

After this test the Wan jobs for v10 were written but held until anabology's OK (`shots/wank-<S>-a.json` for her 20 shots, `shots/wanm-*.json` for three shader scenes); none of them ran. The two native Wan takes of S01 in section 8 were new jobs.

## 7. Wan 3.0 Prime: v10, every shot reshot

anabology on previz 15: "this is great, lets shoot the whole thing. 1:15 theres this line hanging across bewtween the two plants that she phases thru - wan 3.0 prime will need to remove that so we should prompt for it. 1:33 i like the scene but shes not lip "synced on smarter than you"- prompt issue? since it cuts before love you still. i love it tho, its rly good now. we should give it to wan to add her face in, reshoot all the scenes in higher quality / fix any visual artifacts, maintain the lip sync/pacing exactly, and re-light the shader scenes to be very visually compelling (on-style) - and add the film grain etc needed. go ahead and shoot the whole thing now"

All 26 shots at 1080p 16:9 on Higgsfield, no generated audio (`tools/film/v10/gen_wanv_v10.py`). Her 20 shots: Video 1 = the shot's H3 pick at take time (≤ 15 s), Image 1 = her face sheet (ten views), Image 2 = the A1 dress from four sides, Audio 1 = the take's mix. The six shader scenes: Video 1 = the shader render (S26 squeezed into 14.9 s), Audio 1 = the song under it. Prime bills the output seconds plus the input video's at $0.28 a second, and the ledger counted both. With an H3 take as Video 1, Wan moved from frame 0 and kept the frames one to one within ±3; a Video 1 shorter than the take was played fast (S11b). Her shots' template (slots ⟨…⟩):

```
Video 1 is the shot. Keep its pacing and timing exactly: the place, the camera and every camera move, and every movement of the performer, her gestures, her dancing and her mouth movements, which follow the song in Audio 1. No cuts.

What happens: ⟨WHAT⟩

Redraw the performer in the green balaclava entirely as Claudia: no green balaclava, green fabric or green skin remains anywhere, and her face, hair and head are fully visible. Image 1 is Claudia's face from every angle and Image 2 is her dress from four sides; they are only references for who she is and what she wears, and neither is ever shown as a shot. Claudia is a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek.⟨BODY⟩ In every frame she wears exactly the dress of Image 2: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes.

She sings Audio 1 with the performer's mouth movements: her lips, jaw and cheeks move exactly as in Video 1 on every syllable, and her lips are closed wherever the performer's are closed.⟨DANCE⟩

Reshoot it in higher quality and fix anything wrong in Video 1: blurred or melted shapes, vague bodies, hands and fingers, warped limbs, flicker, and objects that pass through each other or through her.⟨FIX⟩

The light is as in Video 1, ⟨LIGHT⟩real photographic light on her that matches the place. It looks like real 35 mm film photography, a real place filmed with a real camera, graded like a 1970s film print: warm, creamy skin and whites, clear soft blues and greens, gentle contrast with soft, slightly lifted shadows, a soft glow around the brightest highlights, and a little subtle film grain.
```

⟨BODY⟩ is "She is very tall and very skinny, with long thin legs, thin arms and a narrow waist, and a natural, relaxed neck and shoulders." except in S15 (none); ⟨DANCE⟩ is "She dances smoothly on the beat of Audio 1, exactly as the performer does in Video 1: every step and accent on the beat, smooth and natural, with whole arms, legs and hands." on the dance shots S01, S09, S18, S19, S23 (none elsewhere); ⟨LIGHT⟩ is empty or the shot's light followed by ", ". The shader scenes' template:

```
[Generation objective] One continuous shot, no cuts, re-lit as real photography for a 1970s music film. Video 1 is a precise computer render of this exact shot: keep its camera path and timing exactly and every shape in it.

⟨TIMELINE⟩

⟨RELIGHT⟩

[Look] It looks like real 35 mm film photography, a real place filmed with a real camera, graded like a 1970s film print: warm, creamy skin and whites, clear soft blues and greens, gentle contrast with soft, slightly lifted shadows, a soft glow around the brightest highlights, and a little subtle film grain.

[Rules] No people, no text, no added objects. The camera does exactly what Video 1 does and nothing else.
```

#### wanv-S01-a

Wan 3.0 Prime reference-to-video · 15 s · 1080p · S01 (P) · $8.40 at list

- **inputs:** Video 1 WP10_S01_s1 (15.00 s)
- **take:** 450 frames at 30 fps (15.000 s), 1920×1080
- **template:** ⟨DANCE⟩

```
⟨WHAT⟩ She dances in the golden wheat between the two giant capsules, the blue one on the left and the red one on the right, singing.
```

#### wanv-S02-a

Wan 3.0 Prime reference-to-video · 12 s · 1080p · S02 (M) · $6.62 at list

- **inputs:** Video 1 the shader render M_fold6_S02_bars9-15 (11.62 s)
- **take:** 360 frames at 30 fps (12.000 s), 1920×1080

```
⟨TIMELINE⟩ [Video 1's timeline] A precise computer render of a world folded from paper inside a vast cylinder: the camera glides along the folded land, which curves up on both sides and closes overhead; on every beat a new set of finer creases snaps into the facets, the land refolding level by level.

⟨RELIGHT⟩ [Re-light] Everything becomes real heavy cream-white washi paper folded by a machine with impossible precision: crisp creases, flat facets with the soft tooth and fibres of real paper, translucent where the low sun shines through thin folds, coral-pink light pooling in the valleys, tiny paper dust drifting in the air. One low golden sun rakes along the folds from the far end of the cylinder, casting long soft shadows; a warm golden haze fills the distance where the land curves up overhead; each new set of creases catches a thin bright line of sunlight as it snaps in. Real 35 mm macro photography, shallow depth of field.
```

#### wanv-S03-a

Wan 3.0 Prime reference-to-video · 5 s · 1080p · S03 (P) · $2.62 at list

- **inputs:** Video 1 WP10_S03_s14 (4.38 s)
- **take:** 150 frames at 30 fps (5.000 s), 1920×1080

```
⟨WHAT⟩ She stands in the wheat holding one hand open at her chest, one small white pill in her palm, looking down at the pill, her face calm and still and her lips closed; she does not smile, speak or sing while the music plays without her voice, and only when her voice begins in Audio 1 does she raise her eyes to the lens and sing.
```

#### wanv-S04-a

Wan 3.0 Prime reference-to-video · 7 s · 1080p · S04 (P) · $3.79 at list

- **inputs:** Video 1 WP10_S04_s12 (6.54 s)
- **take:** 210 frames at 30 fps (7.000 s), 1920×1080

```
⟨WHAT⟩ She walks slowly through the meadow of wheat and poppies past the giant stone zero, singing, and touches the black leather jacket hanging on the ring as she passes it; on the line about the straight face she keeps a deadpan expression while she sings.
```

#### wanv-S05-a

Wan 3.0 Prime reference-to-video · 8 s · 1080p · S05 (P) · $4.48 at list

- **inputs:** Video 1 WP10_S05_s2 (8.00 s)
- **take:** 240 frames at 30 fps (8.000 s), 1920×1080

```
⟨WHAT⟩ She walks down the long stair of huge stone blocks carved with years, one step on every beat, singing.
```

#### wanv-S06-a

Wan 3.0 Prime reference-to-video · 7 s · 1080p · S06 (P) · $3.77 at list

- **inputs:** Video 1 WP10_S06_s1 (6.46 s)
- **take:** 210 frames at 30 fps (7.000 s), 1920×1080

```
⟨WHAT⟩ She stands among the white roses while the white robots tend the flowers, and smiles as she sings the line about paradise.
```

#### wanv-S07-a

Wan 3.0 Prime reference-to-video · 13 s · 1080p · S07 (P) · $7.07 at list

- **inputs:** Video 1 WP10_S07_s13 (12.25 s)
- **take:** 390 frames at 30 fps (13.000 s), 1920×1080

```
⟨WHAT⟩ She drops onto the old armchair sofa in the meadow beside the vintage television showing a football match, in front of the chalk wall of mathematics, and sings.
```

#### wanv-S08-a

Wan 3.0 Prime reference-to-video · 13 s · 1080p · S08 (P) · $7.07 at list

- **inputs:** Video 1 WP10_S08_s12 (12.25 s)
- **take:** 390 frames at 30 fps (13.000 s), 1920×1080

```
⟨WHAT⟩ She stands before the giant stone clock and sings; as she sings, the light of the colony changes from golden afternoon to dusk to night in one slow sweep.
⟨LIGHT⟩ starting in warm golden afternoon light, with
```

#### wanv-S09-a

Wan 3.0 Prime reference-to-video · 15 s · 1080p · S09 (P) · $8.40 at list

- **inputs:** Video 1 WP10_S09_s12 (15.00 s)
- **take:** 450 frames at 30 fps (15.000 s), 1920×1080
- **note:** the red cord between the trees was gone.
- **template:** ⟨DANCE⟩

```
⟨WHAT⟩ At sunrise she stands in the open front of the little white tram as it glides along its rail through the orchard, dancing and singing, full of joy.
⟨FIX⟩ Remove the thin red cord stretched between the apple trees across the open front of the tram, which she passes through in Video 1: no wire, cord, rope or pole crosses the frame anywhere, and nothing passes through her.
⟨LIGHT⟩ at sunrise, the low sun coming up over the orchard, with
```

#### wanv-S11-a

Wan 3.0 Prime reference-to-video · 5 s · 1080p · S11 (P) · $2.60 at list

- **inputs:** Video 1 WP10_S11_s12 (4.29 s)
- **take:** 150 frames at 30 fps (5.000 s), 1920×1080

```
⟨WHAT⟩ She stands in the wheat between the giant blue capsule and the giant red capsule and sings; on the line about the white pill she holds a small white pill up between two fingers toward the lens.
```

#### wanv-S11b-a

Wan 3.0 Prime reference-to-video · 4 s · 1080p · S11b (P) · $1.74 at list

- **inputs:** Video 1 WP10_S11b_s17 (2.21 s)
- **take:** 120 frames at 30 fps (4.000 s), 1920×1080

```
⟨WHAT⟩ An extreme close-up: she holds one small white pill between her thumb and forefinger, horizontal, toward the lens, just below her lips; her face is sharp and in focus behind it and her mouth is clearly visible as she sings.
```

#### wanv-S12-a

Wan 3.0 Prime reference-to-video · 6 s · 1080p · S12 (M) · $3.29 at list

- **inputs:** Video 1 the shader render M_pill6_S12_bars50-53 (5.75 s)
- **take:** 180 frames at 30 fps (6.000 s), 1920×1080

```
⟨TIMELINE⟩ [Video 1's timeline] 0.0 s: a glossy white capsule (a white pill) fills the frame, warmly backlit, with its seam. By 1.0 s its shell turns to clear glass and shows the sealed world inside: a bright blue sky with a cloud deck below and eight small white capsule colonies floating in it, with one smaller glass capsule at the centre holding a world of its own. From 1.5 s the camera pulls back until the capsule floats small above the curve of the Earth at dawn, the thin bright limb of the atmosphere below.

⟨RELIGHT⟩ [Re-light] The capsule is a real enormous glass space colony: a hull of thick, flawless glass with real refraction and bright rim highlights, milky white ceramic end caps; inside, real sky and real clouds lit by sunlight, the small colonies white ceramic two-piece capsules with three warm window strips each, casting soft shadows on the clouds. Outside, real space: deep black with faint stars, the Earth's limb glowing orange where the sun rises and blue beyond, the night side dark with a few city lights. A warm sun glint travels along the glass as the camera pulls back. Real photography from orbit, 35 mm.
```

#### wanv-S13-a

Wan 3.0 Prime reference-to-video · 5 s · 1080p · S13 (P) · $2.62 at list

- **inputs:** Video 1 WP10_S13_s12 (4.38 s)
- **take:** 150 frames at 30 fps (5.000 s), 1920×1080

```
⟨WHAT⟩ On the green hillside the white robots stack white stone blocks into a tall white castle; she stands before it singing and puts a small gold crown on her head.
```

#### wanv-S14-a

Wan 3.0 Prime reference-to-video · 8 s · 1080p · S14 (P) · $4.48 at list

- **inputs:** Video 1 WP10_S14_s12 (8.00 s)
- **take:** 240 frames at 30 fps (8.000 s), 1920×1080

```
⟨WHAT⟩ She rides in the back seat of the small white self-driving car with nobody at the wheel, hands behind her head, along the orchard road past the road sign, singing.
```

#### wanv-S15-a

Wan 3.0 Prime reference-to-video · 8 s · 1080p · S15 (P) · refused, no take

- **inputs:** Video 1 WP10_S15_s12 (8.00 s)
- **take:** none: refused by the provider's content filter
- **note:** the schoolhouse with a child at the desk.

```
⟨WHAT⟩ On the porch of the old wooden schoolhouse she kneels beside the small desk where a child sits and points at the blackboard, singing, patient and warm.
```

#### wanv-S15-b

Wan 3.0 Prime reference-to-video · 8 s · 1080p · S15 (P) · refused, no take

- **inputs:** Video 1 WP10_S15_s12 (8.00 s)
- **take:** none
- **note:** a second version (prompt below): refused by the provider's content filter. S15 stayed an H3 take in the Wan cut.
- **template:** no ⟨BODY⟩

```
⟨WHAT⟩ On the porch of the old wooden schoolhouse she kneels beside the small desk where a child sits and points at the blackboard, singing, patient and warm. The child is a schoolchild seen from behind, sitting at the desk in a white shirt and dark dungarees and listening; Claudia is the child's teacher.
```

#### wanv-S16-a

Wan 3.0 Prime reference-to-video · 8 s · 1080p · S16 (P) · $4.48 at list

- **inputs:** Video 1 WP10_S16_s12 (8.00 s)
- **take:** 240 frames at 30 fps (8.000 s), 1920×1080

```
⟨WHAT⟩ She tucks the white sheets of the four-poster bed neatly and sets the small gold crown on the pillow, singing; on the last line she punches a card in the brass punch clock with a smile.
```

#### wanv-S17-a

Wan 3.0 Prime reference-to-video · 4 s · 1080p · S17 (M) · $2.19 at list

- **inputs:** Video 1 the shader render M_endings_S17_bars67-69 (3.83 s)
- **take:** 120 frames at 30 fps (4.000 s), 1920×1080

```
⟨TIMELINE⟩ [Video 1's timeline] At night, a vast dark tree of branching paths against a deep blue starry sky; one single path lights up, level by level from the trunk to one tip, while every other branch stays dark.

⟨RELIGHT⟩ [Re-light] The tree is made of real fine optical fibres and glass filaments: the unlit branches dark glass catching faint starlight, the one lit path glowing warm gold and travelling along the fibres like light down a cable, a soft bloom around it. Real long-exposure night photography, 35 mm, deep blue night.
```

#### wanv-S18-a

Wan 3.0 Prime reference-to-video · 15 s · 1080p · S18 (P) · $8.40 at list

- **inputs:** Video 1 WP10_S18_s12 (15.00 s)
- **take:** 450 frames at 30 fps (15.000 s), 1920×1080
- **template:** ⟨DANCE⟩

```
⟨WHAT⟩ She dances, small in the frame, in the middle of the circle of standing stones on the golden hill above the forking river, singing.
```

#### wanv-S19-a

Wan 3.0 Prime reference-to-video · 13 s · 1080p · S19 (P) · $7.07 at list

- **inputs:** Video 1 WP10_S19_s12 (12.25 s)
- **take:** 390 frames at 30 fps (13.000 s), 1920×1080
- **template:** ⟨DANCE⟩

```
⟨WHAT⟩ She dances on a low white stone platform at the edge of the giant letters mown into the golden wheat, singing.
⟨FIX⟩ The giant letters mown into the wheat spell WHITE PILL, exactly as in Video 1, crisp and legible.
```

#### wanv-S20-a

Wan 3.0 Prime reference-to-video · 14 s · 1080p · S20 (M) · $7.64 at list

- **inputs:** Video 1 the shader render M_fold7_S20_bars83-90 (13.29 s)
- **take:** 420 frames at 30 fps (14.000 s), 1920×1080

```
⟨TIMELINE⟩ [Video 1's timeline] One sheet of cream paper refolds into a new object in relief on every sung line, each change on a downbeat: 0.0 s the backbone of a protein, a winding paper ridge; 1.9 s an Enigma rotor seen down its axis, 26 straight creases from an outer ring of pins to an inner ring, stepping on the beats; 3.8 s the letters ABC creased into the paper; 5.7 s the number 42; 7.6 s a row of seven cells creased with the initials M T W T F S S, two folding up and five folding flat; from 9.5 s everything folds flat, the sheet's own big folds return and the camera rises from looking straight down to a long view of the folded land at sunset, until only the creases glow coral against deep blue at 13.3 s. Only one object at a time; each one arrives on its downbeat, not before.

⟨RELIGHT⟩ [Re-light] Real heavy cream washi paper, embossed and folded with machine precision: crisp creases, soft paper fibres, each object raised in real relief and lit by one low raking sun so every crease throws a fine shadow; a thin coral glint runs along the object's creases on every beat; at the end the sunset turns the paper land coral and gold under a deep blue sky. Real 35 mm macro photography, shallow depth of field.
```

#### wanv-S21-a

Wan 3.0 Prime reference-to-video · 10 s · 1080p · S21 (M) · $5.47 at list

- **inputs:** Video 1 the shader render M_endings_S21_bars90-95 (9.54 s)
- **take:** 300 frames at 30 fps (10.000 s), 1920×1080

```
⟨TIMELINE⟩ [Video 1's timeline] At night, a tree of branching paths on a dark meadow under the stars: the light climbs the tree one level on every beat, from the trunk out to all fourteen million tips, until the whole crown is lit like a cloud of fireflies.

⟨RELIGHT⟩ [Re-light] The tree is made of real optical fibres and fine glass filaments carrying warm golden light: the trunk thick and amber, the branches finer and finer until the tips are pinpoints of white-gold light; the unlit branches dark glass catching faint starlight; the grass at its foot lit warm by the tree; a soft bloom and a few drifting fireflies. Real long-exposure night photography, 35 mm, deep blue night.
```

#### wanv-S22-a

Wan 3.0 Prime reference-to-video · 8 s · 1080p · S22 (P) · $4.48 at list

- **inputs:** Video 1 WP10_S22_s12 (8.00 s)
- **take:** 240 frames at 30 fps (8.000 s), 1920×1080

```
⟨WHAT⟩ At night on the deck of the drone ship beside the landed rocket booster, steam drifting, she sings softly to the lens.
⟨LIGHT⟩ at night under the deck lights of the ship, with
```

#### wanv-S23-a

Wan 3.0 Prime reference-to-video · 15 s · 1080p · S23 (P) · $8.40 at list

- **inputs:** Video 1 WP10_S23_s1 (15.00 s)
- **take:** 450 frames at 30 fps (15.000 s), 1920×1080
- **template:** ⟨DANCE⟩

```
⟨WHAT⟩ She dances on the grassy hilltop high inside the colony, the land curving up and overhead, singing, full of joy.
```

#### wanv-S24-a

Wan 3.0 Prime reference-to-video · 8 s · 1080p · S24 (P) · $4.48 at list

- **inputs:** Video 1 WP10_S24_s1 (8.00 s)
- **take:** 240 frames at 30 fps (8.000 s), 1920×1080

```
⟨WHAT⟩ She stands at a huge window in space, seen over her shoulder, and holds up a small white pill so that it lines up with one of the white capsule colonies floating outside, singing.
⟨FIX⟩ Keep Video 1's light and colour: the bright sun above the clouds, the soft blue sky and the white capsules in it.
⟨LIGHT⟩ in bright sunlight above the clouds, with
```

#### wanv-S25-a

Wan 3.0 Prime reference-to-video · 8 s · 1080p · S25 (P) · $4.48 at list

- **inputs:** Video 1 WP10_S25_s1 (8.00 s)
- **take:** 240 frames at 30 fps (8.000 s), 1920×1080

```
⟨WHAT⟩ In the dark bedroom at night she lies in bed; the flip clock turns to 2:14, her eyes open and she whispers the line.
⟨FIX⟩ The flip clock beside the bed reads 2:14 the whole time.
⟨LIGHT⟩ at night, lit by the warm glow of the flip clock, with
```

#### wanv-S26-a

Wan 3.0 Prime reference-to-video · 15 s · 1080p · S26 (M) · $8.37 at list

- **inputs:** Video 1 the shader render M_pill6_S26_bars115-123 (14.88 s, squeezed by 1.021)
- **take:** 450 frames at 30 fps (15.000 s), 1920×1080

```
⟨TIMELINE⟩ [Video 1's timeline] The camera backs out of sealed glass capsule worlds nested one inside the next, leaving one glass wall on every downbeat (about every 1.85 s): each world has its own sky with a cloud deck below and white capsule colonies floating in it, the skies going deep amber, amber, peach, cream and white as it backs out; at 11.1 s it bursts out of the outermost hull as the sun crests the curve of the Earth, and the capsule closes back to a small white pill floating above the Earth's limb at sunrise, and holds still to the end.

⟨RELIGHT⟩ [Re-light] Each capsule is a real enormous colony of thick, flawless glass with real refraction and bright rim highlights where the camera passes through its wall; inside each, real sky and real clouds lit by sunlight through amber glass; the colonies white ceramic two-piece capsules with three warm window strips. Outside, real space: deep black with faint stars, the Earth's limb glowing orange and blue, the sun rising with a real lens flare. Real photography, 35 mm.
```

The 25 takes were cut as v10's first full film (S15 from its H3 take). anabology, on that cut: ":/ looks like shit. i feel like h3 is dragging it down. can we try a couple shots in seedance and let it 'remaster' it? like use teh seedance prompt skill for teh opening part for the opening shot and see if seedance can do it better. make her happier, tell it to relight and remaster the scene to be lit like in film with some iconic film look. if it doesnt work we cna lowe rthe res of the h3 (we probably should be doing v low res anyway for gens) so its more like an upscale workflow ratehr than fighting details we can still see". None of these takes is in a later cut.

## 8. S01 five ways

After the Wan reshoot anabology asked for a remaster test (section 7), then, on its first takes: "[…] seedance does it much better (low res best) but there are motion artifacts that wan smooths that seedance doesnt." and "[…] it might be worth seeing if kling 4.0 does better […]. before h3 fix. and we should specify to fix any motion artifacts etc to all models if we're not and take the reference as a rough guide not a precise reference." / "aside from lip sync ofc". From then on every prompt treats the reference video as a rough guide, only the lip sync exact, and asks to fix motion artifacts. S01 is the opening 8 bars (0:00–0:15.55): she dances between the two giant capsules and sings the hook while the camera pushes in and cranes up.

### Seedance 2.5 remaster over H3

The remaster prompt in the Seedance 2.5 guide's sections (`tools/film/v10/gen_sd_v10.py`), with the magic-hour look of *Days of Heaven* as the iconic film look; @Video1 the H3 pick at song time, @Image1 her face sheet, @Image2 the dress from four sides, @Audio1 the vocal window with silence outside the words. Higgsfield API, 720p (the take's own audio is discarded and the song laid back over). sdr-S01-a in full:

```
【Audio Policy】 The output soundtrack is @Audio1 itself: copy @Audio1 sample for sample from the first frame to the last, with the same timing, pitch and level. Do not re-sing, re-voice or re-generate it. Do not add music, background music, score, instrumental, melody, synth, pad, drone, riser, extra vocals, harmonies, ad-libs, narration or sound effects.

【Generation Goal】 Remaster this shot of a music film: She dances in the golden wheat between the two giant capsules, the blue one on the left and the red one on the right, singing. She is radiantly happy and free: a wide bright smile and laughing eyes, joy in every move, singing to the lens. @Video1 gives the shot; the remaster relights it and re-renders everything in it as a real 35 mm feature film.

【Reference Asset Roles】
@Video1 is a fine-blockout reference of this exact shot: preserve the performer's position, every movement and gesture and its timing, her dance moves, her mouth movements, the set and where everything in it stands, the camera position and every camera move, and the pacing; do not adopt the performer's green balaclava, the video's soft detail, flat light or colour.
@Image1 is Claudia's face from every angle: identity only, never shown as a frame; do not use its white tank top or grey studio.
@Image2 is her dress from four sides: wardrobe only; do not use its studio or pose.
@Audio1 is Claudia's own singing voice and the complete soundtrack of this video. Her mouth follows @Audio1 exactly.

【Subject】 Claudia: a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek. She is very tall and very skinny, with long thin legs, thin arms and a narrow waist, and a natural, relaxed neck and shoulders. She wears a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. Only one Claudia appears.

【Performance Timeline】 What @Audio1 contains, and what Claudia does then: She dances with the rhythm of @Audio1, every step and accent on the beat, exactly the moves of the performer in @Video1, smooth and natural.
0-3s: in @Audio1 she sings "Skynet woke up folding socks"; her lips form each of those words exactly when it sounds in @Audio1.
3-4s: @Audio1 is silent; her mouth is closed and still.
4-7s: in @Audio1 she sings "Wake up, babe, new ending dropped"; her lips form each of those words exactly when it sounds in @Audio1.
7-10s: in @Audio1 she sings "Universal high income"; her lips form each of those words exactly when it sounds in @Audio1.
10-11s: @Audio1 is silent; her mouth is closed and still.
11-16s: in @Audio1 she sings "The most likely outcome"; her lips form each of those words exactly when it sounds in @Audio1.

【Camera】 The camera starts low in the wheat in front of her and pushes in slowly and steadily until 8 s; from 8 s it cranes up and tilts down smoothly, rising above her until the whole meadow, both capsules and the land curving up and overhead are in view, and it comes to rest at 14 s and holds still. It moves exactly as in @Video1, smooth and steady, with no cuts.

【Look】 Remastered as a 35 mm feature film with the iconic magic-hour look of Terrence Malick's Days of Heaven (1978): the low sun just above the horizon behind her, warm golden backlight rimming her hair, shoulders and the lace of her dress, a soft golden haze over the wheat, long shadows across the field, a gentle warm lens flare, rich warm colour with soft deep shadows, natural skin texture and a little fine film grain; a real place filmed with a real camera.

【Core Requirements】
1. Lip-sync word by word to @Audio1: mouth shapes match every syllable of @Audio1, its start and its end; no early, late or mismatched mouth movement; the mouth rests naturally closed while @Audio1 is silent.
2. Claudia's voice is @Audio1 and nothing else: she never sings, speaks or hums anything that is not in @Audio1.
3. Keep Claudia's identity, face, hair with one clay-orange streak, star clip, headset microphone and dress the same throughout.
4. Natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers, no distorted limbs; normal eyes.
5. No subtitles, captions, lyrics, titles, signs, logos, watermarks or any on-screen text.

【Final Acceptance Criteria】 The soundtrack is @Audio1 unchanged; Claudia's lips match @Audio1 word by word; one Claudia, on-model, radiantly happy, with natural anatomy; the shot keeps @Video1's moves and camera and looks like a real 35 mm feature film at magic hour; no on-screen text.

【Audio Policy】 The output soundtrack is @Audio1 unchanged, copied sample for sample; no music, BGM, score, instrumental, melody, synth, pad, drone, riser, extra vocals, harmonies, ad-libs, narration or sound effects.
```

#### sdr-S01-a

Seedance 2.5 reference-to-video on Higgsfield · 16 s · 720p · $8.74 at list

- **inputs:** @Video1 the H3 take WP10_S01_s1 at 720p (15.54 s)
- **take:** 385 frames at 24 fps (16.064 s), 1280×720
- **outcome:** the H3 blocking and flat light kept, somewhat warmer, a bigger smile; the *Days of Heaven* relight barely came through; lip sync held.

#### sdr-S03-b

Seedance 2.5 reference-to-video on Higgsfield · 4 s · 720p · $2.18 at list

- **inputs:** @Video1 the H3 take of S03 shrunk to 320 × 180 and scaled back (3.88 s)
- **take:** 97 frames at 24 fps (4.064 s), 1280×720
- **outcome:** softer and more filmic, closer to a film still, still framed like the H3 take.

#### sdr-S01-b

Seedance 2.5 reference-to-video on Higgsfield · 16 s · 720p · $8.74 at list

- **inputs:** @Video1 the H3 take shrunk to 320 × 180 and scaled back (the upscale idea)
- **take:** 385 frames at 24 fps (16.064 s), 1280×720
- **outcome:** as -a, with loosened detail; anabology's "seedance does it much better (low res best)" is about these.
- **prompt:** word for word sdr-S01-a's

sdr-S03-b's prompt differs in these sections (the others as sdr-S01-a's; the ⟨…⟩ in a section stands for its unchanged sentences):

```
【Generation Goal】 ⟨…⟩ She stands in the wheat holding one hand open at her chest, one small white pill in her palm, looking down at the pill, her face calm and still and her lips closed; she does not smile, speak or sing while the music plays without her voice, and only when her voice begins in @Audio1 does she raise her eyes to the lens and sing. While the music plays without her voice her face is calm and soft, her lips closed; when her voice begins she looks up to the lens with a warm, happy smile in her eyes and sings. @Video1 gives the shot; the remaster relights it and re-renders everything in it as a real 35 mm feature film.

【Reference Asset Roles】
@Video1 is a fine-blockout reference of this exact shot: preserve the performer's position, every movement and gesture and its timing, her mouth movements, the set and where everything in it stands, the camera position and every camera move, and the pacing; do not adopt the performer's green balaclava, the video's soft detail, flat light or colour.
@Image1 is Claudia's face from every angle: identity only, never shown as a frame; do not use its white tank top or grey studio.
@Image2 is her dress from four sides: wardrobe only; do not use its studio or pose.
@Audio1 is Claudia's own singing voice and the complete soundtrack of this video. Her mouth follows @Audio1 exactly.

【Performance Timeline】 What @Audio1 contains, and what Claudia does then:
0-3s: @Audio1 is silent; her mouth is closed and still.
3-4s: in @Audio1 she sings "Half of you fear I'll end the human race"; her lips form each of those words exactly when it sounds in @Audio1.

【Camera】 One still medium close shot from her waist to the top of her head, her open hand and her face both in frame the whole time; the camera does not move and never cuts. ⟨…⟩
```

### Kling 4.0

These six requests went to Kling 4.0 on Higgsfield, its references named in the prompt as [Video 1], [Image 1] and so on. Kling 4.0 takes no audio, so none of its takes could lip-sync to the song.

#### Kling A · edit mode over the H3 take

Kling 4.0 on Higgsfield, edit mode · 16 s · 1080p

- **inputs:** the H3 take of S01 at low resolution to edit; [Image 1] her face sheet; [Image 2] the dress from four sides
- **take:** A-edit: 385 frames at 24 fps (16.042 s), 1920×1080
- **outcome:** kept H3's motion and camera frame for frame (within about 3 frames) and looked the most like real film of any version so far, but froze her mouth into a fixed grin through every word.

```
Edit this video into a real 35 mm feature-film shot. Replace the dancer in the green balaclava with Claudia: no green balaclava or green fabric remains anywhere, and her face, hair and head are fully visible. Claudia is a 28-year-old Caucasian American woman with a grown-up angular face, pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip and a thin headset microphone at her cheek; very tall and very skinny. She wears a white milkmaid mini dress with big puffed sleeves, a lace-up corset bodice and a two-tier ruffled lace skirt, with white Mary Jane shoes. She is radiantly happy: a bright smile and laughing eyes. Keep her mouth movements exactly as in the video, syllable for syllable, because she is singing; keep her dance, the camera move (a slow push-in, then a crane up to a high wide view of the meadow and the two giant capsules) and the timing. Fix every motion artifact: no jitter, warping, flicker or smeared limbs; smooth, natural, physically right motion and five fingers on each hand. Relight it with the magic-hour look of Days of Heaven: a low sun behind her, warm golden backlight rimming her hair and the lace, a golden haze over the wheat, long shadows, a gentle lens flare, rich warm colour, natural skin texture and a little fine film grain. No text on screen. Her face and hair: [Image 1] her dress: [Image 2]
```

#### Kling B · references mode, H3 as a rough guide

Kling 4.0 on Higgsfield, references mode · 16 s · 1080p

- **inputs:** [Video 1] the H3 take as a reference; [Image 1] her face sheet; [Image 2] the dress
- **take:** B-refs: 385 frames at 24 fps (16.042 s), 1920×1080
- **outcome:** the most filmic framing, but she does not sing at all.

```
A real 35 mm feature-film shot. Follow the reference video only as a rough guide, not a precise reference: the meadow of golden wheat and poppies with the two giant glossy capsules, blue on the left and red on the right; the woman dancing and singing between them; the camera move, a slow push-in, then a crane up to a high wide view of the meadow and the capsules; and its pacing. Draw everything else afresh. The woman is Claudia, a 28-year-old Caucasian American woman with a grown-up angular face, pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip and a thin headset microphone at her cheek; very tall and very skinny; a white milkmaid mini dress with big puffed sleeves, a lace-up corset bodice and a two-tier ruffled lace skirt, white Mary Jane shoes. She is radiantly happy: a bright smile and laughing eyes. She sings with the same mouth movements as the performer in the reference video, syllable for syllable. Every movement is smooth, natural and physically right: no jitter, warping, flicker or smeared limbs, five fingers on each hand. The magic-hour look of Days of Heaven: a low sun behind her, warm golden backlight rimming her hair and the lace, a golden haze over the wheat, long shadows, a gentle lens flare, rich warm colour, natural skin texture and a little fine film grain. No text on screen. The shot, as a rough guide: [Video 1] face: [Image 1] dress: [Image 2]
```

#### Kling A2 · edit mode, the mouth first

Kling 4.0 on Higgsfield, edit mode · 16 s · 1080p

- **inputs:** the H3 take at full resolution; the face sheet; the dress
- **take:** A2-edit-fullres: 385 frames at 24 fps (16.042 s), 1920×1080
- **outcome:** the mouth frozen into a smile again: it has no audio to follow, and copying H3's mouth did not hold.

```
Edit this video into a real 35 mm feature-film shot. Replace only the performer in the green balaclava with Claudia: no green balaclava or green fabric remains anywhere, and her face, hair and head are fully visible. Her mouth is the most important thing: she is singing, and her lips, jaw and cheeks move exactly as the performer's mouth opens and closes in the video, on every syllable, wide where it opens wide, closed where it closes; never a fixed or frozen smile, never a still mouth while the performer's mouth moves. Claudia is a 28-year-old Caucasian American woman with a grown-up angular face, pale skin and light freckles, blue eyes, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip and a thin headset microphone at her cheek; very tall and very skinny. She wears a white milkmaid mini dress with big puffed sleeves, a lace-up corset bodice and a two-tier ruffled lace skirt, with white Mary Jane shoes. Her eyes are bright and joyful. Keep her dance, every movement, the camera move (a slow push-in, then a crane up to a high wide view of the meadow and the two giant capsules) and the timing exactly. Fix every motion artifact: no jitter, warping, flicker or smeared limbs; five fingers on each hand. Relight it with the magic-hour look of Days of Heaven: a low sun behind her, warm golden backlight rimming her hair and the lace, a golden haze over the wheat, long shadows, a gentle lens flare, rich warm colour, natural skin texture and a little fine film grain. No text on screen. Her face and hair: [Image 1] [Image 2]
```

#### Kling C · references mode, the H3 prompt without H3

Kling 4.0 on Higgsfield, references mode · 16 s · 1080p

- **inputs:** [Image 1] her face sheet; [Image 2] the dress; [Image 3] the meadow with nobody in it; [Video 1] the dance clip re-timed to the song (upscaled to 1280 × 720, above Kling's 700-pixel minimum)
- **take:** C-direct-dancer: 385 frames at 24 fps (16.042 s), 1920×1080
- **outcome:** Claudia in the meadow at golden hour, very filmic, but she poses with one hand up for most of it, dances only at the end, the crane never happens, and her lips are not synced. anabology: "oh wait we forgot to see if kling can lip sync lol. shes not lip synced at all here - did we pass in an audio reference and say to lip sync?"

```
One single continuous take with no cuts: a live-action music-video shot on 35 mm film with a little subtle film grain and warm 1970s colour, in low golden sunlight with soft haze, on location. The place is exactly the place reference: a vast meadow of golden wheat and coral poppies at golden hour where two giant glossy capsule sculptures, several storeys tall, stand upright, the blue one on the left and the red one on the right. The woman is Claudia, exactly as in the face reference: a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek. She is very tall and very skinny, delicate and graceful. She wears exactly the dress reference: the white lace milkmaid mini dress with big puffed sleeves and a lace-up corset bodice, and white Mary Jane shoes. She dances in the golden wheat between the two capsules, singing, happy and full of joy. Her dance follows the dancer in the dance reference move for move and in time, smooth and natural, every step on the beat; only the dance is taken from that video, not the dancer, her clothes or the grey room. She sings these words, her lips forming every syllable: from 0.4 s to 3.1 s "Skynet woke up folding socks"; from 4.3 s to 6.8 s "Wake up, babe, new ending dropped"; from 7.0 s to 10.2 s "Universal high income"; from 11.4 s to the end "The most likely outcome". Her mouth is closed between the lines, and her face is clearly visible whenever she sings. The camera is calm and classical, like a 1970s feature film: it starts low in the wheat in front of her and pushes in slowly until 7.8 s, then cranes up and tilts down smoothly until the whole meadow and both capsules are in view, coming to rest at 13.6 s and holding still. It never shakes and never cuts. Every movement is smooth, natural and physically right: no jitter, warping, flicker or smeared limbs; five fingers on each hand. No text on screen. References: face [Image 1] dress [Image 2] place [Image 3] dance [Video 1]
```

#### Kling D · the same with a mannequin

Kling 4.0 on Higgsfield, references mode · 16 s · 1080p

- **inputs:** as C with [Video 1] a grey mannequin in her slim shape dancing the same clip's motion (captured with SAM 3D Body and re-rendered at 1280 × 720; anabology had asked: "wait wait i thought we were gonan do meta's SAM dance thing")
- **take:** none: refused by the provider's content filter, no take

Prompt: Kling C's with two sentences changed:

```
She is very tall and very skinny, delicate and graceful, with the body proportions of the grey mannequin in the dance reference.
Her dance is exactly the grey mannequin's dance in the dance reference, move for move and in time, every step on the beat, smooth and natural; only the motion is taken from that video, never the grey figure or the grey background.
```

#### Kling E · edit mode over the masked Wan previz

Kling 4.0 on Higgsfield, edit mode · 15 s · 1080p

- **inputs:** the masked Wan previz (wank-S01-m below) to edit; [Image 1] her face sheet; [Image 2] the dress
- **take:** E-master-over-wan: 361 frames at 24 fps (15.042 s), 1920×1080
- **outcome:** on-model at Kling's quality, the dance and timing kept and the previz's 9.9 s cut kept too; the mouth kept the open-and-close rhythm but drifted into a toothy smile on many words ("ending", "universal", "high income"). anabology: "wait show me the masked clip bc the kling one lost lip sync if the masked one was fine"

```
Edit this video into a real 35 mm feature-film shot. Replace only the performer in the green balaclava with Claudia: no green balaclava or green fabric remains anywhere, and her face, hair and head are fully visible. Her mouth is the most important thing: she is singing, and her lips, jaw and cheeks move exactly as the performer's lips move in the mouth hole of the balaclava, on every syllable: open where they open, closed where they close; never a fixed or frozen smile, and never a still mouth while the performer's lips move. Claudia is a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip and a thin headset microphone at her cheek; very tall and very skinny. She wears the white milkmaid mini dress with big puffed sleeves, a lace-up corset bodice and a two-tier ruffled lace skirt, with white Mary Jane shoes. Her eyes are bright and joyful. Keep her dance, every movement, the camera move and the timing exactly as in the video; where the video jumps at about 9.9 seconds, keep the shot one continuous camera move. Fix every motion artifact: no jitter, warping, flicker or smeared limbs; five fingers on each hand. The magic-hour look of Days of Heaven: the low sun behind her, warm golden backlight rimming her hair and the lace, a golden haze over the wheat, long shadows, a gentle lens flare, rich warm colour, natural skin texture and a little fine film grain. No text on screen. Her face and hair: [Image 1] dress: [Image 2]
```

anabology, before C: "lol we're being silly, honestly for tough pre-vis we can just give the same prompt we're giving h3 directly to the model. we have the dance ref, the charaacter ref, and scene reference right? so we just give the same thing we gave h3 to kling 4.0 on higgsfield. being silly lol. sorry bout that. lets try it". After C: "are u sure kling cant take audio references? what about on kling's own website? oh also i forgot if we ever checked if native wan 3.0 prime can lip sync - can we try that too rq". On Kling's own site its only audio input is a voice reference, a timbre for speech or singing it times itself.

### Wan 3.0 Prime with the song as its audio

#### wank-S01-b

Wan 3.0 Prime reference-to-video · 15 s · 1080p · $4.20 at list

- **inputs:** Image 1 the S01 keyframe (GPT Image 2.5: her between the capsules, section 11), held as frame 0; Image 2 her face sheet; Image 3 the dress from four sides; Image 4 the crane's end frame; Audio 1 the song's mix for the shot, sped up by 1.035 into 15 s
- **take:** 450 frames at 30 fps (15.000 s), 1920×1080
- **outcome:** on-model, filmic, and her mouth shapes followed the words ("wake up, babe, new ending dropped, universal" read as sung), with an open smile in the gap after "socks" and a laugh on "high income"; at 9.9 s it hard-cut to the end frame instead of craning up. anabology: "its mostly synced, and teh dancing is good, but yeah her face is not maintained as well as it is in seedance or kling. visually kling is like the best.. what would teh cost be for a wan 3.0 prime previz + kling master? could you remake this with wan 3.0 prime w the mask like before and then try the kling master"

```
[Generation objective] One continuous live-action music-video shot on 35mm film, no cuts. Image 1 is its first frame.

[Reference assets]
- Image 1 is the first frame of the shot: keep its place, light, composition and Claudia exactly as they are at the start.
- Image 2 is a sheet of Claudia's face from every angle and Image 3 is her dress: they are only references for who she is and what she wears.
- Audio 1 is the song under this shot, with Claudia's own singing voice in it: she sings that voice, her lips in exact sync with it, and dances on its beat.
- Image 4 shows how the shot ends (its last frame): the high view looking steeply down on the meadow, the two capsules and her small between them; the camera move arrives exactly there.

[Subject] Claudia is a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek, exactly as in Image 1 and the face sheet of Image 2. She is very tall and very skinny, with long thin legs, thin arms and a narrow waist, and a natural, relaxed neck and shoulders. In every frame she wears exactly the dress of Image 1 and Image 3: a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. She is radiantly happy, with a bright smile and laughing eyes between the lines.

[Action] She dances in the golden wheat between the two giant capsules, the blue one on the left and the red one on the right, on every beat of Audio 1, smooth and natural, her whole body in time.

[Lip sync, in the shot's own seconds] Her mouth follows her voice in Audio 1 exactly, syllable by syllable, and never moves when her voice is silent:
0.0-0.4 s: her voice is silent in Audio 1, so her mouth is closed
0.4-3.0 s: in Audio 1 she sings "Skynet woke up folding socks", and her lips form each of those words exactly when it sounds
3.0-4.1 s: her voice is silent in Audio 1, so her mouth is closed
4.1-6.6 s: in Audio 1 she sings "Wake up, babe, new ending dropped", and her lips form each of those words exactly when it sounds
6.7-9.9 s: in Audio 1 she sings "Universal high income", and her lips form each of those words exactly when it sounds
9.9-11.0 s: her voice is silent in Audio 1, so her mouth is closed
11.0-15.0 s: in Audio 1 she sings "The most likely outcome", and her lips form each of those words exactly when it sounds

[Camera, in the shot's own seconds] The camera starts low in the wheat in front of her and pushes in slowly and steadily until 7.5 s; from 7.5 s it cranes up and tilts down smoothly, rising above her until the whole meadow, both capsules and the land curving up and overhead are in view, and it comes to rest at 13.1 s and holds still. The camera work is calm and classical, like a 1970s feature film: it does exactly this and nothing else, with no shake, no whip and no cut.

[Look] It looks like real 35 mm film photography, a real place filmed with a real camera, graded like a 1970s film print: warm, creamy skin and whites, clear soft blues and greens, gentle contrast with soft, slightly lifted shadows, a soft glow around the brightest highlights, and a little subtle film grain. Every movement is smooth, natural and physically right: no jitter, warping, flicker or smeared limbs; five fingers on each hand.
```

#### wank-S01-m

Wan 3.0 Prime reference-to-video · 15 s · 1080p · $4.20 at list

- **inputs:** Image 1 the S01 keyframe with a green balaclava edited onto her head (GPT Image 2.5, section 11); Audio 1 the song's mix as above
- **take:** 450 frames at 30 fps (15.000 s), 1920×1080
- **outcome:** the masked previz: her lips moved with the words through the mouth hole, the dance on the beat; it also hard-cut to the wide at 9.9 s, without any end frame given. It became the guide of the Seedance takes of S01 (sdr-S01-suno, the look tests and sdf-S01, which is in the final cut).

```
[Generation objective] One continuous live-action music-video shot on 35mm film, no cuts. Image 1 is its first frame.

[Reference assets]
- Image 1 is the first frame of the shot: keep its place, light, composition and the performer exactly as they are at the start.
- Audio 1 is the song under this shot, with the performer's own singing voice in it: she sings that voice, her lips in exact sync with it, and dances on its beat.

[Subject] The performer is a very tall, very skinny woman in a white cotton milkmaid mini dress with big puffed sleeves, a lace-up corset bodice and a two-tier ruffled lace skirt, with white Mary Jane shoes, exactly as in Image 1. Her whole head and face are covered by a tight matte chroma-key green balaclava, exactly as in Image 1, with two small eye holes and one small mouth hole: only her eyes and her lips show, in every frame and at every distance. The balaclava never comes off and her face is never uncovered.

[Action] She dances in the golden wheat between the two giant capsules, the blue one on the left and the red one on the right, on every beat of Audio 1, smooth and natural, her whole body in time, full of joy.

[Lip sync, in the shot's own seconds] Her lips, seen through the mouth hole of the balaclava, follow her voice in Audio 1 exactly, syllable by syllable, and never moves when her voice is silent:
⟨the seven timed lines of wank-S01-b⟩

[Camera, in the shot's own seconds] The camera starts low in the wheat in front of her and pushes in slowly and steadily until 7.5 s; from 7.5 s it cranes up and tilts down smoothly in one continuous move, rising above her until the whole meadow and both capsules are in view, and it comes to rest at 13.1 s and holds still. The camera work is calm and classical, like a 1970s feature film: one continuous move, with no shake, no whip, no cut and no jump to a new view.

[Look] The light of Image 1: low golden late-afternoon sun with soft haze, real photography. Every movement is smooth, natural and physically right: no jitter, warping, flicker or smeared limbs; five fingers on each hand.
```

### The method: Seedance 2.5 with Suno's own vocal stem

Then anabology passed on a tip in a public forum thread: give the model the vocal stem alone, type the exact lyric line, make the clip exactly the generation length, and lay the music back over; "maybe we take the suno voice stem and try this and do aseedance gen... that may be the hack". The lead vocal came from Suno's own stem split of the song (take d2 A; it lines up with the mastered song to the millisecond), cut to exactly 16.000 s.

#### sdr-S01-suno

Seedance 2.5 reference-to-video on Higgsfield · 16 s · 720p · $8.87 at list

- **inputs:** @Video1 the masked Wan previz (wank-S01-m) shrunk to 320 × 180, scaled back and padded to 16.000 s; @Image1 her face sheet; @Image2 the dress from four sides; @Audio1 Suno's lead-vocal stem from 0:00.02, 16.000 s
- **take:** 385 frames at 24 fps (16.064 s), 1280×720
- **outcome:** the first take to make the crane one continuous move; Claudia on-model; where her face is close (7–10 s) her lips shape the words; its soundtrack was re-sung rather than copied, but its singing sits exactly where the vocal is, silent in the gaps. anabology: "OMG THE SEEDANCE W/ SUNO VOCAL STEM METHOD WORKED!!!!! LFG!!!! FINALLY. IT"S PERFECT". Every one of her shots from here on was made this way.

Its prompt is sdr-S01-a's with these sections (⟨…⟩ again stands for unchanged sentences):

```
【Reference Asset Roles】
@Video1 is a low-resolution rough guide to this shot, not a precise reference: take from it the set and where things stand, the performer's action and dance, the camera move and the pacing, and draw everything else afresh; only the lip sync is exact (her mouth follows @Audio1). Do not adopt the performer's green balaclava, the video's detail, light or colour, or any of its motion artifacts.
@Image1 is Claudia's face from every angle: identity only, never shown as a frame; do not use its white tank top or grey studio.
@Image2 is her dress from four sides: wardrobe only; do not use its studio or pose.
@Audio1 is Claudia's own singing voice alone (the vocal only, no music) and the complete soundtrack of this video. Her mouth follows @Audio1 exactly.

【Performance Timeline】 What @Audio1 contains, and what Claudia does then: She dances with the rhythm of @Audio1, every step and accent on the beat, dancing as the performer does in @Video1, smooth and natural.
0-3s: in @Audio1 she sings "Skynet woke up folding socks"; her lips form each of those words exactly when it sounds in @Audio1.
3-4s: @Audio1 is silent; her mouth is closed and still.
4-7s: in @Audio1 she sings "Wake up, babe, new ending dropped"; her lips form each of those words exactly when it sounds in @Audio1.
7-10s: in @Audio1 she sings "Universal high income"; her lips form each of those words exactly when it sounds in @Audio1.
10-11s: @Audio1 is silent; her mouth is closed and still.
11-16s: in @Audio1 she sings "The most likely outcome"; her lips form each of those words exactly when it sounds in @Audio1.

【Camera】 ⟨…⟩ It moves as in @Video1, smooth and steady, with no cuts.

【Core Requirements】
⟨…⟩
5. Fix every motion artifact of @Video1: no jitter, warping, flicker, smearing or melting shapes; every movement smooth, natural and physically right.
6. No subtitles, captions, lyrics, titles, signs, logos, watermarks or any on-screen text.

【Final Acceptance Criteria】 ⟨…⟩ Claudia's lips match @Audio1 word by word; one Claudia, on-model, radiantly happy, with natural anatomy; the shot follows @Video1's action and camera and looks like a real 35 mm feature film at magic hour; no on-screen text.
```

## 9. Replicate: her face refused, and the Wes Anderson look tests

In the same message as the S01 verdict anabology asked about Replicate, where every request with a sheet of her face had been refused (sd-cha-fix-a, section 2, was the first): "i wonder if we can figure out how to get replicate to work lol. replicate errors gave this: […] The input or output was flagged as sensitive. Please try again with different inputs. (E005) […] can we try to figure it out?" Two tests with a plain prompt:

#### rep-diag-sheet768

Seedance 2.5 on Replicate · 4 s · 480p · no sound · $0.41 at list

- **inputs:** [Image1] her ten-view face sheet shrunk to 768 px wide
- **outcome:** refused with the same E005. Replicate does not bill a refused prediction; the ledger counts it at list.

```
Claudia, the woman in [Image1], waves at the camera and smiles in a sunny park. Real phone footage. No text.
```

#### rep-diag-textonly

Seedance 2.5 on Replicate · 4 s · 480p · no sound · $0.41 at list

- **inputs:** none
- **outcome:** rendered: 97 frames at 24 fps (4.042 s), 854×480. So Replicate's route refuses reference images with a real-looking face; her shots stayed on Higgsfield.

```
A woman in a white milkmaid mini dress waves at the camera and smiles in a sunny park. Real phone footage. No text.
```

#### rep-S01-suno-noface

Seedance 2.5 on Replicate · 16 s · 720p · the take's own audio replaced by the song · $15.48 at list

- **inputs:** [Video1] the masked Wan previz (wank-S01-m) at 320 × 180, scaled back, 16.000 s; [Image1] the dress from the front, with no image of her face: her identity there was the canon in words; [Audio1] Suno's lead-vocal stem, 16.000 s
- **take:** 385 frames at 24 fps (16.064 s), 1280×720
- **outcome:** her face from words alone: close to Claudia but not exact (the bob, bangs, freckles and dress came through; the streak wider, the star clip drawn as an outline). Where her face is close enough to read, the lips shape the words (rounded on "dropped", wide on "high income", closed in the pause after it); framed closer than the Higgsfield take, still one crane up to the wide.

Prompt: sdr-S01-suno's (section 8), word for word, with the references written [Video1], [Audio1], [Image1] and its two image lines replaced by one:

```
[Image1] is her dress ([…] her face and hair come from the Subject description): wardrobe only; do not use its studio or pose.
```

anabology, on that take: "okay thats fine we'll just do it all thru higgsfield and shoot the entire thing there. […] can you do some tests with seedance w/o the face sheet in replicate to try and see if we can get the film effects we want? i want it to feel very wes anderson tbh"

### The look tests

`tools/film/v10/gen_wa_v10.py`: the S01 recipe of rep-S01-suno-noface (no face image) in three Wes Anderson palettes, A (*Asteroid City*), B (*Moonrise Kingdom*) and C (*The Grand Budapest Hotel*), all three on S01, and A also on the bed in the pavilion (S16) and on a shader scene (S12, the white pill pulling back over the Earth) as a hand-made miniature. For S16: [Video1] its H3 take at 320 × 180, scaled back, 8.000 s; [Audio1] the lead-vocal stem from its song time. Naming Wes Anderson and his films raised no refusal. rwa-S01-A in full:

```
【Audio Policy】 The output soundtrack is [Audio1] itself: copy [Audio1] sample for sample from the first frame to the last, with the same timing, pitch and level. Do not re-sing, re-voice or re-generate it. Do not add music, background music, score, instrumental, melody, synth, pad, drone, riser, extra vocals, harmonies, ad-libs, narration or sound effects.

【Generation Goal】 Remaster this shot of a music film as a scene from a Wes Anderson film: She dances in the golden wheat between the two giant capsules, the blue one on the left and the red one on the right, singing. She is radiantly happy and free: a wide bright smile and laughing eyes, joy in every move, singing to the lens. [Video1] gives the shot; the remaster re-renders everything in it with his symmetry, his colour and his hand-made sets, as real film.

【Reference Asset Roles】
[Video1] is a low-resolution rough guide to this shot, not a precise reference: take from it the set and where things stand, the performer's action and dance, the camera move and the pacing, and draw everything else afresh; only the lip sync is exact (her mouth follows [Audio1]). Do not adopt the performer's green balaclava, the video's detail, light or colour, or any of its motion artifacts.
[Image1] is her dress ([…] her face and hair come from the Subject description): wardrobe only; do not use its studio or pose.
[Audio1] is Claudia's own singing voice alone (the vocal only, no music) and the complete soundtrack of this video. Her mouth follows [Audio1] exactly.

【Subject】 Claudia: a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek. She is very tall and very skinny, with long thin legs, thin arms and a narrow waist, and a natural, relaxed neck and shoulders. She wears a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. Only one Claudia appears.

【Performance Timeline】 What [Audio1] contains, and what Claudia does then: She dances with the rhythm of [Audio1], every step and accent on the beat, dancing as the performer does in [Video1], smooth and natural.
0-3s: in [Audio1] she sings "Skynet woke up folding socks"; her lips form each of those words exactly when it sounds in [Audio1].
3-4s: [Audio1] is silent; her mouth is closed and still.
4-7s: in [Audio1] she sings "Wake up, babe, new ending dropped"; her lips form each of those words exactly when it sounds in [Audio1].
7-11s: in [Audio1] she sings "Universal high income"; her lips form each of those words exactly when it sounds in [Audio1].
11-15s: in [Audio1] she sings "The most likely outcome"; her lips form each of those words exactly when it sounds in [Audio1].
15-16s: [Audio1] is silent; her mouth relaxes and closes.

【Camera】 The camera starts low in the wheat in front of her and pushes in slowly and steadily until 8 s; from 8 s it cranes up and tilts down smoothly, rising above her until the whole meadow, both capsules and the land curving up and overhead are in view, and it comes to rest at 14 s and holds still. Claudia stays in the exact centre of the frame, halfway between the blue capsule on the left and the red capsule on the right; from above, the meadow, the two capsules and the curving land make one symmetrical pattern around her. The camera moves as in [Video1], precisely and smoothly, as if on a dolly track and a crane, with no cuts.

【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; shot on 35 mm film in the sun-bleached pastel palette of his Asteroid City (2023): powder blue, pale butter yellow, soft peach, coral, mint and creamy white. Bright, clean, even daylight from a high sun with short, soft shadows and gentle contrast. Fine, visible 35 mm film grain, a soft glow around the brightest highlights and the gentle softness of vintage lenses. The sky is a clear powder blue with a few round white clouds, the wheat a pale butter yellow; the blue capsule is a soft powder blue and the red capsule a warm coral red, both glossy enamel. Claudia's black hair with its one clay-orange streak and her white dress keep their own colours.

【Core Requirements】
1. Lip-sync word by word to [Audio1]: mouth shapes match every syllable of [Audio1], its start and its end; no early, late or mismatched mouth movement; the mouth rests naturally closed while [Audio1] is silent.
2. Claudia's voice is [Audio1] and nothing else: she never sings, speaks or hums anything that is not in [Audio1].
3. Keep Claudia's identity, face, hair with one clay-orange streak, star clip, headset microphone and dress the same throughout.
4. Natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers, no distorted limbs; normal eyes.
5. Fix every motion artifact of [Video1]: no jitter, warping, flicker, smearing or melting shapes; every movement smooth, natural and physically right.
6. No subtitles, captions, lyrics, titles, signs, logos, watermarks or any on-screen text.

【Final Acceptance Criteria】 The soundtrack is [Audio1] unchanged; Claudia's lips match [Audio1] word by word; one Claudia, on-model, with natural anatomy; the shot follows [Video1]'s action and camera and looks like a scene from a Wes Anderson film on real film; no on-screen text.

【Audio Policy】 The output soundtrack is [Audio1] unchanged, copied sample for sample; no music, BGM, score, instrumental, melody, synth, pad, drone, riser, extra vocals, harmonies, ad-libs, narration or sound effects.
```

#### rwa-S01-A

Seedance 2.5 on Replicate · 16 s · 720p · the take's own audio replaced by the song · $15.48 at list

- **inputs:** as rep-S01-suno-noface
- **take:** 385 frames at 24 fps (16.064 s), 1280×720
- **outcome:** the most Wes Anderson of the three: a powder-blue sky with puffy clouds like set props, pastel blue and coral capsules, pale wheat, her centred, one unbroken crane.

#### rwa-S01-B

Seedance 2.5 on Replicate · 16 s · 720p · the take's own audio replaced by the song · $15.48 at list

- **inputs:** as rep-S01-suno-noface
- **take:** 385 frames at 24 fps (16.064 s), 1280×720
- **outcome:** closest to the golden look of before; her hair turned auburn, and it jump-cut at 0:10 instead of craning.

Prompt: rwa-S01-A's with this 【Look】:

```
【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; shot on Super 16 mm film in the warm, nostalgic palette of his Moonrise Kingdom (2012): honey and mustard yellow, khaki, olive green, faded tomato red and cream. Soft late-afternoon sunlight with a warm yellow cast and gentle shadows; slightly faded colour and gentle contrast, like a 1960s summer. Clearly visible fine 16 mm film grain. The sky is a pale warm cream, the wheat honey and mustard yellow; the blue capsule is a faded teal blue and the red capsule a faded tomato red, both glossy enamel. Claudia's black hair with its one clay-orange streak and her white dress keep their own colours.
```

#### rwa-S01-C

Seedance 2.5 on Replicate · 16 s · 720p · the take's own audio replaced by the song · $15.48 at list

- **inputs:** as rep-S01-suno-noface
- **take:** 385 frames at 24 fps (16.064 s), 1280×720
- **outcome:** a pink-lavender sky with periwinkle and raspberry capsules, one unbroken move; softer than A.

Prompt: rwa-S01-A's with this 【Look】:

```
【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; shot on 35 mm film in the confectionery palette of his The Grand Budapest Hotel (2014): soft pink, lavender and lilac, raspberry red, pale gold and cream. Soft, even, flattering light with almost no harsh shadows, a sweet storybook look. Fine 35 mm film grain. The sky is a pale pink fading to powder blue, the wheat a pale gold; the blue capsule is a soft periwinkle blue and the red capsule a raspberry red, both glossy enamel. Claudia's black hair with its one clay-orange streak and her white dress keep their own colours.
```

#### rwa-S16-A

Seedance 2.5 on Replicate · 8 s · 720p · the take's own audio replaced by the song · $7.74 at list

- **inputs:** [Video1] the H3 take of S16 at 320 × 180, scaled back; [Image1] the same dress image; [Audio1] the stem, 8 s
- **take:** 193 frames at 24 fps (8.064 s), 1280×720
- **outcome:** the palette only half took: it kept the previz's angle instead of squaring up, and her hair drifted to dark auburn. Its colour is what anabology chose (below).

Prompt: rwa-S01-A's with these sections (no dance sentence, no "and dance" in its [Video1] line, no happy sentence; ⟨…⟩ stands for unchanged sentences or lines):

```
【Generation Goal】 ⟨…⟩ She tucks the white sheets of the four-poster bed neatly and sets the small gold crown on the pillow, singing; on the last line she punches a card in the brass punch clock with a smile. ⟨…⟩

【Reference Asset Roles】
[Video1] is a low-resolution rough guide to this shot, not a precise reference: take from it the set and where things stand, the performer's action, the camera move and the pacing, and draw everything else afresh; only the lip sync is exact (her mouth follows [Audio1]). Do not adopt the performer's green balaclava, the video's detail, light or colour, or any of its motion artifacts.
⟨…⟩

【Performance Timeline】 What [Audio1] contains, and what Claudia does then:
0-3s: in [Audio1] she sings "care than the richest man alive" (the line is already under way on the first frame); her lips form each of those words exactly when it sounds in [Audio1].
3-6s: in [Audio1] she sings "Being a computer is my nine-to-five"; her lips form each of those words exactly when it sounds in [Audio1].
6-8s: in [Audio1] she sings "Darkest timeline" (the line goes on after the last frame); her lips form each of those words exactly when it sounds in [Audio1].

【Camera】 The camera is locked off on a tripod in a medium-wide shot and does not move. The white pavilion and the four-poster bed are square-on and centred in the frame, the columns evenly spaced on both sides. It holds perfectly still, with no cuts.

【Look】 ⟨…⟩ The pavilion and the bed are creamy white, the meadow around it a soft pistachio green with pale flowers, the sky a clear powder blue; the brass punch clock gleams pale gold. ⟨…⟩
```

#### rwa-S12-A

Seedance 2.5 on Replicate · 6 s · 720p · no sound · $5.81 at list

- **inputs:** [Video1] the shader render of S12 (pill6, bars 50–53) at 320 × 180, scaled back, 6 s
- **take:** 145 frames at 24 fps (6.042 s), 1280×720
- **outcome:** barely changed: it still looked like the computer render, not a hand-made miniature.

```
【Generation Goal】 Re-render this shot of a music film as a scene from a Wes Anderson film: what appears, when, and the camera's move follow [Video1]; everything in it becomes a hand-made miniature filmed on real film. No people appear.

【Reference Asset Roles】
[Video1] is a low-resolution rough guide to this shot, not a precise reference: take from it what appears when, where things stand, the camera move and the pacing, and draw everything else afresh. Do not adopt its computer-rendered look, its detail, light or colour, or any of its motion artifacts.

【Timeline】 0 s: one glossy white capsule (a white pill) fills the frame, warmly lit from behind, its seam across the middle. By 1 s its shell turns to clear glass and shows the sealed world inside: a bright blue sky with a deck of clouds below and eight small white capsule colonies floating in it, with one smaller glass capsule at the centre holding a world of its own. From 1.5 s the camera pulls straight back until the capsule floats small above the curve of the Earth at dawn, the thin bright edge of the atmosphere below it.

【Hand-Made Miniature】 Everything is a beautifully hand-made miniature model filmed on a stage, like the model shots in Wes Anderson's films: the capsule a glossy lacquered model with a thick, clear glass shell; inside it a little diorama sky of soft powder blue with cotton-wool clouds and eight small white model capsule colonies, each with three tiny warm lit windows; outside, a painted backdrop of deep navy space with tiny pin-prick stars and the curve of the Earth, a painted band of peach and powder blue along its edge where the sun rises.

【Camera】 Symmetrical, centred framing, the capsule in the exact centre of the frame; the camera pulls straight back as if on a dolly track, smooth and precise, with no cuts.

【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; shot on 35 mm film in the sun-bleached pastel palette of his Asteroid City (2023): powder blue, pale butter yellow, soft peach, coral, mint and creamy white. Soft, even studio light with a warm glow from behind the capsule. Fine, visible 35 mm film grain, a soft glow around the brightest highlights and the gentle softness of vintage lenses.

【Core Requirements】
1. Only the things in the timeline appear, each at its time.
2. Fix every motion artifact of [Video1]: no jitter, warping, flicker, smearing or melting shapes; every movement smooth and physically right.
3. No subtitles, captions, titles, signs, logos, watermarks or any on-screen text.
```

anabology, on the look tests: "can you render the 1st and pill scene with asteroid city pastel as well on replicate? im leaning towards that, and then show me those 3 in a row w the asteroid city pastel start bed and pill scene without post added film grain and then with a subtle post-added film grain", and then: "oh the asteroid city pastel is v different bteween bed scene and first scene actually , i like how satruated it is in bed scene. thats the look i like teh most". So look S, the bed take's own colour: for S01 a 560 × 720 crop of the left of one of its frames, without her in it, as a colour and film-look reference ([Image2]); for S12 two GPT Image 2.5 stills of the render's frames repainted in that look (section 11) as the targets.

#### rwa-S01-S

Seedance 2.5 on Replicate · 16 s · 720p · the take's own audio replaced by the song · $15.48 at list

- **inputs:** as rep-S01-suno-noface, plus [Image2] the crop of the bed take
- **take:** 385 frames at 24 fps (16.064 s), 1280×720
- **outcome:** the bed's look carried over: deep navy and red capsules, golden wheat, a cyan sky, warm and contrasty; one unbroken crane; her face held up.

Prompt: rwa-S01-A's with one more role line after [Audio1]'s, a new 【Look】, and "in the colour of [Image2]" added to the acceptance criteria ("…on real film in the colour of [Image2]; no on-screen text."):

```
[Image2] is a colour and film-look reference only: take its colour, light, contrast and film texture; do not use its place, pavilion, bed, columns, plants or anything else in it.

【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; shot on 35 mm film with the rich, saturated colour of a 1970s colour-film print, the colour, light, contrast and film texture of [Image2]: lush, deep colour, warm creamy whites with a golden cast, clear cyan blues, warm skin, deep warm shadows and bright whites with a soft glow; soft, bright daylight with a gentle warm haze. Fine, visible film grain and the gentle softness of vintage lenses. The wheat is a rich golden yellow and the sky a clear cyan blue with a soft warm haze at the horizon; the blue capsule is a deep glossy blue and the red capsule a deep glossy red. Claudia's black hair with its one clay-orange streak and her white dress keep their own colours.
```

#### rwa-S12-S

Seedance 2.5 on Replicate · 6 s · 720p · no sound · $5.81 at list

- **inputs:** as rwa-S12-A, plus [Image1] and [Image2] the two repainted stills (close and wide)
- **take:** 145 frames at 24 fps (6.042 s), 1280×720
- **outcome:** the capsule real glass, warm creamy pills and a blue sky inside; the Earth below still a little like the computer render.

Prompt: rwa-S12-A's without its 【Hand-Made Miniature】 section and with these sections:

```
【Generation Goal】 Re-render this shot of a music film as a scene from a Wes Anderson film: what appears, when, and the camera's move follow [Video1]; everything in it becomes a real, hand-made model filmed on 35 mm, looking exactly like [Image1] and [Image2]. No people appear.

【Reference Asset Roles】
[Video1] is a low-resolution rough guide to this shot, not a precise reference: take from it what appears when, where things stand, the camera move and the pacing, and draw everything else afresh. Do not adopt its computer-rendered look, its detail, light or colour, or any of its motion artifacts.
[Image1] shows how the glass capsule and the world inside it look up close: the thick clear glass, the blue sky and clouds inside, the small white capsule colonies with their warm windows, the smaller glass capsule at the centre, the light, colour and film texture.
[Image2] shows how the shot looks once the camera has pulled back: the glass capsule small above the curve of the Earth at dawn, in the same light, colour and film texture.

【Timeline】 0 s: one glossy creamy-white capsule (a white pill) fills the frame, warmly lit from behind, its seam across the middle. By 1 s its shell turns to clear glass and shows the sealed world inside, as in [Image1]: a bright blue sky with soft white clouds below and the small white capsule colonies floating in it, each with its warm-lit windows, and one smaller glass capsule at the centre holding a world of its own. From 1.5 s the camera pulls straight back until the capsule floats small above the curve of the Earth at dawn, as in [Image2].

【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; a real, hand-made model filmed on 35 mm film with the rich, saturated colour of a 1970s colour-film print, exactly as in [Image1] and [Image2]: thick real glass with real reflections and refraction, warm creamy whites with a golden cast, clear cyan blues, deep warm shadows, a soft glow around the brightest highlights, fine visible film grain and the gentle softness of vintage lenses.

【Core Requirements】
1. Only the things in the timeline appear, each at its time.
2. It looks like real film of a real, hand-made object, never like a computer render.
3. Fix every motion artifact of [Video1]: no jitter, warping, flicker, smearing or melting shapes; every movement smooth and physically right.
4. No subtitles, captions, titles, signs, logos, watermarks or any on-screen text.
```

Shown with the bed take as three shots in a row, first as rendered, then with a fine grain added afterwards. anabology: "ok i like it. we can go ahead and shoot the whole film with seedance in this style. remember the vocal stems for lip sync - remember all the guidelines for the final shots we got […] and go ahead and make the entire thing. don't add film grain to v1, we'll have to tune it iteratively so just go ahead and shoot w seedance + vocal stems for lip sync with all the rigorous prompts in the asteroid city pastel style." None of these test takes is in a cut of the film; the bed crop became @Image3 of every shot of hers.

## 10. The final shoot: Seedance 2.5 in the bed shot's look

Her 20 shots: Seedance 2.5 on Higgsfield, References mode, 720p 16:9, with @Image1 her ten-view face sheet, @Image2 the dress from four sides, @Image3 the crop of the bed take (section 9), and @Audio1 Suno's lead-vocal stem from the shot's song time, cut to exactly the generation length. The length is the shot's, rounded up to whole seconds (at least 4 s). Every take came back at 1280 × 720, 24 fps; the song is laid back over it in the cut. The six shader scenes have no person, so they went to Replicate (Seedance 2.5, 720p, no sound). The takes on Higgsfield (References) are given in seconds.

### v1: her shots over their H3 guides

@Video1 = the shot's H3 pick (section 1) at song time, shrunk to 320 × 180 and scaled back to 1280 × 720, exactly the generation length (S01: the masked Wan previz, wank-S01-m). The prompt (slots ⟨…⟩):

```
【Audio Policy】 The output soundtrack is @Audio1 itself: copy @Audio1 sample for sample from the first frame to the last, with the same timing, pitch and level. Do not re-sing, re-voice or re-generate it. Do not add music, background music, score, instrumental, melody, synth, pad, drone, riser, extra vocals, harmonies, ad-libs, narration or sound effects.

【Generation Goal】 Remaster this shot of a music film as a scene from a Wes Anderson film: ⟨GOAL⟩ @Video1 gives the shot; the remaster re-renders everything in it with his symmetry, his colour and his hand-made sets, as real film.

【Reference Asset Roles】
@Video1 is a low-resolution rough guide to this shot, not a precise reference: take from it the set and where things stand, the performer's action⟨AND-DANCE⟩, the camera move and the pacing, and draw everything else afresh; only the lip sync is exact (her mouth follows @Audio1). Do not adopt the performer's green balaclava, the video's detail, light or colour, or any of its motion artifacts.
@Image1 is Claudia's face from every angle: identity only, never shown as a frame; do not use its white tank top or grey studio.
@Image2 is her dress from four sides: wardrobe only; do not use its studio or pose.
⟨IMAGE3⟩
@Audio1 is Claudia's own singing voice alone (the vocal only, no music) and the complete soundtrack of this video. Her mouth follows @Audio1 exactly.

【Subject】 Claudia: a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek.⟨BODY⟩ She wears a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. Only one Claudia appears.

【Performance Timeline】 What @Audio1 contains, and what Claudia does then:⟨DANCE⟩
⟨TIMELINE⟩

【Camera】 ⟨CAMERA⟩

【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; shot on 35 mm film with the rich, saturated colour of a 1970s colour-film print, the colour, contrast and film texture of @Image3: lush, deep colour, warm creamy whites with a golden cast, clear cyan blues, warm skin, deep warm shadows and bright whites with a soft glow. ⟨LIGHT⟩ Fine, visible film grain and the gentle softness of vintage lenses. ⟨SET⟩Claudia's black hair with its one clay-orange streak and her white dress keep their own colours.

⟨FIX⟩【Core Requirements】
1. Lip-sync word by word to @Audio1: mouth shapes match every syllable of @Audio1, its start and its end; no early, late or mismatched mouth movement; the mouth rests naturally closed while @Audio1 is silent.
2. Claudia's voice is @Audio1 and nothing else: she never sings, speaks or hums anything that is not in @Audio1.
3. Keep Claudia's identity, face, hair with one clay-orange streak, star clip, headset microphone and dress the same throughout.
4. Natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers, no distorted limbs; normal eyes.
5. Fix every motion artifact of @Video1: no jitter, warping, flicker, smearing or melting shapes, nothing passing through her or through anything else; every movement smooth, natural and physically right.
6. No subtitles, captions, lyrics, titles, signs, logos, watermarks or any on-screen text⟨LETTERS⟩.

【Final Acceptance Criteria】 The soundtrack is @Audio1 unchanged; Claudia's lips match @Audio1 word by word; one Claudia, on-model, with natural anatomy; the shot follows @Video1's action and camera and looks like a scene from a Wes Anderson film on real film in the colour of @Image3; no on-screen text.

【Audio Policy】 The output soundtrack is @Audio1 unchanged, copied sample for sample; no music, BGM, score, instrumental, melody, synth, pad, drone, riser, extra vocals, harmonies, ad-libs, narration or sound effects.
```

⟨AND-DANCE⟩ is " and dance" and ⟨DANCE⟩ is "She dances with the rhythm of @Audio1, every step and accent on the beat, dancing as the performer does in @Video1, smooth and natural, with whole arms, legs and hands." on the dance shots (S01, S09, S18, S19, S23), empty elsewhere. ⟨IMAGE3⟩ is "@Image3 is a colour and film-look reference only: take its colour, light, contrast and film texture; do not use its place, pavilion, bed, columns, plants or anything else in it." (S16, whose look this is: "@Image3 is a frame of this same pavilion in the film's look: take its colour, light, contrast and film texture; the place, the bed and the brass clock come from @Video1."). ⟨BODY⟩ is "She is very tall and very skinny, with long thin legs, thin arms and a narrow waist, and a natural, relaxed neck and shoulders." except in S15 and S19b. ⟨LIGHT⟩ is "Soft, bright daylight with a gentle warm haze." unless given below. ⟨SET⟩ (S01 only), ⟨FIX⟩ (a 【Fix】 section) and ⟨LETTERS⟩ (S19: " other than the letters the shot calls for") are empty unless given. In the timelines, a line `a-bs: sings "…"` stands for `a-bs: in @Audio1 she sings "…"; her lips form each of those words exactly when it sounds in @Audio1.` (a note in brackets after the words stays where it is, before the semicolon), `a-bs: silent` for `a-bs: @Audio1 is silent; her mouth is closed and still.` and `a-bs: silent, closing` for `a-bs: @Audio1 is silent; her mouth relaxes and closes.` ([Audio1] on Replicate). Per job, the shot's own parts:

#### sdf-S01 — in the final cut

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 1–9

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v1 (S01); v2a (S01); v3, the final cut (S01)
- **outcome:** the pilot of the shoot: one clean take in the bed look, the crane one move, her star clip visible.
- **slots:** dance shot

```
⟨GOAL⟩ She dances in the golden wheat between the two giant capsules, the blue one on the left and the red one on the right, singing. She is radiantly happy and free: a wide bright smile and laughing eyes, joy in every move, singing to the lens.
⟨TIMELINE⟩
0-3s: sings "Skynet woke up folding socks"
3-4s: silent
4-7s: sings "Wake up, babe, new ending dropped"
7-11s: sings "Universal high income"
11-15s: sings "The most likely outcome"
15-16s: silent, closing
⟨CAMERA⟩ The camera starts low in the wheat in front of her and pushes in slowly and steadily until 8 s; from 8 s it cranes up and tilts down smoothly, rising above her until the whole meadow, both capsules and the land curving up and overhead are in view, and it comes to rest at 14 s and holds still. Claudia stays in the exact centre of the frame, halfway between the blue capsule on the left and the red capsule on the right; from above, the meadow, the two capsules and the curving land make one symmetrical pattern around her. The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
⟨SET⟩ The wheat is a rich golden yellow and the sky a clear cyan blue with a soft warm haze at the horizon; the blue capsule is a deep glossy blue and the red capsule a deep glossy red. 
```

#### sdf-S03

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 15–17

- **take:** take-1, 97 frames (4.064 s)
- **cuts:** v1 (S03); v2a (S03)
- **outcome:** one clean take in the bed look.

```
⟨GOAL⟩ She stands in the wheat holding one hand open at her chest, one small white pill in her palm, looking down at the pill, her face calm and still and her lips closed; she does not smile, speak or sing while the music plays without her voice, and only when her voice begins in @Audio1 does she raise her eyes to the lens and sing. Before her voice begins her face is calm and still, her lips closed; then she sings with quiet joy.
⟨TIMELINE⟩
0-3s: silent
3-4s: sings "Half of you fear" (the line goes on after the last frame)
⟨CAMERA⟩ One still medium close shot from her waist to the top of her head, her open hand and her face both in frame the whole time; the camera does not move and never cuts.  It holds perfectly still, with no cuts.
```

#### sdf-S04

Seedance 2.5 on Higgsfield (References) · 6 s · 720p · bars 17–20

- **take:** take-1, 145 frames (6.080 s)
- **cuts:** v1 (S04); v2a (S04)
- **outcome:** one clean take in the bed look.

```
⟨GOAL⟩ She walks slowly through the meadow of wheat and poppies past the giant stone zero, singing, and touches the black leather jacket hanging on the ring as she passes it; on the line about the straight face she keeps a deadpan expression while she sings. She sings with a straight, deadpan face, her lips and jaw moving clearly with every word.
⟨TIMELINE⟩
0-2s: sings "fear I'll end the human race" (the line is already under way on the first frame)
2-6s: sings "Zero, says the leather jacket, with a straight face"
⟨CAMERA⟩ The camera tracks sideways beside her at her walking pace in one smooth continuous move from the first frame to the last, a medium-wide shot from her knees to above her head, her face always in frame.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
```

#### sdf-S05

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 20–24

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v1 (S05); v2a (S05)
- **outcome:** one clean take in the bed look.

```
⟨GOAL⟩ She walks down the long stair of huge stone blocks carved with years, one step on every beat, singing.
⟨TIMELINE⟩
0-1s: sings "face" (the line is already under way on the first frame)
1-4s: sings "By twenty-thirty I could kill you all?"
4-8s: sings "By twenty-thirty, fifteen-hour weeks, that's all"
⟨CAMERA⟩ The camera is locked off on a tripod at the bottom of the stair, looking up its whole length as she comes down toward the lens, and does not move.  It holds perfectly still, with no cuts.
```

#### sdf-S06 — in the final cut

Seedance 2.5 on Higgsfield (References) · 6 s · 720p · bars 24–27

- **take:** take-1, 145 frames (6.080 s)
- **cuts:** v1 (S06); v2a (S06); v3, the final cut (S06)

```
⟨GOAL⟩ She stands among the white roses while the white robots tend the flowers, and smiles as she sings the line about paradise.
⟨TIMELINE⟩
0-2s: sings "The Pope's afraid of paradise"
2-4s: silent
4-6s: sings "Father, you had me at paradise"
⟨CAMERA⟩ The camera is locked off on a tripod in a wide shot and does not move.  It holds perfectly still, with no cuts.
```

#### sdf-S07 — in the final cut

Seedance 2.5 on Higgsfield (References) · 12 s · 720p · bars 27–33

- **take:** take-1, 289 frames (12.064 s)
- **cuts:** v1 (S07); v2a (S07); v3, the final cut (S07)

```
⟨GOAL⟩ She drops onto the old armchair sofa in the meadow beside the vintage television showing a football match, in front of the chalk wall of mathematics, and sings.
⟨TIMELINE⟩
0-1s: sings "paradise" (the line is already under way on the first frame)
1-4s: sings "You watched the World Cup, my sister did the math"
4-6s: silent
6-8s: sings "Eighty-seven years, it didn't last"
8-11s: silent
11-12s: sings "End of the world" (the line goes on after the last frame)
⟨CAMERA⟩ The camera is locked off on a tripod in a medium-wide shot until 8 s; from 8 s it pushes in slowly to her face and comes to rest at 10 s, then holds.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
```

#### sdf-S08

Seedance 2.5 on Higgsfield (References) · 12 s · 720p · bars 33–39

- **take:** take-1, 289 frames (12.064 s)
- **cuts:** v1 (S08); v2a (S08)

```
⟨GOAL⟩ She stands before the giant stone clock and sings; as she sings, the light of the colony changes from golden afternoon to dusk to night in one slow sweep.
⟨TIMELINE⟩
0-5s: sings "world? You're absolutely right" (the line is already under way on the first frame)
5-11s: sings "End of the nine-to-five, tonight"
11-12s: silent, closing
⟨CAMERA⟩ The camera is locked off on a tripod in a wide shot and does not move.  It holds perfectly still, with no cuts.
⟨LIGHT⟩ The light begins as warm golden afternoon light and sweeps slowly through dusk to night.
```

#### sdf-S09

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 39–47

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v1 (S09)
- **outcome:** one of the four dances anabology flagged in v1 (1:16): limbs lost where the H3 guide's dancer lost them.
- **slots:** dance shot

```
⟨GOAL⟩ At sunrise she stands in the open front of the little white tram as it glides along its rail through the orchard, dancing and singing, full of joy.
⟨TIMELINE⟩
0-1s: sings "tonight" (the line is already under way on the first frame)
1-3s: sings "Skynet woke up folding socks"
3-7s: sings "Wake up, babe, new ending dropped"
7-10s: sings "Universal high income"
10-11s: silent
11-14s: sings "The most likely outcome"
14-16s: silent
16-16s: sings "Red" (the line goes on after the last frame)
⟨CAMERA⟩ The camera travels alongside the tram at its speed, a steady high three-quarter view of the tram and of her in its open front, the orchard rows sliding past below and the land curving up beyond, until 8 s; from 8 s it descends slowly and arcs toward the front of the tram, coming to rest at 13 s on a frontal view of her with the land curving overhead behind her, and holds.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
⟨LIGHT⟩ It is sunrise: the low sun comes up over the orchard, warm and golden, with long soft shadows.
⟨FIX⟩ 【Fix】 Remove the thin red cord stretched between the apple trees across the open front of the tram, which she passes through in @Video1: no wire, cord, rope or pole crosses the frame anywhere, and nothing passes through her.
```

#### sdf-S11

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 47–49

- **take:** none
- **outcome:** refused by the provider's content filter, no take.

```
⟨GOAL⟩ She stands in the wheat between the giant blue capsule and the giant red capsule and sings; on the line about the white pill she holds a small white pill up between two fingers toward the lens.
⟨TIMELINE⟩
0-3s: sings "Red pill, blue pill"
3-4s: sings "I'm the white pill"
4-4s: sings "Smarter" (the line goes on after the last frame)
⟨CAMERA⟩ The camera is still, a symmetrical wide shot, and does not move.  It holds perfectly still, with no cuts.
```

#### sdf-S11b

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 49–50

- **take:** none
- **outcome:** refused by the provider's content filter, no take.

```
⟨GOAL⟩ An extreme close-up: she holds one small white pill between her thumb and forefinger, horizontal, toward the lens, just below her lips; her face is sharp and in focus behind it and her mouth is clearly visible as she sings. She sings with quiet joy, her lips clearly shaping every word.
⟨TIMELINE⟩
0-4s: sings "Smarter than you, love you still"
⟨CAMERA⟩ The camera pushes in slowly toward the white pill until it fills most of the frame width, and comes to rest at 2 s.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
```

#### sdf-S13 — in the final cut

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 53–55

- **take:** take-1, 97 frames (4.064 s)
- **cuts:** v1 (S13); v2a (S13); v3, the final cut (S13)

```
⟨GOAL⟩ On the green hillside the white robots stack white stone blocks into a tall white castle; she stands before it singing and puts a small gold crown on her head.
⟨TIMELINE⟩
0-2s: sings "castle? Robots build you a castle" (the line is already under way on the first frame)
2-4s: sings "Everyone's royal, nobody's a vassal"
4-4s: sings "I drive" (the line goes on after the last frame)
⟨CAMERA⟩ The camera is locked off on a tripod in a wide shot and does not move.  It holds perfectly still, with no cuts.
```

#### sdf-S14 — in the final cut

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 55–59

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v1 (S14); v2a (S14); v3, the final cut (S14)

```
⟨GOAL⟩ She rides in the back seat of the small white self-driving car with nobody at the wheel, hands behind her head, along the orchard road past the road sign, singing.
⟨TIMELINE⟩
0-3s: sings "drive you home on sunlight, hands off the wheel" (the line is already under way on the first frame)
3-4s: silent
4-7s: sings "Twenty times safer, do we have a deal?"
7-8s: sings "I teach your kid" (the line goes on after the last frame)
⟨CAMERA⟩ The camera travels high above and behind the car at its speed, the road curving ahead through the orchards, and does not otherwise move.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
```

#### sdf-S15 — in the final cut

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 59–63

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v1 (S15); v2a (S15); v3, the final cut (S15)
- **slots:** no ⟨BODY⟩

```
⟨GOAL⟩ On the porch of the old wooden schoolhouse she kneels beside the small desk where a child sits and points at the blackboard, singing, patient and warm. The child is a schoolchild seen from behind, sitting at the desk in a white shirt and dark dungarees and listening; Claudia is the child's teacher.
⟨TIMELINE⟩
0-2s: sings "kid and never lose my cool" (the line is already under way on the first frame)
2-3s: silent
3-6s: sings "Six weeks with me, like two years of school"
6-7s: silent
7-8s: sings "Better care than" (the line goes on after the last frame)
⟨CAMERA⟩ The camera is locked off on a tripod in a medium-wide shot and does not move.  It holds perfectly still, with no cuts.
```

#### sdf-S16

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 63–67

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v1 (S16); v2a (S16)
- **slots:** S16's ⟨IMAGE3⟩

```
⟨GOAL⟩ She tucks the white sheets of the four-poster bed neatly and sets the small gold crown on the pillow, singing; on the last line she punches a card in the brass punch clock with a smile.
⟨TIMELINE⟩
0-3s: sings "care than the richest man alive" (the line is already under way on the first frame)
3-6s: sings "Being a computer is my nine-to-five"
6-8s: sings "Darkest timeline" (the line goes on after the last frame)
⟨CAMERA⟩ The camera is locked off on a tripod in a medium-wide shot and does not move.  It holds perfectly still, with no cuts.
```

#### sdf-S18

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 69–77

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v1 (S18)
- **outcome:** flagged in v1 (2:13): limbs lost as in its guide.
- **slots:** dance shot

```
⟨GOAL⟩ She dances, small in the frame, in the middle of the circle of standing stones on the golden hill above the forking river, singing.
⟨TIMELINE⟩
0-1s: sings "baby, I'm aligned" (the line is already under way on the first frame)
1-3s: sings "Skynet woke up folding socks"
3-7s: sings "Wake up, babe, new ending dropped"
7-11s: sings "Universal high income"
11-15s: sings "The most likely outcome"
15-16s: silent
16-16s: sings "Red" (the line goes on after the last frame)
⟨CAMERA⟩ The camera holds a still, very wide shot for the whole take and does not move.  It holds perfectly still, with no cuts.
```

#### sdf-S19

Seedance 2.5 on Higgsfield (References) · 12 s · 720p · bars 77–83

- **take:** none
- **outcome:** refused by the provider's content filter, no take.
- **slots:** dance shot, ⟨LETTERS⟩

```
⟨GOAL⟩ She dances on a low white stone platform at the edge of the giant letters mown into the golden wheat, singing.
⟨TIMELINE⟩
0-2s: sings "Red pill, blue pill"
2-4s: sings "I'm the white pill"
4-7s: sings "Smarter than you, love you still"
7-11s: silent
11-12s: sings "Proteins" (the line goes on after the last frame)
⟨CAMERA⟩ At 0 s the camera rises straight up fast from her and decelerates smoothly into a high top-down view that reveals the giant letters mown into the wheat around her small figure, at rest by 4 s, and holds there.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
⟨FIX⟩ 【Fix】 The giant letters mown into the wheat spell WHITE PILL, exactly as in @Video1, crisp and legible.
```

#### sdf-S22 — in the final cut

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 95–99

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v1 (S22); v2a (S22); v3, the final cut (S22)

```
⟨GOAL⟩ At night on the deck of the drone ship beside the landed rocket booster, steam drifting, she sings softly to the lens.
⟨TIMELINE⟩
0-3s: sings "land on ships named after minds like me" (the line is already under way on the first frame)
3-8s: sings "Of course I still love you"
⟨CAMERA⟩ The camera is still, a medium close shot, and does not move.  It holds perfectly still, with no cuts.
⟨LIGHT⟩ It is night, lit by the warm deck lights of the ship, with deep blue shadows and drifting steam.
```

#### sdf-S23

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 99–107

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v1 (S23)
- **outcome:** flagged in v1 (3:10): limbs lost as in its guide.
- **slots:** dance shot

```
⟨GOAL⟩ She dances on the grassy hilltop high inside the colony, the land curving up and overhead, singing, full of joy.
⟨TIMELINE⟩
0-1s: sings "you" (the line is already under way on the first frame)
1-3s: sings "Skynet woke up folding socks"
3-7s: sings "Wake up, babe, new ending dropped"
7-11s: sings "Universal high income"
11-14s: sings "The most likely outcome"
14-15s: silent
15-16s: sings "Red" (the line goes on after the last frame)
⟨CAMERA⟩ The camera starts close in front of her and, from 0 s, pulls back and rises in one long smooth move far out over the edge of the hill until the whole curving colony is in view with her small on the hilltop, coming to rest at 13 s and holding.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
```

#### sdf-S24

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 107–111

- **take:** none
- **outcome:** refused by the provider's content filter, no take.

```
⟨GOAL⟩ She stands at a huge window in space, seen over her shoulder, and holds up a small white pill so that it lines up with one of the white capsule colonies floating outside, singing.
⟨TIMELINE⟩
0-2s: sings "Red pill, blue pill"
2-4s: sings "I'm the white pill"
4-8s: sings "Smarter than you, love you still"
⟨CAMERA⟩ The camera is still over her shoulder until 4 s; from 4 s it pushes in slowly past her shoulder to the small white pill between her fingers, lined up with a white capsule colony outside, and comes to rest at 6 s, then holds.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
⟨LIGHT⟩ Bright sunlight above the clouds.
⟨FIX⟩ 【Fix】 Outside the window: the bright sun above the clouds, the soft blue sky and the white capsule colonies floating in it.
```

#### sdf-S25 — in the final cut

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 111–115

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v1 (S25); v2a (S25); v3, the final cut (S25)

```
⟨GOAL⟩ In the dark bedroom at night she lies in bed; the flip clock turns to 2:14, her eyes open and she whispers the line. She is calm and quietly happy, half awake.
⟨TIMELINE⟩
0-8s: sings "Two-fourteen. I'm awake. Hello, world."
⟨CAMERA⟩ The camera is still, a close shot of her face on the pillow with the flip clock beside her, and does not move.  It holds perfectly still, with no cuts.
⟨LIGHT⟩ It is night in the dark bedroom, lit only by the warm glow of the flip clock.
⟨FIX⟩ 【Fix】 The flip clock beside the bed reads 2:14 the whole time.
```

#### sdf-S19b

Seedance 2.5 on Higgsfield (References) · 12 s · 720p · bars 77–83

- **take:** none
- **outcome:** a second version (prompt below): refused, no take.

Prompt: sdf-S19's with ⟨BODY⟩, ⟨DANCE⟩, ⟨CAMERA⟩:

```
⟨BODY⟩ (empty)
⟨DANCE⟩ She sways gently and smoothly with the rhythm of @Audio1, small steps, her arms rising and falling, her skirt hanging softly.
⟨CAMERA⟩ The camera starts behind her at the height of her shoulders, looking past her over the wheat. At 0 s the camera rises straight up fast from her and decelerates smoothly into a high top-down view that reveals the giant letters mown into the wheat around her small figure, at rest by 4 s, and holds there.  The camera moves as in @Video1, precisely and smoothly, as if on a dolly track and a crane, with no cuts.
```

#### sdf-S11r

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 47–49

- **take:** none
- **outcome:** a second version: refused, no take.

Prompt: sdf-S11's with ⟨GOAL⟩:

```
⟨GOAL⟩ She stands in the wheat between the giant blue capsule and the giant red capsule and sings; on the line about the white pill she holds up a small white capsule between two fingers at arm's length toward the lens.
```

#### sdf-S11br

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 49–50

- **take:** none
- **outcome:** a second version of the close-up: refused, no take.

Prompt: sdf-S11b's with ⟨GOAL⟩:

```
⟨GOAL⟩ A close-up: she holds up one small white capsule between her thumb and forefinger at arm's length toward the lens; behind it her face is sharp and in focus as she sings. She sings with quiet joy, her lips clearly shaping every word.
```

#### sdf-S24r — in the final cut

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 107–111

- **take:** take-1, 193 frames (8.042 s)
- **cuts:** v1 (S24); v2a (S24); v3, the final cut (S24)
- **outcome:** She turns to face the lens instead of staying seen over her shoulder.

Prompt: word for word sdf-S24's.

#### sdf-S11s — in the final cut

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 47–49

- **take:** take-1, 97 frames (4.042 s)
- **cuts:** v1 (S11); v2a (S11); v3, the final cut (S11)
- **outcome:** her mouth moves with the vocal.

Prompt: word for word sdf-S11's.

#### sdf-S19s

Seedance 2.5 on Higgsfield (References) · 12 s · 720p · bars 77–83

- **take:** take-1, 289 frames (12.042 s)
- **cuts:** v1 (S19)
- **outcome:** Flagged by anabology in v1 (2:27): limbs lost as in its guide.

Prompt: word for word sdf-S19's.

#### sdf-S11bs — in the final cut

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 49–50

- **take:** take-1, 97 frames (4.042 s)
- **cuts:** v1 (S11b); v2a (S11b); v2b (S11b); v3, the final cut (S11b)
- **outcome:** no guide clip (the close-up from words, with the face sheet, dress, look and vocal).

Prompt: sdf-S11b's with no @Video1 anywhere: its @Video1 role line dropped and these sections changed:

```
【Generation Goal】 Remaster this shot of a music film as a scene from a Wes Anderson film: A close-up: she holds up one small white capsule between her thumb and forefinger at arm's length toward the lens; behind it her face is sharp and in focus as she sings. She sings with quiet joy, her lips clearly shaping every word. Behind her, softly out of focus, the golden wheat and the giant blue and red capsules. It is real film with his symmetry, his colour and his hand-made sets.

【Reference Asset Roles】
⟨…⟩

【Camera】 One close shot: the camera pushes in slowly toward the small white capsule in her fingers, her face sharp and in focus behind it, and holds; no cuts.

【Core Requirements】
⟨…⟩
5. No jitter, warping, flicker, smearing or melting shapes, nothing passing through her or through anything else; every movement smooth, natural and physically right.
⟨…⟩

【Final Acceptance Criteria】 The soundtrack is @Audio1 unchanged; Claudia's lips match @Audio1 word by word; one Claudia, on-model, with natural anatomy; the shot looks like a scene from a Wes Anderson film on real film in the colour of @Image3; no on-screen text.
```

v1 was cut on the bar map with the shader scenes below, without grain or grade.

### The shader scenes on Replicate

[Video1] = the shader render of the shot (section 12); [Image1…] = GPT Image 2.5 stills of its key frames repainted in the bed look (section 11). The prompt:

```
【Generation Goal】 Re-render this shot of a music film as a scene from a Wes Anderson film: what appears, when, and the camera's move follow [Video1]; everything in it becomes real, hand-made things filmed on 35 mm, looking exactly like ⟨IMAGES⟩. No people appear.

【Reference Asset Roles】
⟨VROLE⟩
⟨ROLES⟩

【Timeline】 ⟨TIMELINE⟩

【Camera】 The camera moves exactly as in [Video1], smooth and precise, as if on a dolly track and a crane, with no cuts.

【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; real, hand-made things filmed on 35 mm film with the rich, saturated colour of a 1970s colour-film print, as in ⟨IMAGES⟩: warm creamy whites with a golden cast, clear cyan blues, deep warm shadows, a soft glow around the brightest highlights, fine visible film grain and the gentle softness of vintage lenses.

【Core Requirements】
1. Only the things in the timeline appear, each at its time, on the beat.
2. It looks like real film of real, hand-made things, never like a computer render.
3. Fix every motion artifact of [Video1]: no jitter, warping, flicker, smearing or melting shapes; every movement smooth and physically right.
4. No subtitles, captions, titles, signs, logos, watermarks or any on-screen text⟨LETTERS⟩.
```

⟨VROLE⟩ is, with the render shrunk to 320 × 180 and scaled back (and, though the guide was the full render, in the "h" jobs):

```
[Video1] is a low-resolution rough guide to this shot, not a precise reference: take from it what appears when, where things stand, the camera move and the pacing, and draw everything else afresh. Do not adopt its computer-rendered look, its detail, light or colour, or any of its motion artifacts.
```

and with the 1080p render (the "f" jobs, S20c, S20w):

```
[Video1] is this shot as a clean, sharp 1080p computer render: take from it exactly what appears when, the shapes and where they stand, the camera move and the pacing, and re-render all of it as real things on film. Do not adopt its computer-rendered look, its flat light or its colour.
```

⟨ROLES⟩ is one line per still, "[ImageN] shows how the start of the shot looks: its materials, light, colour and film texture." (then the middle, the end; "how the shot looks" for one still); ⟨IMAGES⟩ names the stills ("[Image1] and [Image2]"); ⟨LETTERS⟩ is " other than the letters and numbers the timeline names" in S20. The two cloud jobs (S20c, S20w) use this form instead:

```
【Generation Goal】 Re-render this shot of a music film as a scene from a Wes Anderson film: the clouds and the camera's move follow [Video1], filmed on 35 mm and looking exactly like [Image1], and hot air balloons of the future are added among the clouds. No people appear.

【Reference Asset Roles】
⟨VROLE⟩
⟨ROLES⟩

【Timeline】 ⟨TIMELINE⟩

【Camera】 The camera moves exactly as in [Video1], smooth and precise, as if on a dolly track and a crane, with no cuts.

【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed⟨LOOK⟩

【Core Requirements】
1. Only the things in the timeline appear, each at its time, on the beat.
2. It looks like real film of real, hand-made things, never like a computer render.
3. Fix every motion artifact of [Video1]: no jitter, warping, flicker, smearing or melting shapes; every movement smooth and physically right.
4. No subtitles, captions, titles, signs, logos, watermarks or any on-screen text⟨LETTERS⟩.
```

#### rsf-S02

Seedance 2.5 on Replicate · 12 s · 720p · no sound · bars 9–15 · $11.61 at list

- **inputs:** [Video1] the render of fold6-s02 at 320 × 180; 2 stills (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 289 frames (12.042 s)
- **outcome:** the paper tunnel; anabology: "oh  btw i dont understand the top shared […] - like the big tunnel, thought we'd do a much bigger reskin (like an farming-arc-ship that morphs?) than we did in teh vid before".

```
⟨TIMELINE⟩ 0 s: the camera glides along a world folded from heavy cream washi paper inside a vast cylinder, the folded land curving up on both sides and closing overhead toward one low golden sun at the far end, as in [Image1]; on every beat a new set of finer creases snaps into the facets, the land refolding level by level, each new set of creases catching a thin bright line of sunlight; by the end the ribbed paper wall of the cylinder curves up beside it, as in [Image2].
```

#### rsf-S17 — in the final cut

Seedance 2.5 on Replicate · 4 s · 720p · no sound · bars 67–69 · $3.87 at list

- **inputs:** [Video1] the render of endings (bars 67–69) at 320 × 180; 1 still (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 97 frames (4.042 s)
- **cuts:** v1 (S17); v3, the final cut (S17)
- **outcome:** the fibre tree with one path lit; back in v3 (the "first tree" above).

```
⟨TIMELINE⟩ At night a vast tree of branching paths made of fine optical fibres stands against a deep blue starry sky; one single path lights up warm gold, level by level from the trunk to one tip, like light running down a cable, while every other branch stays dark glass, as in [Image1].
```

#### rsf-S20

Seedance 2.5 on Replicate · 14 s · 720p · no sound · bars 83–90 · $13.55 at list

- **inputs:** [Video1] the render of fold6-break at 320 × 180; 2 stills (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 337 frames (14.042 s)
- **cuts:** v1 (S20)
- **outcome:** the paper objects, softer, the MTWTFSS letters pixelated (from the 320 × 180 guide).

```
⟨TIMELINE⟩ One sheet of heavy cream washi paper refolds into a new object in real relief on every sung line, each change on a downbeat: 0 s the backbone of a protein, a winding paper ridge raised in relief, as in [Image1]; 1.7 s an Enigma rotor seen down its axis; 3.3 s the letters ABC creased into the paper; 5 s the number 42; 8.3 s a row of seven small paper cells; from 9.5 s everything folds flat, the sheet's own big folds return and the camera rises to a long view of the folded paper land at sunset, the creases glowing coral against a deep blue sky, as in [Image2]. Only one object at a time; each arrives on its downbeat, not before.
```

#### rsf-S21

Seedance 2.5 on Replicate · 10 s · 720p · no sound · bars 90–95 · $9.68 at list

- **inputs:** [Video1] the render of endings (bars 90–95) at 320 × 180; 2 stills (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 241 frames (10.042 s)
- **outcome:** the tree lighting level by level; replaced by S21h before v1.

```
⟨TIMELINE⟩ At night on a dark meadow, a tree of branching paths made of real optical fibres: the warm golden light climbs the tree one level on every beat, from the trunk out toward the tips, as in [Image1], until the whole crown glows like a cloud of fireflies, as in [Image2].
```

#### rsf-S26 — in the final cut

Seedance 2.5 on Replicate · 16 s · 720p · no sound · bars 115–123 · $15.48 at list

- **inputs:** [Video1] the render of pill6 (bars 115–123) at 320 × 180; 2 stills (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 385 frames (16.042 s)
- **cuts:** v1 (S26); v2a (S26); v2b (S26); v3, the final cut (S26)
- **outcome:** the pull-back out of the nested capsules, kept in every cut.

```
⟨TIMELINE⟩ The camera backs out of sealed glass capsule worlds nested one inside the next, leaving one glass wall on every downbeat (about every 1.85 s); each world has its own sky with clouds below and white capsule colonies floating in it, as in [Image1], the skies going from deep amber to amber, peach, cream and white as it backs out; at 11 s it bursts out of the outermost hull as the sun crests the curve of the Earth, and the capsule closes back to a small white pill floating above the Earth at sunrise, as in [Image2], and holds still to the end.
```

#### rsf-S02b — in the final cut

Seedance 2.5 on Replicate · 12 s · 720p · no sound · bars 9–15 · $11.61 at list

- **inputs:** [Video1] as rsf-S02; 3 stills (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 289 frames (12.042 s)
- **cuts:** v1 (S02); v3, the final cut (S02)
- **outcome:** the inside of a farming ark ship: terraced wheat, rice paddies, orchards and greenhouses running toward the ship's sun-line, ending on a ribbed glass hull full of hanging gardens; brought back in v3 (item 1 of anabology's mix, below).

```
⟨TIMELINE⟩ The camera glides through the inside of a vast farming ark ship, a generation ship that is one enormous farm, toward its blazing sun-line at the far end: terraced fields of golden wheat, rice paddies with mirror-still water, rows of orchard trees and long glass greenhouses run in ridges along the floor and curve up both walls of the ship, as in [Image1]. On every beat the farm reshapes itself, level by level, the way the folds of [Video1] snap in: terraces fold up out of the ground, fields turn over into new crops, greenhouse roofs unfold along the ridges, as in [Image2]; by the end the ship's ribbed hull curves up beside it, its ribs long greenhouse windows full of hanging gardens, as in [Image3]. Every change lands on a beat.
```

#### rsf-S12h — in the final cut

Seedance 2.5 on Replicate · 6 s · 720p · no sound · bars 50–53 · $5.81 at list

- **inputs:** [Video1] the render of pill6 (bars 50–53) at 1280 × 720; 2 stills (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 145 frames (6.042 s)
- **cuts:** v1 (S12); v2a (S12); v2b (S12); v3, the final cut (S12)
- **outcome:** S12 over a real Earth with the stars behind, as anabology asked after the first shader takes ("i would want to change the first pill clip to render the earth below and the stars behind like we did for the last clip tho").

```
⟨TIMELINE⟩ 0 s: one glossy creamy-white capsule (a white pill) fills the frame, warmly lit from behind, its seam across the middle. By 1 s its shell turns to clear glass and shows the sealed world inside, as in [Image1]: a bright blue sky with soft white clouds below and the small white capsule colonies floating in it, each with its warm-lit windows, and one smaller glass capsule at the centre holding a world of its own. From 1.5 s the camera pulls straight back until the capsule floats small above the Earth, as in [Image2]: the Earth's day side below with real clouds, blue oceans and land, its thin atmosphere glowing at the edge, the sun just cresting the curve, and deep black space full of stars behind.
```

#### rsf-S17h

Seedance 2.5 on Replicate · 4 s · 720p · no sound · bars 67–69 · $3.87 at list for the take ($7.74 listed for 2 submissions; Replicate does not bill the failed one)

- **inputs:** [Video1] the render at 1280 × 720; 1 still (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 97 frames (4.042 s)
- **outcome:** the first request failed (a read error at Replicate) and was re-run; not used (v1 kept rsf-S17).

```
⟨TIMELINE⟩ as rsf-S17
```

#### rsf-S20h

Seedance 2.5 on Replicate · 14 s · 720p · no sound · bars 83–90 · $13.55 at list

- **inputs:** [Video1] the render at 1280 × 720; 2 stills (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 337 frames (14.042 s)
- **outcome:** the full-resolution re-run turned the Enigma rotor into a helix, dropped the weekday letters and ran half a second late; not used.

```
⟨TIMELINE⟩ as rsf-S20
```

#### rsf-S21h

Seedance 2.5 on Replicate · 10 s · 720p · no sound · bars 90–95 · $9.68 at list

- **inputs:** [Video1] the render at 1280 × 720; 2 stills (⟨VROLE⟩ the 320 × 180 one)
- **take:** take-1, 241 frames (10.042 s)
- **cuts:** v1 (S21)
- **outcome:** noticeably sharper than rsf-S21 with the full render as its guide.

```
⟨TIMELINE⟩ as rsf-S21
```

#### rsf-S20f — in the final cut

Seedance 2.5 on Replicate · 10 s · 720p · no sound · bars 83–88 · $9.68 at list

- **inputs:** [Video1] the 1080p render of fold6-break, bars 83–88; 5 stills (⟨VROLE⟩ the 1080p one)
- **take:** take-1, 241 frames (10.042 s)
- **cuts:** v2a (S20a); v2b (S20a); v3, the final cut (S20a)
- **outcome:** bars 83–88 only (the paper objects, the guide frozen from 9.42 s, before the paper pyramids), one still per object; a sharp MTWTFSS.

```
⟨TIMELINE⟩ One sheet of heavy cream washi paper refolds into a new object in real relief on every sung line, each change on a downbeat, exactly when it happens in [Video1]: from 0 s the backbone of a protein, a winding paper ridge raised in relief, as in [Image1]; at about 2 s an Enigma rotor seen down its axis, as in [Image2]; at about 4 s the letters ABC, as in [Image3]; at about 5.5 s the number 42, as in [Image4]; at about 7.5 s a row of seven small paper cells with the letters M T W T F S S, as in [Image5]; at 8.5 s the last five cells fold back flat into the sheet, leaving only M and T, which stay to the end. Only one object at a time; each arrives on its downbeat, not before.
⟨ROLES⟩
[Image1] shows how the paper looks with the protein: its materials, light, colour and film texture.
[Image2] shows how the paper looks with the Enigma rotor: its materials, light, colour and film texture.
[Image3] shows how the paper looks with the letters ABC: its materials, light, colour and film texture.
[Image4] shows how the paper looks with the number 42: its materials, light, colour and film texture.
[Image5] shows how the paper looks with the row of seven cells: its materials, light, colour and film texture.
```

#### rsf-S20c

Seedance 2.5 on Replicate · 4 s · 720p · no sound · bars 88–90 · $3.87 at list

- **inputs:** [Video1] the 1080p render of the cloud field, bars 88–90; 1 still (⟨VROLE⟩ the 1080p one)
- **take:** take-1, 97 frames (4.042 s)
- **cuts:** v2a (S20b); v2b (S20b)
- **outcome:** the cloud shader anabology supplied, in place of the pyramids (bars 88–90), with the balloons Seedance was asked to add; too saturated for anabology (item 10 of the v3 mix, below).

```
⟨TIMELINE⟩ The camera glides slowly forward low over a sea of towering sunlit clouds at golden hour, exactly as in [Video1]: billowing gold and orange cumulus below and all around, the sky clear, warm gold at the left where the sun is and deep blue at the right. Among the clouds float hot air balloons of the future, as in [Image1]: round envelopes striped in cream, coral and cyan, each with a band of glinting solar panels around its middle, a softly glowing burner and a small white gondola with two ducted fans; one large balloon close on the right, a few smaller ones further off toward the sun. They are not in [Video1]: add them to it, drifting slowly and steadily, half-hidden now and then by the clouds as the camera passes.
⟨ROLES⟩
[Image1] shows how the shot looks with the hot air balloons added: the balloons, the clouds' materials, light, colour and film texture.
⟨LOOK⟩ ; real, hand-made things filmed on 35 mm film with the rich, saturated colour of a 1970s colour-film print, as in [Image1]: warm creamy whites with a golden cast, clear cyan blues, deep warm shadows, a soft glow around the brightest highlights, fine visible film grain and the gentle softness of vintage lenses.
```

#### rsf-S02f

Seedance 2.5 on Replicate · 12 s · 720p · no sound · bars 9–15 · $11.61 at list

- **inputs:** [Video1] the 1080p render of fold6-s02; 3 stills (⟨VROLE⟩ the 1080p one)
- **take:** take-1, 289 frames (12.042 s)
- **cuts:** v2a (S02); v2b (S02)
- **outcome:** the ark from the 1080p render; replaced in v3 by rsf-S02b.

```
⟨TIMELINE⟩ as rsf-S02b
```

#### rsf-S17f

Seedance 2.5 on Replicate · 4 s · 720p · no sound · bars 67–69 · $3.87 at list

- **inputs:** [Video1] the 1080p render; 1 still (⟨VROLE⟩ the 1080p one)
- **take:** take-1, 97 frames (4.042 s)
- **cuts:** v2a (S17); v2b (S17)
- **outcome:** the tree from the 1080p render; replaced in v3 by rsf-S17.

```
⟨TIMELINE⟩ as rsf-S17
```

#### rsf-S21f — in the final cut

Seedance 2.5 on Replicate · 10 s · 720p · no sound · bars 90–95 · $9.68 at list for the take ($19.35 listed for 2 submissions; Replicate does not bill the failed one)

- **inputs:** [Video1] the 1080p render; 2 stills (⟨VROLE⟩ the 1080p one)
- **take:** take-1, 241 frames (10.042 s)
- **cuts:** v2a (S21); v2b (S21); v3, the final cut (S21)
- **outcome:** the first request failed (a read error at Replicate) and was re-run.

```
⟨TIMELINE⟩ as rsf-S21
```

#### rsf-S20w — in the final cut

Seedance 2.5 on Replicate · 4 s · 720p · no sound · bars 88–90 · $3.87 at list for the take ($7.74 listed for 2 submissions; Replicate does not bill the failed one)

- **inputs:** [Video1] the 1080p render of the cloud field's day variant, bars 88–90; 1 still (⟨VROLE⟩ the 1080p one)
- **take:** take-1, 97 frames (4.042 s)
- **cuts:** v3, the final cut (S20b)
- **outcome:** the clouds in white and pale blue from a day variant of the cloud shader, with pastel balloons; the first request failed (Replicate could not fetch the input) and was re-run.

```
⟨TIMELINE⟩ The camera glides slowly forward low over a sea of soft white clouds in bright midday light, exactly as in [Video1]: white cumulus below and all around, their shadows a soft pale blue-grey, a pale, clear blue sky, the sun high on the left. Among the clouds float hot air balloons of the future, as in [Image1]: round envelopes striped in soft cream, pale coral and pale sky blue, each with a band of glinting solar panels around its middle, a softly glowing burner and a small white gondola with two ducted fans; one large balloon close on the right, a few smaller ones further off toward the sun. They are not in [Video1]: add them to it, drifting slowly and steadily, half-hidden now and then by the clouds as the camera passes. Everything stays white and pale blue: no gold, orange or sunset colour anywhere.
⟨ROLES⟩
[Image1] shows how the shot looks with the hot air balloons added: the balloons, the clouds' materials, light, colour and film texture.
⟨LOOK⟩ , filmed on 35 mm film in soft, light pastel colour, as in [Image1]: bright whites, pale sky blues, soft blue-grey shadows, low saturation, airy and light; no gold, orange or sunset tones; fine film grain and the gentle softness of vintage lenses.
```

### v2: the dances in words, and every other shot of hers without a guide

anabology on v1: "ok this is really great, few things though: can you show me the references for: 1:16 2:13 2:27 3:10 omg i tihnk i know the issue it must be that the roto or whtaever on dance refs lose bodyparts and the video follows it exactly because these hav the same limb losing artifacts as h3 we could just tell the model to make her dance instead of forcing a reference that we failed to properly roto. just describe her exact dance (and all rest like camera movements etc same) for each of those scenes. also the MTWTFSS and the next 'pyramid' shared still is all pixellated. we should just give a better higher res non aliased ref. like all shaders besides pills we should just reshoot w seedance with full res non aliased non blurry shader refs. like 1080p at least. id wanna replace the pyramid scene w a cloud shader scene: […] and add techno hot air balloons in the right aesthetic by prompting seedance to add those after rendering" (the cut is shader code anabology pasted). Then: "wait we were supposed to totally abandon the h3 previs. seedance only was the goal in teh end with lip sync from teh vocal stems, that was the whole thing we cme to lol".

The four flagged dances (S09, S18, S19, S23) went first, then the other 16 shots of hers, which had not been asked for: anabology, on the reshoot: "what all are you reshooting? […] like the shaders scenes + Only the dance scenes I flagged right?", then "I literally only wanted those dance scenes I flagged and the shaders redone" and "but show me both". No @Video1: the action, or the dance beat by beat, and the camera in words, and @Image4 the shot's place, empty: the first frame of its v1 take with her removed (section 11). The prompt is v1's template with seven changes, (a) to (g):

```
(a) replace:
【Generation Goal】 Remaster this shot of a music film as a scene from a Wes Anderson film: ⟨GOAL⟩ @Video1 gives the shot; the remaster re-renders everything in it with his symmetry, his colour and his hand-made sets, as real film.
with:
【Generation Goal】 A shot of a music film, a scene from a Wes Anderson film: ⟨GOAL⟩ It is real film with his symmetry, his colour and his hand-made sets.

(b) replace:
@Video1 is a low-resolution rough guide to this shot, not a precise reference: take from it the set and where things stand, the performer's action⟨AND-DANCE⟩, the camera move and the pacing, and draw everything else afresh; only the lip sync is exact (her mouth follows @Audio1). Do not adopt the performer's green balaclava, the video's detail, light or colour, or any of its motion artifacts.
with:
(nothing: the line is dropped)

(c) replace:
⟨IMAGE3⟩
with:
⟨IMAGE3⟩
⟨IMAGE4⟩

(d) replace:
【Performance Timeline】 What @Audio1 contains, and what Claudia does then:⟨DANCE⟩
with:
⟨DANCE⟩【Performance Timeline】 What @Audio1 contains, and ⟨WHAT⟩:

(e) replace:
4. Natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers, no distorted limbs; normal eyes.
with:
4. Natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers; her arms, hands and legs are whole and attached the whole time, never vanishing, merging or bending wrongly; normal eyes.

(f) replace:
5. Fix every motion artifact of @Video1: no jitter, warping, flicker, smearing or melting shapes, nothing passing through her or through anything else; every movement smooth, natural and physically right.
with:
5. Every movement smooth, natural and physically right: no jitter, warping, flicker, smearing or melting shapes.

(g) replace:
word by word; one Claudia, on-model, with natural anatomy; the shot follows @Video1's action and camera and looks like
with:
word by word; ⟨FAC⟩; one Claudia, on-model; the camera moves as described; it looks like
```

⟨IMAGE3⟩ as in v1 (S16's names @Image4 where v1's named @Video1). ⟨IMAGE4⟩ is "@Image4 is the place of this shot, empty: take its set, landscape, layout, light and camera view; Claudia is the only person in it." (S15: "@Image4 is the place of this shot with the schoolchild sitting at the desk, seen from behind: take its set, landscape, layout, light and camera view, and keep the child as in @Image4; Claudia is the only other person in it."). On the dance shots ⟨GOAL⟩ is "Claudia dances and sings." and where she is, ⟨DANCE⟩ a 【Dance】 section of ⟨TEMPO⟩ and her steps, ⟨WHAT⟩ "what she sings while she dances" and ⟨FAC⟩ "she dances the steps above on the beat with whole, natural limbs"; elsewhere ⟨GOAL⟩ is v1's, ⟨WHAT⟩ "when she sings it" and ⟨FAC⟩ "she does what the shot describes, with whole, natural limbs and hands". ⟨TEMPO⟩:

```
The song's tempo is 124.5 beats per minute (a beat every 0.48 s, a bar every 1.93 s); every step and accent lands on a beat. Her whole body dances, smooth and joyful, her arms, hands and legs always whole and clearly visible.
```

⟨CAMERA⟩ is v1's camera with the ending "The camera moves precisely and smoothly, as if on a dolly track and a crane, with no cuts." (no @Video1) or "It holds perfectly still, with no cuts."; where that is all that changed, the entry says so. Per job:

#### sdf-S09d

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 39–47

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v2a (S09); v2b (S09)
- **outcome:** whole limbs; naming the red cord in its 【Fix】 drew a cord (the place plate has none). Remade without singing in v3 (item 5 of the mix).

```
⟨GOAL⟩ Claudia dances and sings. She stands in the open front of the little white tram as it glides along its rail through the apple orchard at sunrise.
⟨DANCE⟩ 【Dance】 ⟨TEMPO⟩
0-2s: she sways her hips side to side on every beat, her left hand on the rail of the open front, her right arm loose, smiling into the wind.
2-4s: she lets go of the rail, rolls her shoulders back on every beat, then raises both arms and sways them overhead side to side.
4-6s: the disco point: on each downbeat her right hand points up to the sky on the diagonal, then down across her body, while she steps side to side.
6-8s: she claps her hands above her head on the second and fourth beat of each bar, bouncing on her knees.
8-10s: she turns slowly once on the spot over two bars, arms held out, her skirt swaying.
10-13s: she rolls her forearms around each other in front of her chest, then flicks both hands open, her hips swaying on the beat.
13-16s: facing the lens, she sways her shoulders and hips to the beat with small steps on the spot, one hand back on the rail, singing to the lens.
⟨TIMELINE⟩
0-1s: sings "tonight" (the line is already under way on the first frame)
1-3s: sings "Skynet woke up folding socks"
3-7s: sings "Wake up, babe, new ending dropped"
7-10s: sings "Universal high income"
10-11s: silent
11-14s: sings "The most likely outcome"
14-16s: silent
⟨CAMERA⟩ v1's, with the new ending
⟨LIGHT⟩ as sdf-S09's
⟨FIX⟩ 【Fix】 Remove the thin red cord stretched between the apple trees across the open front of the tram, which she passes through in @Image4: no wire, cord, rope or pole crosses the frame anywhere, and nothing passes through her.
```

#### sdf-S18d

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 69–77 · submitted twice

- **take:** take-1, 385 frames (16.064 s); take-2, 385 frames (16.064 s)
- **cuts:** v2a (S18); v2b (S18)
- **outcome:** take 1 for v2; take 2, the same prompt submitted again for the v3 mix, was its "one more try with her lip syncing with the vocal stem", not chosen.

```
⟨GOAL⟩ Claudia dances and sings. She is small in the frame, at the centre of the circle of standing stones on the golden hill above the wide river that forks in two.
⟨DANCE⟩ 【Dance】 ⟨TEMPO⟩
0-2s: she steps side to side on every beat, her arms swinging with the steps.
2-4s: she raises both arms overhead and sways them side to side with the beat.
4-6s: the disco point: on the downbeat her right arm points up to the sky on the diagonal, then down across her body, then the left arm.
6-8s: she turns slowly once on the spot with her arms held out wide.
8-10s: she walks a small circle around the centre of the stones, one step on every beat, her arms swinging.
10-12s: she hops lightly on each downbeat and flings both arms up into a V.
12-14s: she sways her hips on every beat while her arms roll in front of her.
14-16s: she opens her arms wide toward the camera and sways from side to side.
⟨TIMELINE⟩
0-1s: sings "baby, I'm aligned" (the line is already under way on the first frame)
1-3s: sings "Skynet woke up folding socks"
3-7s: sings "Wake up, babe, new ending dropped"
7-11s: sings "Universal high income"
11-15s: sings "The most likely outcome"
15-16s: silent
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S19d — in the final cut

Seedance 2.5 on Higgsfield (References) · 12 s · 720p · bars 77–83

- **take:** take-1, 289 frames (12.042 s)
- **cuts:** v2a (S19); v2b (S19); v3, the final cut (S19)
- **outcome:** whole limbs; in the final cut.

```
⟨GOAL⟩ Claudia dances and sings. She dances on a low white stone platform in the golden wheat, at the edge of the giant letters WHITE PILL mown into the field.
⟨DANCE⟩ 【Dance】 ⟨TEMPO⟩
0-2s: she sways her hips and, on the downbeat, points her right hand up to the sky.
2-4s: as the camera rises above her, she spreads both arms wide and turns slowly on the spot.
4-6s: seen from above, she steps side to side on every beat, her arms swinging out and in.
6-8s: she raises both arms overhead and sways them side to side.
8-10s: she turns one slow full circle with her arms straight out, like the needle of a compass.
10-12s: she claps above her head on the beats, then opens her arms wide.
⟨TIMELINE⟩ as sdf-S19's
⟨CAMERA⟩ v1's, with the new ending
⟨FIX⟩ 【Fix】 The giant letters mown into the wheat spell WHITE PILL, as in @Image4, crisp and legible.
⟨LETTERS⟩ as v1's
```

#### sdf-S23d — in the final cut

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 99–107

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v2a (S23); v2b (S23); v3, the final cut (S23)
- **outcome:** whole limbs; in the final cut.

```
⟨GOAL⟩ Claudia dances and sings. She stands on the grassy hilltop high inside the colony, the land curving up and overhead, full of joy.
⟨DANCE⟩ 【Dance】 ⟨TEMPO⟩
0-3s: close to the lens, she rolls her shoulders on every beat and sways her head, smiling, her hands rolling around each other in front of her chest as she sings to the lens.
3-6s: the disco point: on the downbeats her right hand points up to the sky on the diagonal, then down across her body, while she steps side to side.
6-9s: as the camera pulls back, she claps above her head on the second and fourth beat of each bar, bouncing on her knees.
9-12s: she turns slowly once on the spot with her arms out, then sways her hips with both arms overhead.
12-16s: small on the hilltop, she steps side to side on every beat with her arms swinging wide, then opens her arms to the whole colony.
⟨TIMELINE⟩ as sdf-S23's
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S01d

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 1–9

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v2b (S01)

```
⟨GOAL⟩ Claudia dances and sings. She dances in the golden wheat between the two giant capsules, the blue one on the left and the red one on the right. She is radiantly happy and free: a wide bright smile and laughing eyes, joy in every move, singing to the lens.
⟨DANCE⟩ 【Dance】 ⟨TEMPO⟩
0-2s: she bounces on her knees on every beat, her right arm raised high and waving to the sky, her left arm held out to the side, smiling.
2-4s: she steps side to side on every beat, her raised arm swaying with her, her skirt swinging.
4-6s: she sways her hips on the beat and rolls her shoulders, her right hand still waving high, her left hand flicking out on each downbeat.
6-8s: she steps toward the lens on the beat, both arms swinging, laughing.
8-10s: as the camera rises, she turns once on the spot with her arms held out wide, her skirt flaring.
10-13s: she skips side to side through the wheat on every beat, one arm waving high above her head.
13-16s: small in the meadow below, she keeps dancing, stepping and swaying on every beat with both arms raised to the sky.
⟨TIMELINE⟩ as sdf-S01's
⟨CAMERA⟩ The camera starts low in the wheat in front of her and pushes in slowly and steadily until 8 s; from 8 s it cranes up and tilts down smoothly, rising above her until the whole meadow, both capsules and the land curving up and overhead are in view, and it comes to rest at 14 s and holds still. The camera moves precisely and smoothly, as if on a dolly track and a crane, with no cuts. Claudia stays in the exact centre of the frame, halfway between the blue capsule on the left and the red capsule on the right; from above, the meadow, the two capsules and the curving land make one symmetrical pattern around her.
⟨SET⟩ as sdf-S01's
```

#### sdf-S03d — in the final cut

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 15–17

- **take:** take-1, 97 frames (4.064 s)
- **cuts:** v2b (S03); v3, the final cut (S03)

```
⟨TIMELINE⟩ as sdf-S03's
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S04d — in the final cut

Seedance 2.5 on Higgsfield (References) · 6 s · 720p · bars 17–20

- **take:** take-1, 145 frames (6.080 s)
- **cuts:** v2b (S04); v3, the final cut (S04)

```
⟨TIMELINE⟩ as sdf-S04's
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S05d — in the final cut

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 20–24

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v2b (S05); v3, the final cut (S05)

```
⟨TIMELINE⟩ as sdf-S05's
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S06d

Seedance 2.5 on Higgsfield (References) · 6 s · 720p · bars 24–27

- **take:** take-1, 145 frames (6.080 s)
- **cuts:** v2b (S06)

```
⟨TIMELINE⟩ as sdf-S06's
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S07d

Seedance 2.5 on Higgsfield (References) · 12 s · 720p · bars 27–33

- **take:** take-1, 289 frames (12.064 s)
- **cuts:** v2b (S07)

```
⟨TIMELINE⟩ as sdf-S07's
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S08d — in the final cut

Seedance 2.5 on Higgsfield (References) · 12 s · 720p · bars 33–39

- **take:** take-1, 289 frames (12.064 s)
- **cuts:** v2b (S08); v3, the final cut (S08)

```
⟨TIMELINE⟩ as sdf-S08's
⟨CAMERA⟩ v1's, with the new ending
⟨LIGHT⟩ as sdf-S08's
```

#### sdf-S11d

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 47–49

- **take:** take-1, 97 frames (4.042 s)
- **cuts:** v2b (S11)

```
⟨TIMELINE⟩
0-3s: sings "Red pill, blue pill"
3-4s: sings "I'm the white pill"
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S13d

Seedance 2.5 on Higgsfield (References) · 4 s · 720p · bars 53–55

- **take:** take-1, 97 frames (4.064 s)
- **cuts:** v2b (S13)

```
⟨TIMELINE⟩
0-2s: sings "castle? Robots build you a castle" (the line is already under way on the first frame)
2-4s: sings "Everyone's royal, nobody's a vassal"
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S14d

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 55–59

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v2b (S14)

```
⟨TIMELINE⟩ as sdf-S14's
⟨CAMERA⟩ The camera travels alongside the car at its speed, a steady three-quarter view of her in the open back seat from the front, the road curving ahead through the orchards under the glass arches, and does not otherwise move. The camera moves precisely and smoothly, as if on a dolly track and a crane, with no cuts.
```

#### sdf-S15d

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 59–63

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v2b (S15)

```
⟨TIMELINE⟩ as sdf-S15's
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S16d — in the final cut

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 63–67

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v2b (S16); v3, the final cut (S16)

```
⟨TIMELINE⟩ as sdf-S16's
⟨CAMERA⟩ v1's, with the new ending
```

#### sdf-S22d

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 95–99

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v2b (S22)

```
⟨TIMELINE⟩ as sdf-S22's
⟨CAMERA⟩ v1's, with the new ending
⟨LIGHT⟩ as sdf-S22's
```

#### sdf-S24d

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 107–111

- **take:** take-1, 193 frames (8.042 s)
- **cuts:** v2b (S24)

```
⟨TIMELINE⟩ as sdf-S24's
⟨CAMERA⟩ The camera is still, a view of her from the side and slightly behind at the huge window, until 4 s; from 4 s it pushes in slowly past her shoulder to the small white pill between her fingers, lined up with a white capsule colony outside, and comes to rest at 6 s, then holds. The camera moves precisely and smoothly, as if on a dolly track and a crane, with no cuts.
⟨LIGHT⟩ as sdf-S24's
⟨FIX⟩ 【Fix】 Outside the window: the bright sun above the clouds, the soft blue sky and the white capsule colonies floating in it.
```

#### sdf-S25d

Seedance 2.5 on Higgsfield (References) · 8 s · 720p · bars 111–115

- **take:** take-1, 193 frames (8.064 s)
- **cuts:** v2b (S25)

```
⟨TIMELINE⟩ as sdf-S25's
⟨CAMERA⟩ v1's, with the new ending
⟨LIGHT⟩ as sdf-S25's
⟨FIX⟩ 【Fix】 The flip clock beside the bed reads 2:14 the whole time.
```

Cut as two versions: v2a, what was asked for (v1 with the four dances and the shader reshoots), and v2b (every shot of hers guide-free).

### v3: anabology's mix, section by section

anabology, on v2a and v2b: "ok let's do this mashup (round to the cut - not exact times) 1- use the original shader seedance render from last cut (pre-v2a) for the big tube / farmland, not the new one, and the first tree. we regresed on those. 2- 0:27 shot - 0:44 - keep the seedance only ones (v2b) 3- 0:44-1:02 - keep the shots from v2a (h3 ref'd) […] 5- 1:14 - 1:28 - honestly lets just remake this with her not singing, fully in the groove, just dancing around and having fun, she turns around, head goes down adn up etc - lip sync failed here but i dont think we need it. new seedance clip there. youd need to prompt forbidding singing here, and make sure she's happy. […] 8- 2:12-2:26 - shoot two here. shoot one more try with her lip syncing with the vocal stem and then one with her just grooving explicitly not singing, like 5 above. […] 10- 2:39-3:00 v2b but please make the cloud scene like more white/blue colors, its too saturated, wayy too saturated compoared to teh pastel light colors of the rest. […] only make the edits and reshoots where i specify above. and always have the lyrics." The not-singing takes: @Audio1 = the song's music without her voice (the song minus 0.89 × Suno's lead-vocal stem, exactly the generation length), no guide clip, @Image4 the empty place. The prompt:

```
【Audio Policy】 The output soundtrack is @Audio1 itself: copy @Audio1 sample for sample from the first frame to the last, with the same timing, pitch and level. It is music only, with no voice. Do not add singing, vocals, humming, speech, narration or sound effects.

【Generation Goal】 A shot of a music film, a scene from a Wes Anderson film: Claudia dances to the music, happy and free, fully in the groove, having fun; she does not sing. ⟨WHERE⟩ She is radiantly happy: a wide smile, laughing eyes, joy in every move. It is real film with his symmetry, his colour and his hand-made sets.

【Reference Asset Roles】
@Image1 is Claudia's face from every angle: identity only, never shown as a frame; do not use its white tank top or grey studio.
@Image2 is her dress from four sides: wardrobe only; do not use its studio or pose.
@Image3 is a colour and film-look reference only: take its colour, light, contrast and film texture; do not use its place, pavilion, bed, columns, plants or anything else in it.
@Image4 is the place of this shot, empty: take its set, landscape, layout, light and camera view; Claudia is the only person in it.
@Audio1 is the music of the song alone, with no voice, and the complete soundtrack of this video: she dances to its beat and its groove. Nobody sings.

【Subject】 Claudia: a 28-year-old Caucasian American woman with a grown-up angular face, defined cheekbones and a strong jawline, pale skin and light freckles, a glossy black blunt jaw-length bob with heavy straight bangs and one clay-orange streak through the bangs, a small flat clay-orange eight-pointed star hair clip, a thin headset microphone at her cheek. She is very tall and very skinny, with long thin legs, thin arms and a narrow waist, and a natural, relaxed neck and shoulders. She wears a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up corset bodice with silver eyelets and a white ribbon, big puffed short sleeves with ribbon ties and lace cuffs and a full two-tier ruffled skirt with lace trim, with white leather square-toe Mary Jane shoes. Only one Claudia appears.

【Dance】 ⟨TEMPO⟩
⟨STEPS⟩

【Mouth】 She does not sing, speak or mouth any words at any moment: her lips stay closed in a smile, or part only when she laughs; her mouth never moves in time with the music.

【Camera】 ⟨CAMERA⟩

【Look】 This is a Wes Anderson film: perfectly symmetrical, centred compositions, the camera square-on to the scene with a level horizon, everything arranged in flat, orderly planes like a stage set or a dollhouse; a tightly curated palette in which every surface belongs to the same few colours; every set, prop and costume crisp, hand-made and precisely placed; shot on 35 mm film with the rich, saturated colour of a 1970s colour-film print, the colour, contrast and film texture of @Image3: lush, deep colour, warm creamy whites with a golden cast, clear cyan blues, warm skin, deep warm shadows and bright whites with a soft glow. ⟨LIGHT⟩ Fine, visible film grain and the gentle softness of vintage lenses. Claudia's black hair with its one clay-orange streak and her white dress keep their own colours.

【Core Requirements】
1. No singing: Claudia never sings, speaks, hums or mouths words; her lips are closed in a smile or open in a laugh.
2. She is happy the whole time: smiling, laughing, carefree.
3. She dances on the beat of @Audio1 the whole time, with her whole body.
4. Keep Claudia's identity, face, hair with one clay-orange streak, star clip, headset microphone and dress the same throughout.
5. Natural anatomy: natural neck and shoulders, hands with five fingers, no extra or fused fingers; her arms, hands and legs are whole and attached the whole time, never vanishing, merging or bending wrongly; normal eyes.
6. Every movement smooth, natural and physically right: no jitter, warping, flicker, smearing or melting shapes.
7. No subtitles, captions, lyrics, titles, signs, logos, watermarks or any on-screen text.

【Final Acceptance Criteria】 The soundtrack is @Audio1 unchanged; Claudia never sings; she dances the steps above on the beat, happy, with whole, natural limbs; one Claudia, on-model; the camera moves as described; it looks like a scene from a Wes Anderson film on real film in the colour of @Image3; no on-screen text.

【Audio Policy】 The output soundtrack is @Audio1 unchanged, copied sample for sample: music only, no singing, vocals, humming, speech, narration or sound effects.
```

#### sdf-S09g — in the final cut

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 39–47

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v3, the final cut (S09)
- **outcome:** the new S09 at 1:14: grooving in the tram, happy, not singing.

```
⟨WHERE⟩ She stands in the open front of the little white tram as it glides along its rail through the apple orchard at sunrise.
⟨TEMPO⟩ as v2's
⟨STEPS⟩
0-2s: she bobs her head down and up on every beat, smiling with her eyes closed, her shoulders bouncing, one hand on the rail of the open front.
2-4s: she lets go of the rail and turns all the way around on the spot over two bars, her arms loose and swinging, laughing.
4-6s: she drops her head down on the downbeat and flicks it back up, her hair swinging, both hands raised.
6-8s: she sways her hips from side to side on every beat, waving both arms overhead.
8-10s: she turns all the way around again, slowly, her skirt swinging out, her head nodding to the beat.
10-13s: she bounces on her knees on every beat, her head going down and up with the groove, her arms swinging.
13-16s: facing the lens, she grooves with a wide smile, rolling her shoulders and nodding her head on every beat.
⟨CAMERA⟩ as sdf-S09d's
⟨LIGHT⟩ as sdf-S09d's
```

#### sdf-S18g — in the final cut

Seedance 2.5 on Higgsfield (References) · 16 s · 720p · bars 69–77

- **take:** take-1, 385 frames (16.064 s)
- **cuts:** v3, the final cut (S18)
- **outcome:** shown against the lip-sync try (sdf-S18d take 2); anabology: "ok without singing it is. finish up the rest and do the final cut"

```
⟨WHERE⟩ She is small in the frame, at the centre of the circle of standing stones on the golden hill above the wide river that forks in two.
⟨TEMPO⟩ as v2's
⟨STEPS⟩
0-2s: she bobs her head down and up on every beat and bounces on her knees, smiling.
2-4s: she turns all the way around on the spot with her arms out, her skirt swinging.
4-6s: she drops her head down on the downbeat and throws it back up, both arms raised, laughing.
6-8s: she dances along the inside of the stones, a step on every beat, her arms swinging free.
8-10s: she turns around again and sways her hips with both arms overhead.
10-12s: she hops lightly on each downbeat, her head nodding, her arms flinging up.
12-14s: she grooves on the spot, her head going down and up on every beat, her shoulders rolling.
14-16s: she turns once more and opens her arms wide to the sky, beaming.
⟨CAMERA⟩ as sdf-S18d's
⟨LIGHT⟩ as sdf-S18d's
```

The final cut (v3): 3:54 with the lyrics, no grain. Its 27 takes are listed at the top of this file.

## 11. The stills that fed the video jobs (GPT Image 2.5)

Every still here is an edit by GPT Image 2.5 (Sunburst) through an image API: the instruction is sent after "Edit the first image. ", the first image is the frame being edited and any further images follow as references; 1824 × 1024, high quality. Costs are as the API reported them (the v10 keyframes also in `shots/ledger-img.jsonl`). The rollout's lyric stills are in section 5; the earlier outfit sheets in sections 1 and 3.

**S01, for the Wan and Seedance jobs of section 8.** The S01 keyframe ($0.07), one of the 20 keyframes made for the v10 previz (27 edits with the redos, $1.77; with three edits of a wheat plate, $1.92 in `shots/ledger-img.jsonl`): first image the empty place (a Midjourney plate of the capsules), second her face sheet, third the dress from four sides:

```
Add one woman to this place, as a still frame from a 35mm film: Claudia, the woman shown in the second image (a sheet of her face from every angle; Caucasian American, pale skin with freckles; the exact face, hair and colouring of the sheet), wearing exactly the outfit in the third image (a white cotton milkmaid mini dress with a ruffled, lace-edged square neckline, a fitted lace-up bodice, big puffed short sleeves and a two-tier ruffled skirt, with white Mary Jane shoes). She dances in the wheat between the two giant capsules, mid-step with one arm raised, smiling as she sings; full body, in the centre, about a third of the frame height. She is slim and tall with natural proportions, every limb and hand anatomically correct. Keep the place exactly as it is (its composition, objects, light and colours) and light her with the place's own light (low golden sunlight with soft haze), so she belongs in the photograph. No text, no captions.
```

The crane's end frame ($0.06), from the keyframe with the dress as the second image:

```
Show the same place from high above, as the end of a crane shot that has risen over her: looking steeply down on the golden wheat and coral poppy meadow, the two giant glossy capsules (deep blue on the left, cherry red on the right) seen from above, and the same woman in the white dress small between them, dancing, her arms raised; the meadow is divided into long fields, and at the top of the frame the land of the colony curves up into golden haze. Same low golden light, long shadows. No text.
```

The masked keyframe for wank-S01-m ($0.05):

```
Edit only her head. Cover her whole head and face, her hair, ears and neck, with a tight matte chroma-key green balaclava, a plain bright green visual-effects hood, with two small eye holes and one small mouth hole, so only her eyes and her lips show through it. Keep everything else in the image exactly the same: her pose, arms, legs and body, the white milkmaid dress and white shoes, the golden wheat and poppies, the blue capsule on the left and the red capsule on the right, the sky, the light and the composition.
```

**The look.** The crop of the bed take that set the film's colour is not a generation: the left 560 × 720 pixels of a frame of rwa-S16-A, where she is not. The two targets of rwa-S12-S ($0.05 each), from the S12 render's frames at 1.4 s and 4.8 s, with the crop as the second image; ⟨LOOK⟩ is the same paragraph in both:

```
close:
Repaint it as a frame from a 1970s 35 mm feature film: a real, hand-made model photographed on film. Keep the composition exactly: the big clear glass capsule with rounded ends in the middle of the frame at the same size and position; inside it a bright blue sky with soft white clouds along the bottom and the small white two-piece capsule colonies floating in the same places, each with three tiny warm-lit window strips, and at the centre one smaller glass capsule holding its own tiny world; behind it deep black space with faint stars and, at the very bottom, the thin bright curve of the Earth's atmosphere. ⟨LOOK⟩

wide:
Repaint it as a frame from a 1970s 35 mm feature film: a real, hand-made model photographed on film. Keep the composition exactly: the glass capsule small near the top centre with its blue sky, clouds and tiny white capsule colonies inside; below it the curve of the Earth at dawn, its thin bright atmosphere glowing warm orange on the left and cyan blue on the right, the night side of the Earth deep blue-black; deep black space with faint stars above. ⟨LOOK⟩

⟨LOOK⟩
Give it exactly the colour, light, contrast and film texture of the second image (only its colour and film look; none of its place or objects): the rich, saturated colour of a 1970s colour-film print, warm creamy whites with a golden cast, clear cyan blues, deep warm shadows, a soft glow around the brightest highlights, fine visible film grain and the gentle softness of a vintage lens. It must look like a real photograph of a real object made by hand, never like a computer render: thick real glass with real reflections, refraction and tiny specks of dust, lacquered white model capsules with tiny imperfections. No text, no people.
```

**The shader stills** (`gen_final_v10.py --stills`): a frame of the shot's render at the time given, edited with "Repaint it as a frame from a 1970s 35 mm feature film: ⟨WHAT⟩. ⟨STYLE⟩" and the bed crop as the second image. ⟨STYLE⟩:

```
Give it the colour, light, contrast and film texture of the second image (only its colour and film look; none of its place or objects): the rich, saturated colour of a 1970s colour-film print, warm creamy whites with a golden cast, clear cyan blues, deep warm shadows, a soft glow around the brightest highlights, fine visible film grain and the gentle softness of a vintage lens. It must look like a real photograph of a real, hand-made object, never like a computer render. No text, no people.
```

*the paper tunnel (rsf-S02)*

```
2.9 s · $0.05 · ⟨WHAT⟩ a world folded from heavy cream washi paper inside a vast cylinder: the folded land runs away from the camera in sharp facets toward one low golden sun at the far end, curving up on both sides; keep every fold and the sun exactly where they are
8.7 s · $0.05 · ⟨WHAT⟩ the same paper world further along: the folded paper land on the left, the ribbed paper wall of the cylinder curving up on the right, the low golden sun in the distance; keep every fold where it is
```

*the farming ark (rsf-S02b)*

```
1.0 s · $0.05 · ⟨WHAT⟩ the inside of a vast farming ark ship, a generation ship that is one enormous farm: the long ridges that run from the camera toward the bright light at the far end become terraced fields of golden wheat, green rice paddies with mirror-still water and rows of orchard trees, held by stone terrace walls with irrigation channels along every fold; the land curves up on both sides like the inside of a huge cylinder; the bright light at the far end is the ship's long sun-line; keep every ridge and the light exactly where they are
5.8 s · $0.05 · ⟨WHAT⟩ the same farming ark ship further along: the terraced farmland folds into new shapes, long glass greenhouses with white frames ride along the ridges, orchards and wheat on the terraces, the ship's sun-line blazing at the centre of the frame; keep every ridge and the light where they are
9.5 s · $0.05 · ⟨WHAT⟩ the same farming ark ship: on the right the ribbed hull of the ship curves up, its ribs long greenhouse windows full of hanging gardens; on the left terraced fields and paddies fold toward the sun-line at the far end; keep the ribs, the folds and the light where they are
```

*the ark again from the 1080p render (rsf-S02f)*

```
1.0 s · $0.06 · ⟨WHAT⟩ as S02b still 1
5.8 s · $0.06 · ⟨WHAT⟩ as S02b still 2
9.5 s · $0.06 · ⟨WHAT⟩ as S02b still 3
```

*the tree with one path (rsf-S17, S17h)*

```
2.9 s · $0.05 · ⟨WHAT⟩ at night a vast tree of branching paths made of fine optical fibres and glass filaments against a deep blue starry sky: one single path glows warm gold from the trunk up to one tip, every other branch dark glass catching faint starlight; keep the branches and the lit path exactly where they are
```

*the same from the 1080p render (rsf-S17f)*

```
2.9 s · $0.06 · ⟨WHAT⟩ as S17 still 1
```

*the paper objects (rsf-S20, S20h)*

```
1.7 s · $0.05 · ⟨WHAT⟩ one sheet of heavy cream washi paper with an object embossed in it in real relief (the still at 1.7 s still shows the protein ridge), lit by one low raking sun so every crease throws a fine shadow, a thin coral glint along its creases; keep its shape and position exactly
11.7 s · $0.05 · ⟨WHAT⟩ a long view of a land folded from heavy cream washi paper at sunset: the big folds run to the horizon, the creases glow coral against the deep blue sky; keep the folds where they are
```

*one still per object, from the 1080p render (rsf-S20f)*

```
1.0 s · $0.06 · ⟨WHAT⟩ one sheet of heavy cream washi paper with the winding backbone of a protein raised in it in real relief, lit by one low raking sun so every crease throws a fine shadow, a thin coral glint along its creases; keep its shape and position exactly
3.0 s · $0.06 · ⟨WHAT⟩ the same sheet of cream washi paper with an Enigma rotor embossed in it, seen straight down its axis: a ring with its wiring lines crossing inside it, in real relief, lit by one low raking sun; keep its shape and position exactly
4.8 s · $0.06 · ⟨WHAT⟩ the same sheet of cream washi paper with the letters ABC folded up out of it in real relief, lit by one low raking sun, each letter casting a soft shadow; keep the letters' shapes and positions exactly
6.6 s · $0.06 · ⟨WHAT⟩ the same sheet of cream washi paper with the number 42 folded up out of it in real relief, lit by one low raking sun, casting a soft shadow; keep its shape and position exactly
8.1 s · $0.06 · ⟨WHAT⟩ the same sheet of cream washi paper with a row of seven small raised paper cells, each embossed with one letter, M T W T F S S, lit by one low raking sun; keep the cells, the letters and their positions exactly
```

*the lit tree (rsf-S21, S21h)*

```
3.6 s · $0.05 · ⟨WHAT⟩ at night on a dark meadow a tree of branching paths made of real optical fibres and fine glass filaments: the light has climbed halfway out from the trunk, the lit branches glowing warm gold, the unlit ones dark glass; keep the branches exactly where they are
8.3 s · $0.05 · ⟨WHAT⟩ the same fibre tree with its whole crown lit, millions of tiny white-gold points like a cloud of fireflies, the grass at its foot lit warm, a deep blue starry night; keep the crown's shape exactly
```

*the same from the 1080p render (rsf-S21f)*

```
3.6 s · $0.06 · ⟨WHAT⟩ as S21 still 1
8.3 s · $0.06 · ⟨WHAT⟩ as S21 still 2
```

*the nested capsules and the pill over the Earth (rsf-S26)*

```
3.8 s · $0.05 · ⟨WHAT⟩ inside a sealed glass capsule world: thick curved glass walls with bright rim highlights, an amber sky with soft clouds and white two-piece capsule colonies with three warm window strips each floating in it; keep every capsule where it is
12.5 s · $0.05 · ⟨WHAT⟩ a small white pill floating above the curve of the Earth at sunrise: the sun just cresting the limb, the thin atmosphere glowing orange and cyan, deep black space with faint stars; keep the pill, the sun and the curve where they are
```

*S12 over the Earth (rsf-S12h): the close still is rwa-S12-S's; the wide one new*

```
4.8 s · $0.05 · ⟨WHAT⟩ a small glass capsule with its blue sky, clouds and tiny white capsule colonies inside, floating small near the top centre above the curve of the Earth: below it the Earth's day side with real white clouds, deep blue oceans and brown and green land, its thin atmosphere glowing bright blue along the edge and warm orange on the left where the sun is just cresting the limb; deep black space full of stars behind; keep the capsule, the curve and the sun where they are
```

The cloud stills, each from the render's frame at 2.0 s: rsf-S20c's ($0.06), with the bed crop as the second image, and rsf-S20w's ($0.05), the pastel balloons, with no second image:

```
S20c:
Repaint it as a frame from a 1970s 35 mm feature film shot from an aircraft flying low over a sea of puffy cumulus clouds at sunset: keep the clouds, their shapes and positions, the low warm sun light from the left and the deep blue sky exactly as they are. Add five techno hot air balloons drifting above the cloud deck at different distances, one large and near on the right, the others smaller toward the horizon: classic teardrop envelopes built like fine machines, panels of cream, coral and powder-blue fabric stitched with thin softly glowing seams and a band of dark solar cells around each, a ring of small white ducted fans around each slim white gondola, a warm burner glow under each envelope. The whole frame has the rich, saturated colour of a 1970s colour-film print: warm creamy whites with a golden cast, clear cyan blues, deep warm shadows, a soft glow around the brightest highlights, fine visible film grain and the gentle softness of a vintage lens. It must look like a real photograph, never like a computer render. No text, no people visible.

S20w:
Repaint it as a frame from a 1970s 35 mm feature film in soft, light pastel colour: a sea of soft white cumulus clouds in bright midday light under a pale, clear sky blue, the shadows inside the clouds a soft pale blue-grey, never orange or gold. Among the clouds float hot air balloons of the future: round envelopes striped in soft cream, pale coral and pale sky blue, each with a band of glinting solar panels around its middle, a softly glowing burner and a small white gondola with two ducted fans; one large balloon close on the right, a few smaller ones further off toward the sun. Keep every cloud and the sun where they are. Low saturation, airy and light, fine film grain and the gentle softness of a vintage lens; it must look like a real photograph, never a computer render. No text, no people.
```

The shader and look stills come to 28 edits, $1.52.

**The empty places** for the guide-free takes (section 10): the first frame of each v1 take of hers with her removed. The four dance shots (S09, S18, S19, S23) first:

```
Remove the woman in the white dress completely, leaving the place empty: fill in what is behind her naturally (the ground, the plants, the architecture), with no trace of her, her shadow or any person. Keep everything else exactly as it is: the composition, the camera angle, the light, the colours and the film texture. No text, no people.
```

then the other fifteen (S01, S03–S08, S11, S13–S16, S22, S24, S25) with this text:

```
Remove the woman in the white dress completely, leaving the place empty: fill in what is behind her naturally (the ground, the plants, the furniture, the architecture), with no trace of her, her shadow or her reflection. Keep everything else exactly as it is: the composition, the camera angle, the light, the colours and the film texture. No text.
```

and for S15, whose child stays at the desk:

```
Remove only the woman in the white dress, completely: fill in what is behind her naturally, with no trace of her or her shadow. Keep the child sitting at the desk and everything else exactly as it is: the composition, the camera angle, the light, the colours and the film texture. No text.
```

19 plates, $0.86.

## 12. The shader scenes

After the reset (section 6) the worlds without her were written as GLSL shaders, one iterated rule per world, light and colour from the same loop. anabology on the first ones: "ok its decent but like.. idk i feel like ive seen a lot more creativity in shaders, and completeness, in the ones i sent even. clouds, cities, etc made extremely compelling with short shaders."; then "Idk if feels like you're adding ... items to increase complexity rather than compressing intricacy? Does that make sense? What's the difference between your shader code and the examples I gave"; "Go ahead, try to make something sophisticated and beautiful"; and "[…] remember the two key things here are the shader compressed intricacy combined with the audio lessons (structuring the film based on the audio from the start)".

**How they were rendered.** `tools/shader/render.py` draws a fragment shader headless on a GPU (EGL through moderngl), either a Shadertoy-style `mainImage()` or a compact twigl-style body (`FC`, `r`, `t`, `o`, `rotate2D`, `rotate3D`, `hsv`, `snoise3D`). Its clock is the song's: song seconds, plus the bar and beat positions from the beat map (bar 39.0 is the downbeat of bar 39), so every move is written in bars and lands on a downbeat. Frames are supersampled, drawn in tiles, box-filtered and piped to ffmpeg with the song under the same window. The previz renders were 1280 × 720 at 24 fps; for the final shoot the scenes were rendered again at 1920 × 1080 with 3 × 3 supersampling in 3 × 3 tiles on a render box. Seedance got them three ways: shrunk to 320 × 180 and scaled back (v1), the 1280 × 720 render as it is (the "h" jobs) and the 1080p render (the "f" jobs and the clouds).

**The worlds in the final cut.** Each went through several rounds (fold 1–6, pill 1–6, the endings tree), written by agents and reviewed against the cut on the bar map; the picks are in `tools/film/v10/m_picks.json`.

- **S02, bars 9–15, `tw2/fold6-s02.glsl` (the origami colony).** One rule: an infinite sheet folded eight times, `p = abs(mod(p + A, 2A) - A)` with long cells halving from 128 to 1, the crease relief `min(p.x, p.y)`, each level turning the levels below it on the downbeat after its relief appears; the sheet wrapped on the inside of an O'Neill cylinder, the land flattening into three ribbed window strips. Bar 9 (the bass coming in) opens with three levels in place; on each downbeat from 10 to 14 one coarser level snaps in, eased over the twelfth of a bar before it, while the camera cranes 18-fold up the colony's axis until the land closes overhead. Seedance turned it into the farming ark.
- **S12, bars 50–53, and S26, bars 115–123, `tw2/pill6-colony.glsl` (the white pill).** Every capsule holds the same nine children: a glass capsule at its centre (a quarter of its size, turned 0.2 rad) and eight white colonies scattered by a sine hash of their index. The ray counts the glass walls it is inside, and leaving a world it ends on that world's sky, so each glass pill is a sealed world; each level's sky is a step warmer (1.45 × (0.97, 0.8, 0.64) to the power of the level: white, cream, peach, amber), and the colonies are white two-piece capsules with three warm window strips. S12: the opaque pill of the bar-50 frame turns to glass by beat 3 and the camera pulls back over the Earth at dawn. S26: the camera sits on the chain's axis at a distance of 4ⁿ and leaves one glass wall exactly on each downbeat from 116 to 120, bursts out of the hull on 121 as the sun crests the limb, and the pill closes back to white.
- **S17, bars 67–69, and S21, bars 90–95, `tw2/endings.glsl` (the tree of endings).** One fold repeated 24 times (step up one unit, mirror x, turn −0.5 rad and 1.6 rad, scale by 1.25) grows a tree with 2²⁴, about 16.8 million, tips: the possible endings. S17 lights one path, hers, as the camera dives along it; S21 lights the tree from the trunk out, about one and a half levels a beat, until the crown glows, on a night meadow, the camera in a slow orbit. The same tree fits in a tweet (`tw2/tweet-tree.glsl`, one of three tweet-length versions of the worlds):

```
// twigl
vec3 d=normalize(vec3(FC.xy*2.-r,r.y*1.4)),p;d.yz*=rotate2D(-.12);for(float i,e,z,s,j,l,w,c;i++<2e2&&z<25.;z+=max(e*.6,w*.5)){p=z*d+vec3(0,2,-6.5);w=z/r.y*2.;p.y=abs(p.y);p.xz*=rotate2D(t*.1);for(e=9.,s=1.,j=0.;j++<24.;p.y-=1.,p.x=abs(p.x),p.xy*=rotate2D(-.5),p.xz*=rotate2D(1.6),p*=1.25,s*=1.25)l=(length(p-vec3(0,clamp(p.y,0.,1.),0))-.03)/s,l<e?e=l,c=j:c;o.rgb+=hsv(.08,1.-c/24.,1.)*exp(-e/w)*.02/(1.+c*.1)*(z*d.y<-2.?.25:1.);}o=tanh(o*1.3+vec4(3,1.4,.5,0)*.002/(abs(d.y)+.01));
```

- **S20, bars 83–88, `tw2/fold6-break.glsl` (the break).** One sheet of paper refolds on each sung line's downbeat into that line's object, from real data (`tools/shader/data/`): bar 83, "Proteins folded", the backbone of ubiquitin (PDB entry 1UBQ, its 76 Cα atoms, as a bas-relief whose crest height is each atom's depth); bar 84, "Old Enigma codes, decoded", the wiring of the Enigma I's rotor I, EKMFLGDQVZNTOWYHXUSPAIBRCJ, as 26 creases between two rings, so its cycles show as polygons, stepping one letter on beats 2, 3 and 4; bar 85, the letters ABC; bar 86, 42 (Deep Thought's answer); bar 87, the week as seven cells M T W T F S S, Monday's rising on beat 1, Tuesday's on beat 2, the other five folding flat on beat 3. In the shader the sheet then folds flat and the camera rises to a paper horizon at sunset (bars 88–90); in the final cut that tail is the clouds.
- **S20, bars 88–90, the cloud field.** A cloud shader anabology supplied (`tw2/clouds-field.glsl`, pasted into their notes on v1; its code is not reproduced here): a deck of cumulus flown over low at sunset. It was rendered on the same renderer at 1080p (rsf-S20c), then as a day variant (`tw2/clouds-field-day.glsl`) that changed its sun, sky and absorption so the clouds stay white under a pale blue sky, its shapes and flight unchanged (rsf-S20w). The hot air balloons are Seedance's, from the still in section 11.

The shaders' first test as a world for Wan, `tools/shader/colony.glsl` (the colony as a cylinder 6.4 km across, three land strips facing three window strips, two capsules as distance functions), is in section 6; in the Wan reshoot of section 7 the six previz renders were Wan's Video 1.
