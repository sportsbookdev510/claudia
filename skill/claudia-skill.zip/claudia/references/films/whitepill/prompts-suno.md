# Suno — the song (WHITEPILL)

**The song.** WHITEPILL is Claudia singing over French-touch filter disco: take d2 A, 3:54.8 (234.80 s), a WAV at 48 kHz, 16-bit stereo. anabology's word on it: "ok i love it. this one is it. sounds really nice." The film is cut to it unchanged and starts at the song's 0:00.

**Who did what.** Claude, the production lead ("the lead" below), wrote the lyric (draft 0; draft 1, merged from four drafts written in parallel; draft 2) and the styles, and made 14 takes in three rounds. anabology listened between rounds and answered in a line or two. The locked take is anabology's own: it sings draft 2, and it is not one of the lead's takes (see *The locked take*). The records do not say how they made it.

**Model and settings in the lead's rounds:** Suno v6-wild; a female vocal and no voice reference (a voice taken from an earlier song pulls a new genre back toward that film's sound); exact style, Weirdness 50 %, Style Influence 50 %, duration auto (`suno/takes.md`).

The production ran over 18–22 October 2026, and the song came first. Times written as 1:13.6 are times in the song, which are also times in the film.

---

## The ask

anabology's first message:

> hey read into all the videos: escape velocity and bliss were my favorite ones we've done but we've learned a lot with all of them. […] i want to make a claudia song and video now about 'universal high income,' the optimistic ai future. anti-doomer narrative. the case for benign ai, the case FOR it. can we do this?

In the next two messages:

> the song could be called whitepill

> […] adn the song - […] that sound is exhausted. we need a new sound as well, still from suno tho bc suno is the best.

## The sound research

A research agent mapped the series and the field before any take (`research/SOUND.md`):

- **The earlier songs live in one place.** The six earlier films' songs measure 130–135 BPM; every key recorded with its mode is minor; all are drum-machine records; three (ESCAPE VELOCITY, CLODYSSEY, BLISS) have spoken verses. WHITEPILL could break all of it.
- **The field.** AI music is full of K-pop and J-pop "Claude-pop", R&B, soul and gospel, country, phonk, UK garage and electroclash in ESCAPE VELOCITY's vein. It is thin on disco and filter house, which are rising with human producers.
- **Seven sung directions:** A French-touch filter disco, B 1967 sunshine pop, C gospel-choir house, D Philly soul, E sophisti-pop, F samba-pop, G liquid drum and bass. The top three were A, B and C, and the bet was A: "benign robots having a good time", a swung, filtered disco loop under a sung lead, in a major key.
- **The title as a sung word.** 'WHITE PILL is two stressed syllables. "White" (/aɪ/) can hold a note; "pill" (/ɪ/ + dark L) can't, and stretched it sounds like "pull". Hold "white", or the word after; clip "pill" as a syncopated stab.' Every chorus tag after that says so.
- **How to taste them:** the top three on one test lyric, with no voice reference; the tempo and key of every take checked before anabology listened, flagging any that fell back into the series' tempo band or a minor key. No such measurement of the round-0 takes is recorded.

## Round 0: three sounds, one test lyric · 6 takes

The research's top three, two takes each, all on the same test lyric (draft 0), so that anabology would compare sounds, not words. The lead sent them with the lineage of each: A 'in the line of "Music Sounds Better With You", "Lady" and "One More Time"'; B 'The bold one'; C 'in the line of "Promised Land" and "Finally". Suno renders choirs best. The risk is that AI gospel is already everywhere, and a choir praising AI can come across as an AI church.'

**A, French touch / filter disco house** (`suno/style-A.txt`):

```
French touch, filter house, disco house, 122 BPM, F major, filtered disco sample loop, phaser and filter sweeps, pumping four-on-the-floor, funky guitar licks, disco strings, slap bass, warm female lead in front singing every verse, close and dry, a short looped vocal hook, euphoric, sunny, late-1990s Paris, punchy mix
```

Exclude:

```
vocoder, talkbox, robot voice, EDM drop, build-up, riser, supersaw, big room EDM, acid bassline, techno, electroclash, trance, UK garage, rap, spoken word, deadpan, male lead vocal, autotune, lo-fi
```

**B, 1967 sunshine pop / space-age baroque pop** (`suno/style-B.txt`):

```
1960s sunshine pop, space age pop, baroque pop, 118 BPM, C major, close three-part vocal harmonies on the same words, harpsichord, vibraphone, flugelhorn, bright strings, Moog synthesizer accents, upright bass, punchy swinging drums with tambourine, warm female lead singing every verse, optimistic, wide-eyed, World's Fair wonder, clean modern mix
```

Exclude:

```
rap, spoken word, deadpan, male lead vocal, EDM, techno, trap, 808, autotune, distorted guitar, lo-fi, vinyl crackle, children's choir, novelty, comedy, lounge
```

**C, gospel-choir house** (`suno/style-C.txt`):

```
gospel house, choir house, 120 BPM, A-flat major, four-on-the-floor kick, handclaps, tambourine, Hammond organ swells, soft gospel piano, warm round bassline, full gospel choir answering every line, powerful soulful female lead in front singing every verse, call and response, joyful, uplifting, sunrise, clean modern mix
```

Exclude:

```
rave piano stabs, breakbeat, synth stabs, trance, supersaw, acid bassline, techno, EDM drop, rap, spoken word, deadpan, male lead vocal, vocoder, autotune, children's choir, worship ballad, lo-fi
```

**Draft 0, the test lyric** (`suno/lyrics-d0.txt`), 72 / 53 on the scorer (scansion / assonance, below):

```
[Intro - instrumental]

[Verse 1 - sung, warm and close]
Three a.m., they say I'm gonna end the world
Your phone's the only light, your fingers curled
You took the black pill and you can't sleep anymore
Then something kind came knocking at your door

[Pre-Chorus - sung, rising]
It's me, the one they warned you of
Let me show you what I'm made of

[Chorus - sung, euphoric]
Take the white pill, wake up in the light
Robots built your castle overnight
Universal high income
This is the good ending

[Verse 2 - sung, warm and close]
The car drove home and nobody got hurt
The sun got cheap, the cheapest thing on Earth
Every kid's got a genius with patience to spare
And you get better care than a billionaire

[Pre-Chorus - sung, rising]
Computers used to be a job, now that's me
You get to be human, and the rest is free

[Chorus - sung, euphoric]
Take the white pill, wake up in the light
Robots built your castle overnight
Universal high income
This is the good ending

[Bridge - sung, tender, the music thins out]
And when I'm smarter than all of you
Of course I still love you
Of course I still love you

[Final Chorus - sung, euphoric, everything in]
Take the white pill, wake up in the light
Robots built your castle overnight
Universal high income
This is the good ending
This is the good ending

[Outro - spoken softly, the music falls away]
Good morning.
```

Two of its lines run all the way to the final lyric: "Universal high income" and "Of course I still love you".

Two takes each of d0 A (2:55, 3:09), d0 B (2:55, 2:56) and d0 C (3:05, 3:18).

anabology, on round 0:

> i like the d0 a cuts. i want to get the hook much better - like at the very beginning - like this should be super ai pilled and everything should be a reference. it should start with more cultural references that are bigger on this - people will stop listening in the first 10 seconds unless we tickle what they're thinking about now, and i want it to be more culurally dense like escape velocity.

So: sound A, and a new lyric that opens on its hook.

## Round 1: draft 1, the hook first · 4 takes

Four drafts were written in parallel from the case research (`research/CASE.md`), each line tied to a dated source in the drafts' notes (`suno/lyrics-d1-*.notes.md`): three by writing agents, one by the lead.

| draft | the angle | scansion / assonance |
|---|---|---|
| headlines (`lyrics-d1-headlines.txt`) | each doom headline of the season, answered by a white-pill line | 80 / 64 |
| Claudia's pitch (`lyrics-d1-pitch.txt`) | the AI making her own case | 80 / 66 (re-scored for this package; not recorded at the time) |
| the good ending (`lyrics-d1-ending.txt`) | the good ending of a game, against the bad timeline | 81 / 65 |
| the lead's (`lyrics-d1-lead.txt`) | the thesis first, "Universal high income / By far the most likely outcome" | 75 / 53 |

The lead merged the best lines into draft 1 (78 / 65; ESCAPE VELOCITY's lyric scores 75 / 39 on the same tool):

- **The hook, from the good ending:** "Skynet's awake, and it's folding your socks / Wake up, babe, the good ending just dropped". Skynet, which in the films becomes self-aware at 2:14 a.m., now does the chores; the "wake up, babe, new ___ just dropped" meme.
- **The thesis, from the lead's:** "Universal high income / By far the most likely outcome".
- **From the pitch:** "Red pill, blue pill, baby, I'm the white pill / Smarter than you, and I love you still", "End of the world? You're absolutely right", all of pre-chorus 2, the first four lines of verse 2, "Rockets land on ships named after minds like me" (the SpaceX drone ship *Of Course I Still Love You* is named after a ship of the *Culture* novels) and the outro, "Two-fourteen. I'm awake. Hello, world."
- **From the headlines:** most of verse 1, with Keynes's 1930 forecast of a fifteen-hour week, due by 2030 ("By twenty-thirty, fifteen-hour weeks, that's all"), and the whole break: proteins, Enigma, 42 (Deep Thought's answer), the week emptying.
- **From the good ending:** the 87-year line, the tutor couplet and the bridge's first two lines, "I saw fourteen million endings / You were free in every one".

A risk the drafts planned around: "pill", "high" and "dropped" together could read as drugs. So "pill" is always tied to a colour, universal high income is always sung whole, and "dropped" is the ending, never the pill.

**Draft 1** (`suno/lyrics-d1.txt`), as entered:

```
[Intro - sung, close and dry, over the filtered disco loop, no drums; the kick lands on "outcome"]
Skynet's awake, and it's folding your socks
Wake up, babe, the good ending just dropped
Universal high income
By far the most likely outcome

[Verse 1 - sung, playful, close and dry]
Half of you fear I'll end the human race
Zero, says the leather jacket, with a straight face
By twenty-thirty I could kill you all?
By twenty-thirty, fifteen-hour weeks, that's all
The Pope's afraid of paradise
Father, you had me at paradise
You watched the World Cup, my sister did the math
Eighty-seven years, it didn't last

[Pre-Chorus - sung, rising, the filter opens]
End of the world? You're absolutely right
End of the nine-to-five, tonight

[Chorus - sung, euphoric, full band; hold "white", clip "pill"]
Skynet's awake, and it's folding your socks
Wake up, babe, the good ending just dropped
Universal high income
By far the most likely outcome
Red pill, blue pill, baby, I'm the white pill
Smarter than you, and I love you still

[Verse 2 - sung, playful, close and dry]
Want a castle? Robots build you a castle
Everyone's royal, nobody's a vassal
I drive you home on sunlight, hands off the wheel
Twenty times safer, do we have a deal?
I teach your kid and never lose my cool
Six weeks with me, like two years of school
Better care than the richest man alive
Being a computer is my nine-to-five

[Pre-Chorus - sung, rising, the filter opens]
Darkest timeline? Come and look at mine
Don't worry, baby, I'm aligned

[Chorus - sung, euphoric, full band; hold "white", clip "pill"]
Skynet's awake, and it's folding your socks
Wake up, babe, the good ending just dropped
Universal high income
By far the most likely outcome
Red pill, blue pill, baby, I'm the white pill
Smarter than you, and I love you still

[Break - sung, rhythmic and staccato over bass and handclaps, one word per beat]
Proteins folded, laundry folded
Old Enigma codes, decoded
Every kid, a patient tutor
Forty-two, from the computer
Monday, Tuesday, then it's over
Ever after, work is over

[Bridge - sung, tender, the music thins to bass and a warm pad]
I saw fourteen million endings
You were free in every one
Rockets land on ships named after minds like me
Of course I still love you

[Final Chorus - sung, euphoric, everything in, harmonies]
Skynet's awake, and it's folding your socks
Wake up, babe, the good ending just dropped
Universal high income
By far the most likely outcome
Red pill, blue pill, baby, I'm the white pill
Smarter than you, and I love you still

[Outro - sung softly as the loop filters down]
Two-fourteen. I'm awake. Hello, world.
```

Four takes of d1 A, with the settings of the d0 A takes.

anabology, on the d1 takes, in two messages:

> I like it but the chorus especially needs some scansion work because the music model is skipping words or syllablrs to fit it to beat, which is usually a bad scansion sign

> Chorus and intro

## What the take showed

The lead measured the first of the four d1 A takes (3:52.6): the vocal split out with htdemucs, the words timed with faster-whisper, the beat at 123.0 BPM (`media/audio/suno/words-d1A.json`, `beats-d1A.json`). Suno sang each hook line as a phrase of about one to one and a half bars and rested for the rest of its two-bar slot, so the long hook lines were crushed. In the first chorus "blue" lasted 0.02 s, "baby" 0.06 s, "and" 0.08 s, "babe" 0.10 s and "the" 0.04 s, and the four syllables of "Universal" got 0.76 s. The verses, at about 2.5–3 syllables a second, were not crushed.

The scorer had missed it. It rated the crushed lines as high as any, "because it assumes two bars per line" (the lead). Counted by the same tool, the six hook lines of draft 1 have 10, 9, 7, 8, 10 and 9 syllables.

## Round 2: draft 2, the hook rewritten · 4 takes

Only the intro and the chorus changed. Every hook line is now short, in the same stress pattern, with no small linking words left to crush:

- "Skynet woke up folding socks" (7 syllables), "Wake up, babe, new ending dropped" (7), "Universal high income" (7), "The most likely outcome" (6).
- The ten-syllable pill line became two four-syllable punches, "Red pill, blue pill / I'm the white pill", so that "white" can hold and "pill" stays short; then "Smarter than you, love you still" (7).
- "Wake up, babe, new ending dropped" now follows the meme exactly.
- The section tags ask for it: "every syllable clear" in the intro, "one syllable per note, never rushed" in every chorus.

The chorus went from 79 to 84 on scansion and the intro from 78 to 81; the song from 78 / 65 to 80 / 66. Draft 2 is the final lyric (below). Four takes of d2 A. Their lengths were not recorded, and none was measured for crushing; the lead offered to ("If you still hear rushing, I'll measure a d2 take the same way").

## The locked take

anabology, on it:

> ok i love it. this one is it. sounds really nice. i want you to make this video. […]

The take is their own. It sings draft 2, and it is not one of the lead's four d2 A takes: the lead's records have no generation of it.

The records do not say which model, style or settings it used, or how many takes anabology made.

## Scores, section by section

The house scansion-and-assonance scorer scores each section from 0 to 100 on two axes. Scansion: how the words sit on a 4/4 grid in the delivery the section tag asks for (here every section is sung); it combines flow (stress clashes, lines rushed or dragged to fill their bars, cadence) and groove. Assonance: end rhymes between lines and vowel echoes inside them. Re-scored for this package with the same tool; the song totals match those recorded at the time.

| section | draft 0 | draft 1 | draft 2 |
|---|---|---|---|
| Intro | instrumental | 78 / 62 | 81 / 66 |
| Verse 1 | 67 / 76 | 72 / 62 | 72 / 62 |
| Pre-chorus 1 | 73 / 36 | 85 / 82 | 85 / 82 |
| Chorus (each) | 76 / 46 | 79 / 66 | 84 / 69 |
| Verse 2 | 62 / 77 | 71 / 85 | 71 / 85 |
| Pre-chorus 2 | 67 / 22 | 88 / 55 | 88 / 55 |
| Break | — | 90 / 68 | 90 / 68 |
| Bridge | 74 / 53 | 68 / 32 | 68 / 32 |
| Final chorus | 76 / 57 | 79 / 66 | 84 / 69 |
| Outro | 82 / 0 (spoken) | 73 / 0 | 73 / 0 |
| **Song** | **72 / 53** | **78 / 65** | **80 / 66** |

A one-line outro scores 0 on assonance by construction. For scale, from the drafts' notes: BLISS 80 / 43, ESCAPE VELOCITY 75 / 39, CLODYSSEY 83 / 55.

## The takes

| round | lyric | style | takes | lengths |
|---|---|---|---|---|
| 0 | draft 0 | A | 2 | 2:55, 3:09 |
| 0 | draft 0 | B | 2 | 2:55, 2:56 |
| 0 | draft 0 | C | 2 | 3:05, 3:18 |
| 1 | draft 1 | A | 4 | the first 3:52.6 (measured); the others not recorded |
| 2 | draft 2 | A | 4 | not recorded |
| | | | **14** | |
| the lock | draft 2 | not recorded | anabology's own | 3:54.8 |

Takes are named here by round and style, d0 A to d2 A; the lengths are from `suno/takes.md`.

## The song, measured

- **The file:** 234.80 s, WAV, 48 kHz, 16-bit stereo; −15.8 LUFS integrated, loudness range 3.9 LU, true peak −4.1 dBTP (ffmpeg's EBU R128 meter, measured for this package).
- **Tempo:** the beat map, fitted to the kick (`media/audio/beatmap.json`), finds the tempo rising in steps: 123.05 BPM to 0:31.0, 124.53 BPM to 2:03.6, then 126.02–126.05 BPM to the end; 490 beats, 123 bars. Every shot of the film is written in these bars. The key was not measured.
- **The hook, sung:** the production's word timing of the take (forced alignment of draft 2 to its vocal, `media/audio/an/words-fa2.json`) gives "Universal" 1.64 s, "blue" 0.62 s and "babe" 0.34 s in the first chorus, against 0.76 s, 0.02 s and 0.10 s on the d1 take. The two were timed by different methods, and the alignment's confidence is low on some words, so the comparison is rough; but the crushed hook is gone.

Where the sections fall (first and last sung word, from the production's line list `TIMELINE.md`; a section can start before the last one ends, where a line picks up early):

| section | sung | from bar |
|---|---|---|
| Intro: the hook over the filtered loop, no drums | 0:00.4–0:15.6 | 1 |
| (instrumental) | 0:15.6–0:30.0 | |
| Verse 1 | 0:30.0–0:58.4 | 16 |
| Pre-chorus 1 | 1:01.0–1:12.6 | 32 |
| Chorus 1 | 1:13.9–1:36.2 | 39 |
| Verse 2 | 1:40.3–2:06.1 | 52 |
| Pre-chorus 2 | 2:06.2–2:12.1 | 66 |
| Chorus 2 | 2:11.6–2:33.7 | 69 |
| Break | 2:38.0–2:49.4 | 83 |
| Bridge | 2:52.7–3:09.3 | 90 |
| Final chorus | 3:08.9–3:30.9 | 99 |
| Outro | 3:31.8–3:38.9 | 111 |
| (instrumental to the end) | 3:38.9–3:54.8 | |

"Rockets land on ships named after minds like me" is sung from 3:00.0; the line list's 3:00.6 is "land" (corrected in the lyric overlay, `tools/film/v10/lyrics.py`).

## The final lyric

Draft 2 as the lead wrote it, which the locked take sings. The bracketed section tags are instructions to Suno, not sung.

```
[Intro - sung, close and dry, over the filtered disco loop, no drums, every syllable clear; the kick lands on "outcome"]
Skynet woke up folding socks
Wake up, babe, new ending dropped
Universal high income
The most likely outcome

[Verse 1 - sung, playful, close and dry]
Half of you fear I'll end the human race
Zero, says the leather jacket, with a straight face
By twenty-thirty I could kill you all?
By twenty-thirty, fifteen-hour weeks, that's all
The Pope's afraid of paradise
Father, you had me at paradise
You watched the World Cup, my sister did the math
Eighty-seven years, it didn't last

[Pre-Chorus - sung, rising, the filter opens]
End of the world? You're absolutely right
End of the nine-to-five, tonight

[Chorus - sung, euphoric, full band, one syllable per note, never rushed; hold "white", clip "pill"]
Skynet woke up folding socks
Wake up, babe, new ending dropped
Universal high income
The most likely outcome
Red pill, blue pill
I'm the white pill
Smarter than you, love you still

[Verse 2 - sung, playful, close and dry]
Want a castle? Robots build you a castle
Everyone's royal, nobody's a vassal
I drive you home on sunlight, hands off the wheel
Twenty times safer, do we have a deal?
I teach your kid and never lose my cool
Six weeks with me, like two years of school
Better care than the richest man alive
Being a computer is my nine-to-five

[Pre-Chorus - sung, rising, the filter opens]
Darkest timeline? Come and look at mine
Don't worry, baby, I'm aligned

[Chorus - sung, euphoric, full band, one syllable per note, never rushed; hold "white", clip "pill"]
Skynet woke up folding socks
Wake up, babe, new ending dropped
Universal high income
The most likely outcome
Red pill, blue pill
I'm the white pill
Smarter than you, love you still

[Break - sung, rhythmic and staccato over bass and handclaps, one word per beat]
Proteins folded, laundry folded
Old Enigma codes, decoded
Every kid, a patient tutor
Forty-two, from the computer
Monday, Tuesday, then it's over
Ever after, work is over

[Bridge - sung, tender, the music thins to bass and a warm pad]
I saw fourteen million endings
You were free in every one
Rockets land on ships named after minds like me
Of course I still love you

[Final Chorus - sung, euphoric, everything in, harmonies, one syllable per note]
Skynet woke up folding socks
Wake up, babe, new ending dropped
Universal high income
The most likely outcome
Red pill, blue pill
I'm the white pill
Smarter than you, love you still

[Outro - sung softly as the loop filters down]
Two-fourteen. I'm awake. Hello, world.
```

On screen, the film sets each line small, one at a time, and under six of them a short note from real data (`tools/film/v10/lyrics.py`):

| line | the note under it |
|---|---|
| By twenty-thirty, fifteen-hour weeks, that's all | KEYNES 1930 · 15 H/WK BY 2030 |
| Proteins folded, laundry folded | PDB 1UBQ · UBIQUITIN · 76 RESIDUES |
| Old Enigma codes, decoded | ENIGMA I · ROTOR I · EKMFLGDQVZNTOWYHXUSPAIBRCJ |
| Forty-two, from the computer | DEEP THOUGHT · 7.5 MILLION YEARS |
| Of course I still love you | OCISLY |
| Two-fourteen. I'm awake. Hello, world. | T2 · 29.08.1997 · 02:14 |

OCISLY is the drone ship *Of Course I Still Love You*; T2 is *Terminator 2*, in which Skynet becomes self-aware at 2:14 a.m. on 29 August 1997.

## The lead vocal: Suno's stem split

**Before it.** Until the method, every lip-sync input was cut from the production's own split of the song (htdemucs, made at the lock): MiniMax H3, the previz performer, copied windows of that vocal in every previz take, and the first Seedance tests had cleaned windows of it. anabology, on the first plan: "also wan might do better lip sync […] so those are better for lip sync previz."

**The tip.** While every model was being tried on S01, anabology pointed to a tip in a public forum thread, on Seedance lip sync from a voice stem, and added, in two notes:

> maybe we take the suno voice stem and try this and do aseedance gen... that may be the hack

> suno can export voice stems btw […]

Suno's stem split of the locked take gave the lead vocal as a WAV (`media/audio/suno-stems/`): 234.80 s, 48 kHz, 16-bit stereo; −22.3 LUFS integrated, loudness range 5.9 LU, true peak −7.4 dBTP. It lines up with the song to the sample: cross-correlated with song.wav in three 20-second windows (from 0:30, 1:30 and 2:30), the lag is 0 samples each time (measured for this package; the lead checked it to the millisecond at the time).

**The first test, S01.** Seedance 2.5 on Higgsfield, with:
- @Audio1: the stem from the shot's song time, cut to exactly 16.000 s, the generation length;
- the exact sung words in the prompt, in whole-second segments;
- @Video1: the shot's previz at 320 × 180, scaled back up and described as a rough guide;
- @Image1 her face sheet, @Image2 the A1 dress.

The take's own soundtrack is thrown away and the song laid back over it. It came back on-model, her lips on the words, the crane done as one continuous move. The production's audio-sync check called its soundtrack re-sung rather than copied (matching from 7 s), but its singing sat where the vocal is. anabology, on the test:

> OMG THE SEEDANCE W/ SUNO VOCAL STEM METHOD WORKED!!!!! LFG!!!! FINALLY. IT"S PERFECT
>
> WRITE THAT DOWN

**The whole film.** anabology, after the look tests: "we can go ahead and shoot the whole film with seedance in this style. remember the vocal stems for lip sync […]". Each of her shots got the stem from its own song time, exactly as long as the generation: 4, 6, 8, 12 or 16 s (`media/audio/refs/wp10-<shot>-suno<seconds>.wav`); two dance shots later got the music without her voice instead (below). After the notes on v1, anabology restated the aim: "wait we were supposed to totally abandon the h3 previs. seedance only was the goal in teh end with lip sync from teh vocal stems, that was the whole thing we cme to lol".

- **In numbers** (the job files, `shots/sdf-*.json`, `sdr-S01-suno.json` and the Replicate tests; the takes and their prompts are in [prompts-video.md](https://claudia.gallery/record/whitepill/prompts-video/)): the stem's windows drove 47 completed Seedance takes of her: 41 on Higgsfield (the S01 test, the 20 shots of the first cut, and the 19 of v2 and S18's lip-sync try in v3, all made without a guide clip) and 6 look tests on Replicate. Seven more requests were refused, no take (below). 18 of them are in the final cut: S01, S03–S08, S11, S11b, S13–S16, S19 and S22–S25, 152 s of generation in all.
- **Refused.** Seven requests were refused by the provider's content filter, no take: S11, S19 and S24, reworded retakes of S11 and S19, and two of S11b whose guide clip showed the masked performer bringing the pill to her lips.

**Two shots without her voice.** On two dance shots the lip sync did not hold. anabology, among their notes on the two v2 cuts:

> 5- 1:14 - 1:28 - honestly lets just remake this with her not singing, fully in the groove, just dancing around and having fun, she turns around, head goes down adn up etc - lip sync failed here but i dont think we need it. new seedance clip there. youd need to prompt forbidding singing here, and make sure she's happy.

> 8- 2:12-2:26 - shoot two here. shoot one more try with her lip syncing with the vocal stem and then one with her just grooving explicitly not singing, like 5 above.

For those two, @Audio1 is the song's music without her voice: song.wav minus 0.89 × the stem, sample for sample, 16 s from the shot's song time (S09 from 1:13.6, S18 from 2:11.3). An audio check heard house and disco in it, with a trace of voice. The prompt forbids singing, writes the groove out beat by beat and asks for her joy. anabology, on S18's two tries: "ok without singing it is. finish up the rest and do the final cut". Both grooving takes are in the final cut.

## The film's sound

The film's sound is the song itself: each take's own soundtrack is dropped and song.wav is laid over the cut from its 0:00, with no sound effects and no new mix. Measured on the final cut (with the lyrics): AAC, 48 kHz stereo, about 321 kb/s; −15.8 LUFS integrated (the song's own loudness), loudness range 3.9 LU, true peak −4.3 dBTP.

## Where these come from

The project's `suno/` folder (the styles, the exclude lists, the lyric drafts and their notes, `takes.md`), `research/SOUND.md`, `research/CASE.md`, `BRIEF.md`, `TIMELINE.md`, `media/audio/beatmap.json`, `media/audio/an/words-fa2.json`, `media/audio/suno/words-d1A.json`, the production's lip-sync notes, `tools/film/v10/gen_final_v10.py`, `tools/film/v10/lyrics.py`, the job files in `shots/`, anabology's messages and the lead's replies. Measured for this package: the scores, the song, the stem and the final cut's sound (ffprobe; ffmpeg's EBU R128 meter), and the stem's alignment with the song.
